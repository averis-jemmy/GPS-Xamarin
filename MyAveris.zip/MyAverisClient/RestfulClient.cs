using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Net;
using ModernHttpClient;
using System.IO;

namespace MyAveris
{
    public enum MyAverisHttpVerb
    {
        GET,
        POST,
        PUT,
        DELETE
    }

    public class MyAverisContentTypeString
    {
        private MyAverisContentTypeString(string value) { Value = value; }

        public string Value { get; set; }

        public static MyAverisContentTypeString Text { get { return new MyAverisContentTypeString("text/plain"); } }
        public static MyAverisContentTypeString XML { get { return new MyAverisContentTypeString("text/xml"); } }
        public static MyAverisContentTypeString JSON { get { return new MyAverisContentTypeString("application/json"); } }
    }

    public class RestfulClient
    {
        public string EndPoint { get; set; }
        public MyAverisHttpVerb Method { get; set; }
        public string ContentType { get; set; }
        public string PostData { get; set; }

        public RestfulClient(string endpoint)
        {
            EndPoint = endpoint;
            Method = MyAverisHttpVerb.GET;
            ContentType = MyAverisContentTypeString.XML.Value;
            PostData = "";
        }

        public RestfulClient(string endpoint, MyAverisHttpVerb method, MyAverisContentTypeString contentType, string postData)
        {
            EndPoint = endpoint;
            Method = method;
            ContentType = contentType.Value;
            PostData = postData;
        }

        public void ProcessRequest(string parameters, List<KeyValuePair<string, string>> headers)
        {
            List<KeyValuePair<String, String>> values = new List<KeyValuePair<string, string>>(); //<-- this should be filled with your key-values you want to POST.
            var content = new FormUrlEncodedContent(values);

            NativeCookieHandler cookies = new NativeCookieHandler(); // <-- if you need to send/receive cookies
            NativeMessageHandler handler = new NativeMessageHandler(false, false, cookies); //<-- **NOTE: different signature to send cookies.

            handler.UseCookies = true;

            using (HttpClient client = new HttpClient(handler))
            {
                //Task.WaitAll(client.PostAsync(EndPoint + parameters, new StringContent(PostData, Encoding.Default, "application/json")).ContinueWith(response =>
                //{
                //    if (response.Result.StatusCode == HttpStatusCode.OK)
                //    {
                //        //notifRep.UpdateSentStatus(info.ID);
                //    }
                //}));

                var response = client.PostAsync(EndPoint + parameters, new StringContent(PostData, Encoding.Default, "application/json")).Result;
                var responseValue = string.Empty;
                if (response != null && response.StatusCode == HttpStatusCode.OK)
                {
                    Task task = response.Content.ReadAsStreamAsync().ContinueWith(t =>
                    {
                        var stream = t.Result;
                        using (var reader = new StreamReader(stream))
                        {
                            responseValue = reader.ReadToEnd();
                        }
                    });

                    task.Wait();

                    //JObject result;

                    //try
                    //{
                    //    result = (JObject)JsonConvert.DeserializeObject(responseValue);
                    //    JArray results = ((JArray)result.SelectToken("results", false));
                    //    if (results != null && results != null && results.Count > 0)
                    //    {
                    //        try
                    //        {
                    //            JToken error = results[0].SelectToken("error", false);
                    //            if (error == null)
                    //                notifRep.UpdateSentStatus(info.ID);
                    //        }
                    //        catch { }
                    //    }
                    //}
                    //catch { }
                }
            }
        }
    }
}