﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyAverisEntity;

namespace MyAverisData
{
    public class PhotoRepository : RepositoryBase<Photo>
    {
        public PhotoRepository(AverisMobileDb context) : base(context) { }

        public List<KeyValuePair<string, int>> GetCategories()
        {
            var categories = (from item in GetAll()
                              where item.IsDeleted == false
                              group item by item.Category into category
                              select new { cat = category.Key, cnt = category.Count() }).ToList();

            var list = (from item in categories
                        select new KeyValuePair<string, int>(item.cat, item.cnt));

            return list.ToList();
        }

        public List<PhotoInfo> GetPhotoList(string category)
        {
            var photos = (from item in GetAll()
                          where item.IsDeleted == false && item.Category == category
                          select item).ToList();

            var photoList = (from item in photos
                             select new PhotoInfo()
                             {
                                 ID = item.ID,
                                 Name = item.Name,
                                 FilePath = item.FilePath
                             }).ToList();

            return photoList;
        }

        public bool Insert(PhotoInfo info, Guid userID)
        {
            try
            {
                string userEmail = string.Empty;
                try
                {
                    userEmail = (from item in context.Users
                                 where item.ID == userID && item.IsDeleted == false
                                 select item.EmailAddress).FirstOrDefault();
                }
                catch { }

                context.Photos.Add(new Photo()
                {
                    ID = Guid.NewGuid(),
                    Name = info.Name,
                    FilePath = info.FilePath,
                    Category = info.Category,
                    IsDeleted = false,
                    CreatedBy = userEmail,
                    CreatedDate = DateTime.Now,
                    UpdatedBy = userEmail,
                    UpdatedDate = DateTime.Now
                });
                context.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }
    }
}
