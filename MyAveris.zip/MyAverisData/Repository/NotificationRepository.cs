﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyAverisEntity;

namespace MyAverisData
{
    public class NotificationRepository : RepositoryBase<Notification>
    {
        public NotificationRepository(AverisMobileDb context) : base(context) { }

        public List<PreBoardingInfo> GetPendingAlerts()
        {
            var pendingNotifs = (from preBoarding in context.PreBoardingInformations
                                 join user in context.Users on preBoarding.UserID equals user.ID
                                 join jobApp in context.JobApplications on preBoarding.UserID equals jobApp.UserID
                                 where preBoarding.IsDeleted == false && preBoarding.JoinDate != null
                                 && user.IsDeleted == false && jobApp.IsDeleted == false
                                 select new PreBoardingInfo()
                                 {
                                     UserID = user.ID,
                                     FirstName = jobApp.FirstName,
                                     LastName = jobApp.LastName,
                                     Position = preBoarding.Position,
                                     BuddyName = preBoarding.BuddyName,
                                     HRContactPerson = preBoarding.HRContactPerson,
                                     Supervisor = preBoarding.Supervisor,
                                     Department = preBoarding.Department,
                                     JoinDate = preBoarding.JoinDate,
                                     RecruiterName = preBoarding.RecruiterName
                                 });

            return pendingNotifs.ToList();
        }

        public List<NotificationInfo> GetPendingNotifications()
        {
            var pendingNotifs = (from item in GetAll()
                                 join user in context.Users on item.UserID equals user.ID
                                 where item.IsSent == false && user.IsDeleted == false
                                 select new NotificationInfo()
                                 {
                                     ID = item.ID,
                                     UserID = item.UserID,
                                     Title = item.Title,
                                     Message = item.Message,
                                     NotificationType = item.NotificationType,
                                     DeviceToken = user.DeviceToken,
                                     MobileNumber = user.PhoneNumber
                                 });

            return pendingNotifs.ToList();
        }

        public void Update(NotificationInfo model)
        {
            if (model.UserID.HasValue)
            {
                context.Notifications.Add(new Notification()
                {
                    ID = model.ID,
                    UserID = model.UserID.GetValueOrDefault(),
                    Title = model.Title,
                    Message = model.Message,
                    NotificationType = model.NotificationType,
                    CreatedDate = DateTime.Now,
                    IsSent = false
                });
            }
            context.SaveChanges();
        }

        public void Update(NotificationInfo model, bool isSent)
        {
            if (model.UserID.HasValue)
            {
                context.Notifications.Add(new Notification()
                {
                    ID = model.ID,
                    UserID = model.UserID.GetValueOrDefault(),
                    Title = model.Title,
                    Message = model.Message,
                    NotificationType = model.NotificationType,
                    CreatedDate = DateTime.Now,
                    IsSent = isSent
                });
            }
            context.SaveChanges();
        }

        public void UpdateSentStatus(Guid id)
        {
            var notif = GetSingle(model => model.ID == id);
            if (notif != null)
            {
                notif.IsSent = true;
                notif.SentDate = DateTime.Now;
            }
            context.SaveChanges();
        }

        public void UpdateFailedStatus(Guid id)
        {
            var notif = GetSingle(model => model.ID == id);
            if (notif != null)
            {
                notif.IsSent = false;
            }
            context.SaveChanges();
        }
    }
}
