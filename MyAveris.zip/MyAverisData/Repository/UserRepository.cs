﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyAverisEntity;

namespace MyAverisData
{
    public class UserRepository : RepositoryBase<User>
    {
        public UserRepository(AverisMobileDb context) : base(context) { }

        public bool CreateUser(UserData model)
        {
            try
            {
                context.Users.Add(
                    new User()
                    {
                        ID = Guid.NewGuid(),
                        Name = model.UserName,
                        EmailAddress = model.Email,
                        PhoneNumber = model.PhoneNumber,
                        IsRecruiter = model.IsRecruiter,
                        IsDeleted = false,
                        CreatedDate = DateTime.Now,
                        UpdatedDate = DateTime.Now
                    });

                context.SaveChanges();

                return true;
            }
            catch { }
            return false;
        }

        public void UpdateHasProfilePicture(Guid userID)
        {
            try
            {
                var user = (from item in GetAll()
                            where item.ID == userID && item.IsDeleted == false
                            select item).FirstOrDefault();
                if (user != null)
                    user.HasProfilePicture = true;

                context.SaveChanges();
            }
            catch { }
        }

        public bool UserExists(UserData model)
        {
            var exists = (from item in GetAll()
                          where (item.PhoneNumber == model.PhoneNumber || item.EmailAddress == model.Email) && item.IsDeleted == false
                          select item).Any();

            return exists;
        }

        public bool PhoneNumberExists(UserData model)
        {
            var exists = (from item in GetAll()
                          where item.PhoneNumber == model.PhoneNumber && item.IsDeleted == false && item.ID != model.ID
                          select item).Any();

            return exists;
        }

        public bool ValidToken(Guid userID, Guid tokenID)
        {
            var exists = (from item in GetAll()
                          where item.ID == userID && item.IsDeleted == false && item.TokenID == tokenID
                          select item).Any();

            return exists;
        }

        public bool ValidRecruiter(Guid userID)
        {
            var exists = (from item in GetAll()
                          where item.ID == userID && item.IsDeleted == false && item.IsRecruiter == true
                          select item).Any();

            return exists;
        }

        public bool UpdateUser(UserData model)
        {
            try
            {
                var user = (from item in GetAll()
                            where item.ID == model.ID
                            select item).FirstOrDefault();

                if (user != null)
                {
                    user.Name = model.UserName;
                    user.EmailAddress = model.Email;
                    user.PhoneNumber = model.PhoneNumber;
                    user.UpdatedDate = DateTime.Now;

                    context.SaveChanges();
                    return true;
                }
            }
            catch { }

            return false;
        }

        public bool DeleteUser(Guid id)
        {
            try
            {
                var user = (from item in GetAll()
                            where item.ID == id
                            select item).FirstOrDefault();

                if (user != null)
                {
                    user.IsDeleted = true;
                    user.UpdatedDate = DateTime.Now;

                    context.SaveChanges();
                    return true;
                }
            }
            catch { }

            return false;
        }

        public UserData GetUserByID(Guid id)
        {
            var user = (from item in GetAll()
                        where item.ID == id
                        select new UserData()
                        {
                            ID = item.ID,
                            Email = item.EmailAddress,
                            UserName = item.Name,
                            PhoneNumber = item.PhoneNumber,
                            IsRecruiter = item.IsRecruiter,
                            HasProfilePicture = item.HasProfilePicture
                        }).FirstOrDefault();

            return user;
        }

        public List<UserData> GetAllUsers()
        {
            var users = (from item in GetAll()
                         where item.IsDeleted == false
                         select new UserData()
                        {
                            ID = item.ID,
                            UserName = item.Name,
                            Email = item.EmailAddress,
                            PhoneNumber = item.PhoneNumber,
                            IsRecruiter = item.IsRecruiter
                        });

            return users.ToList();
        }

        public bool CheckRegisteredUsers(string phone)
        {
            var verifySuccess = (from item in GetAll()
                                 where item.IsDeleted == false && item.PhoneNumber == phone
                                 select item).Any();

            return verifySuccess;
        }

        public bool HasRequestedVerificationCode(string phone)
        {
            var user = (from item in GetAll()
                        where item.IsDeleted == false && item.PhoneNumber == phone
                        select item).FirstOrDefault();

            if (user != null && !string.IsNullOrEmpty(user.VerificationCode)
                && (DateTime.Now - user.LastRequestedDate.GetValueOrDefault()).TotalMinutes < 1)
            {
                return true;
            }

            return false;
        }

        public Guid? GetUserIDByPhoneNumber(string phone)
        {
            var userID = (from item in GetAll()
                          where item.IsDeleted == false && item.PhoneNumber == phone
                          select item.ID).FirstOrDefault();

            return userID;
        }

        private string GenerateVerificationCode(string phone)
        {
            string code = string.Empty;
            try
            {
                Random rnd = new Random();
                code = rnd.Next(1, 999999).ToString().PadLeft(6, '0');

                var user = (from item in GetAll()
                            where item.IsDeleted == false && item.PhoneNumber == phone
                            select item).FirstOrDefault();

                if (user != null)
                {
                    user.VerificationCode = code;
                    user.LastRequestedDate = DateTime.Now;
                }

                context.SaveChanges();
            }
            catch (Exception ex) { throw ex; }

            return code;
        }

        public UserInfo IsVerified(Verification model)
        {
            try
            {
                var user = (from item in GetAll()
                            where item.IsDeleted == false && item.PhoneNumber == model.PhoneNumber
                            select item).FirstOrDefault();

                if (user != null && !string.IsNullOrEmpty(user.VerificationCode)
                    && user.VerificationCode == model.VerificationCode
                    && (DateTime.Now - user.LastRequestedDate.GetValueOrDefault()).TotalMinutes < 10)
                {
                    if (user.TokenID.HasValue)
                        ClearPreviousDataNotification(user.DeviceType, user.DeviceToken);

                    Guid tokenID = Guid.NewGuid();
                    user.TokenID = tokenID;
                    user.DeviceType = model.DeviceType;
                    user.UpdatedDate = DateTime.Now;

                    UserInfo info = new UserInfo();
                    info.UserID = user.ID;
                    info.UserName = user.Name;
                    info.Email = user.EmailAddress;
                    info.PhoneNumber = user.PhoneNumber;
                    info.IsRecruiter = user.IsRecruiter.GetValueOrDefault();
                    info.TokenID = tokenID;
                    info.PositionApplied = user.PositionApplied;
                    info.HasProfilePicture = user.HasProfilePicture.GetValueOrDefault();

                    context.SaveChanges();

                    return info;
                }
            }
            catch { }

            return null;
        }

        public string SendSMSVerificationCode(string phone)
        {
            try
            {
                var verificationCode = GenerateVerificationCode(phone);
                return verificationCode;
            }
            catch { }

            return string.Empty;
        }

        public bool UpdateDeviceToken(string deviceToken, Guid id)
        {
            try
            {
                var user = (from item in GetAll()
                            where item.IsDeleted == false && item.ID == id
                            select item).FirstOrDefault();
                if (user != null)
                {
                    user.DeviceToken = deviceToken;
                    context.SaveChanges();
                    return true;
                }
            }
            catch { }
            return false;
        }

        private void ClearPreviousDataNotification(string deviceType, string deviceToken)
        {
            try
            {

            }
            catch { }
        }
    }
}
