﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyAverisEntity;

namespace MyAverisData
{
    public class VideoRepository : RepositoryBase<Video>
    {
        public VideoRepository(AverisMobileDb context) : base(context) { }

        public List<KeyValuePair<string, int>> GetCategories()
        {
            var categories = (from item in GetAll()
                              where item.IsDeleted == false
                              group item by item.Category into category
                              select new { cat = category.Key, cnt = category.Count() }).ToList();

            var list = (from item in categories
                        select new KeyValuePair<string, int>(item.cat, item.cnt));

            return list.ToList();
        }

        public List<VideoInfo> GetVideoList(string category)
        {
            var videos = (from item in GetAll()
                              where item.IsDeleted == false && item.Category == category
                              select new VideoInfo()
                              {
                                  ID = item.ID,
                                  Name = item.Name,
                                  VideoCode = item.VideoCode
                              });

            return videos.ToList();
        }

        public bool Insert(VideoInfo info, Guid userID)
        {
            try
            {
                string userEmail = string.Empty;
                try
                {
                    userEmail = (from item in context.Users
                                 where item.ID == userID && item.IsDeleted == false
                                 select item.EmailAddress).FirstOrDefault();
                }
                catch { }

                context.Videos.Add(new Video()
                {
                    ID = Guid.NewGuid(),
                    Name = info.Name,
                    VideoCode = info.VideoCode,
                    Category = info.Category,
                    IsDeleted = false,
                    CreatedBy = userEmail,
                    CreatedDate = DateTime.Now,
                    UpdatedBy = userEmail,
                    UpdatedDate = DateTime.Now
                });
                context.SaveChanges();
            }
            catch
            {
                return false;
            }
            return true;
        }
    }
}
