﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAverisData
{
    public class JobApplicationRepository : RepositoryBase<JobApplication>
    {
        public JobApplicationRepository(AverisMobileDb context) : base(context) { }

        public JobApplicationInfo GetJobApplicationByUserID(Guid userID)
        {
            var jobApplication = (from item in GetAll()
                                  where item.UserID == userID && item.IsDeleted == false
                                  select item).FirstOrDefault();

            if (jobApplication == null)
                return null;

            var jobInfo = GetJobApplication(jobApplication);
            if (jobInfo != null)
            {
                jobInfo.CurrentAddress = GetAddress(jobApplication, InitialData.AddressType.CurrentAddress);
                jobInfo.HomeAddress = GetAddress(jobApplication, InitialData.AddressType.HomeAddress);
                jobInfo.EmergencyAddress = GetAddress(jobApplication, InitialData.AddressType.EmergencyAddress);
                jobInfo.PackageDetail = GetPackageDetail(jobApplication);

                jobInfo.Activities = GetActivities(jobApplication);
                jobInfo.Declarations = GetDeclarations(jobApplication);
                jobInfo.Educations = GetEducations(jobApplication);
                jobInfo.Families = GetFamilies(jobApplication);
                jobInfo.Languages = GetLanguages(jobApplication);
                jobInfo.References = GetReferences(jobApplication);
                jobInfo.WorkingHistories = GetWorkingHistories(jobApplication);
            }

            return jobInfo;
        }

        //public byte[] GetPhotoByUserID(Guid userID)
        //{
        //    var jobApplicationPhoto = (from item in GetAll()
        //                               where item.UserID == userID && item.IsDeleted == false
        //                               select item.Photo).FirstOrDefault();

        //    return jobApplicationPhoto;
        //}

        public ShortJobApplicationInfo GetJobApplicationStatusByUserID(Guid userID)
        {
            var jobApplication = (from item in GetAll()
                                  join user in context.Users on item.UserID equals user.ID
                                  where item.UserID == userID && item.IsDeleted == false
                                  && user.IsDeleted == false
                                  select new ShortJobApplicationInfo()
                                  {
                                      ID = item.ID,
                                      UserID = item.UserID,
                                      FullName = item.FirstName,
                                      PositionApplied = user.PositionApplied,
                                      ApplicationStatus = item.ApplicationStatus,
                                      IsLocked = item.IsLocked
                                  }).FirstOrDefault();

            if(jobApplication == null)
            {
                jobApplication = new ShortJobApplicationInfo();
                jobApplication.IsLocked = false;
                jobApplication.ApplicationStatus = InitialData.ApplicationStatus.New;
                jobApplication.PositionApplied = (from item in context.Users
                                                  where item.ID == userID && item.IsDeleted == false
                                                  select item.PositionApplied).FirstOrDefault();
            }

            return jobApplication;
        }

        public JobApplicationInfo GetJobApplicationByID(Guid id)
        {
            var jobApplication = (from item in GetAll()
                                  where item.ID == id && item.IsDeleted == false
                                  select item).FirstOrDefault();

            if (jobApplication == null)
                return null;

            var jobInfo = GetJobApplication(jobApplication);
            if (jobInfo != null)
            {
                jobInfo.CurrentAddress = GetAddress(jobApplication, InitialData.AddressType.CurrentAddress);
                jobInfo.HomeAddress = GetAddress(jobApplication, InitialData.AddressType.HomeAddress);
                jobInfo.EmergencyAddress = GetAddress(jobApplication, InitialData.AddressType.EmergencyAddress);
                jobInfo.PackageDetail = GetPackageDetail(jobApplication);

                jobInfo.Activities = GetActivities(jobApplication);
                jobInfo.Declarations = GetDeclarations(jobApplication);
                jobInfo.Educations = GetEducations(jobApplication);
                jobInfo.Families = GetFamilies(jobApplication);
                jobInfo.Languages = GetLanguages(jobApplication);
                jobInfo.References = GetReferences(jobApplication);
                jobInfo.WorkingHistories = GetWorkingHistories(jobApplication);
            }

            return jobInfo;
        }

        public List<ShortJobApplicationInfo> GetAllJobApplications()
        {
            var jobApplications = (from item in GetAll()
                                   join user in context.Users on item.UserID equals user.ID into temp
                                   from us in temp.DefaultIfEmpty()
                                   where item.IsDeleted == false && item.ApplicationStatus == InitialData.ApplicationStatus.Submitted
                                   orderby item.UpdatedDate descending
                                   select new ShortJobApplicationInfo
                                   {
                                       ID = item.ID,
                                       UserID = item.UserID,
                                       FullName = item.FirstName,
                                       PositionApplied = (us == null ? string.Empty : us.PositionApplied),
                                       ApplicationStatus = item.ApplicationStatus,
                                       IsLocked = item.IsLocked
                                   });

            return jobApplications.ToList();
        }

        public JobApplicationInfo GetJobApplication(JobApplication item)
        {
            var jobApplication = new JobApplicationInfo()
            {
                ID = item.ID,
                UserID = item.UserID,
                Title = item.Title,
                FirstName = item.FirstName,
                LastName = item.LastName,
                KnownAs = item.KnownAs,
                ChineseCharacter = item.ChineseCharacter,
                Gender = item.Gender,
                DateOfBirth = item.DateOfBirth,
                CountryOfBirth = item.CountryOfBirth,
                Nationality = item.Nationality,
                Race = item.Race,
                MaritalStatus = item.MaritalStatus,
                Religion = item.Religion,
                IdentityNo = item.IdentityNo,
                IsPassport = item.IsPassport,
                DateOfIssue = item.DateOfIssue,
                DateOfExpiry = item.DateOfExpiry,
                CountryOfIssue = item.CountryOfIssue,
                EmailAddress = item.EmailAddress,
                EmergencyContact = item.EmergencyContact,
                ServiceCompleted = item.ServiceCompleted,
                HighestRankAttained = item.HighestRankAttained,
                ExemptionReason = item.ExemptionReason,
                LiabilityForDuties = item.LiabilityForDuties,
                ApplicationStatus = item.ApplicationStatus,
                IsLocked = item.IsLocked
            };
            return jobApplication;
        }

        private JobApplicationPackageDetailInfo GetPackageDetail(JobApplication item)
        {
            var packageDetail = (from model in item.JobApplicationPackageDetails
                                 select new JobApplicationPackageDetailInfo()
                                 {
                                     ID = model.ID,
                                     JobApplicationID = model.JobApplicationID,
                                     EPFNumber = model.EPFNumber,
                                     SOCSONumber = model.SOCSONumber,
                                     IncomeTaxNumber = model.IncomeTaxNumber,
                                     BankAccountNumber = model.BankAccountNumber,
                                     BaseSalary = model.BaseSalary,
                                     ExpectedSalary = model.ExpectedSalary,
                                     ContractualBonus = model.ContractualBonus,
                                     PerformanceBonus = model.PerformanceBonus,
                                     HousingAllowance = model.HousingAllowance,
                                     TransportAllowance = model.TransportAllowance,
                                     ConnectivityAllowance = model.ConnectivityAllowance,
                                     ProjectAlowance = model.ProjectAlowance,
                                     SpecialSkillsAllowance = model.SpecialSkillsAllowance,
                                     CarParkAllowance = model.CarParkAllowance,
                                     CarParkClaim = model.CarParkClaim,
                                     PhoneClaim = model.PhoneClaim,
                                     MileageClaim = model.MileageClaim,
                                     MealClaim = model.MealClaim,
                                     OvertimeClaim = model.OvertimeClaim,
                                     StandbyClaim = model.StandbyClaim,
                                     SelfMedicalBenefit = model.SelfMedicalBenefit,
                                     FamilyMedicalBenefit = model.FamilyMedicalBenefit,
                                     SelfInsuranceBenefit = model.SelfInsuranceBenefit,
                                     FamilyInsuranceBenefit = model.FamilyInsuranceBenefit,
                                     DentalBenefit = model.DentalBenefit,
                                     OpticalBenefit = model.OpticalBenefit,
                                     RetirementBenefit = model.RetirementBenefit,
                                     AnnualLeave = model.AnnualLeave,
                                     MedicalLeave = model.MedicalLeave
                                 }).FirstOrDefault();
            return packageDetail;
        }

        private JobApplicationAddressInfo GetAddress(JobApplication item, string addressType)
        {
            var currentAddress = (from model in item.JobApplicationAddresses
                                  where model.AddressType == addressType
                                  select new JobApplicationAddressInfo()
                                  {
                                      ID = model.ID,
                                      JobApplicationID = model.JobApplicationID,
                                      AddressType = model.AddressType,
                                      Address = model.Address,
                                      Country = model.Country,
                                      HomeNumber = model.HomeNumber,
                                      MobileNumber = model.MobileNumber,
                                      PostalCode = model.PostalCode
                                  }).FirstOrDefault();
            return currentAddress;
        }

        private List<JobApplicationActivityInfo> GetActivities(JobApplication item)
        {
            var activities = (from model in item.JobApplicationActivities
                              select new JobApplicationActivityInfo()
                              {
                                  ID = model.ID,
                                  JobApplicationID = model.JobApplicationID,
                                  Organisation = model.Organisation,
                                  FromDate = model.FromDate,
                                  ToDate = model.ToDate,
                                  Country = model.Country,
                                  NatureOfActivities = model.NatureOfActivities
                              }).ToList();
            return activities;
        }

        private List<JobApplicationDeclarationInfo> GetDeclarations(JobApplication item)
        {
            var declarations = (from model in item.JobApplicationDeclarations
                                select new JobApplicationDeclarationInfo()
                                {
                                    ID = model.ID,
                                    JobApplicationID = model.JobApplicationID,
                                    DeclarationID = model.DeclarationID,
                                    DeclarationDetail = model.DeclarationDetail.Declaration,
                                    Answer = model.Answer,
                                    Remarks = model.Remarks
                                }).ToList();
            return declarations;
        }

        private List<JobApplicationEducationInfo> GetEducations(JobApplication item)
        {
            var educations = (from model in item.JobApplicationEducations
                              select new JobApplicationEducationInfo()
                              {
                                  ID = model.ID,
                                  JobApplicationID = model.JobApplicationID,
                                  StartDate = model.StartDate,
                                  EndDate = model.EndDate,
                                  Institution = model.Institution,
                                  Country = model.Country,
                                  Qualification = model.Qualification,
                                  CourseOfStudy = model.CourseOfStudy
                              }).ToList();
            return educations;
        }

        private List<JobApplicationFamilyInfo> GetFamilies(JobApplication item)
        {
            var families = (from model in item.JobApplicationFamilies
                            select new JobApplicationFamilyInfo()
                            {
                                ID = model.ID,
                                JobApplicationID = model.JobApplicationID,
                                Relationship = model.Relationship,
                                FirstName = model.FirstName,
                                LastName = model.LastName,
                                IdentityNo = model.IdentityNo,
                                Gender = model.Gender,
                                DateOfBirth = model.DateOfBirth,
                                CountryOfBirth = model.CountryOfBirth,
                                Nationality = model.Nationality,
                                JobTitle = model.JobTitle,
                                Employer = model.Employer,
                                IsSameCountry = model.IsSameCountry
                            }).ToList();
            return families;
        }

        private List<JobApplicationLanguageInfo> GetLanguages(JobApplication item)
        {
            var languages = (from model in item.JobApplicationLanguages
                             select new JobApplicationLanguageInfo()
                             {
                                 ID = model.ID,
                                 JobApplicationID = model.JobApplicationID,
                                 Language = model.Language,
                                 ReadAbility = model.ReadAbility,
                                 WriteAbility = model.WriteAbility,
                                 SpeakAbility = model.SpeakAbility
                             }).ToList();
            return languages;
        }

        private List<JobApplicationReferenceInfo> GetReferences(JobApplication item)
        {
            var references = (from model in item.JobApplicationReferences
                              select new JobApplicationReferenceInfo()
                              {
                                  ID = model.ID,
                                  JobApplicationID = model.JobApplicationID,
                                  Name = model.Name,
                                  Occupation = model.Occupation,
                                  YearsKnown = model.YearsKnown,
                                  Address = model.Address,
                                  Employer = model.Employer,
                                  HomeNumber = model.HomeNumber,
                                  MobileNumber = model.MobileNumber,
                                  OfficeNumber = model.OfficeNumber
                              }).ToList();
            return references;
        }

        private List<JobApplicationWorkingHistoryInfo> GetWorkingHistories(JobApplication item)
        {
            try
            {
                var workingHistories = (from model in item.JobApplicationWorkingHistories
                                        select model).ToList();

                var histories = (from model in workingHistories
                                 select new JobApplicationWorkingHistoryInfo()
                                 {
                                     ID = model.ID,
                                     JobApplicationID = model.JobApplicationID,
                                     StartDate = model.StartDate,
                                     EndDate = model.EndDate,
                                     Company = model.Company,
                                     Country = model.Country,
                                     LastPositionHeld = model.LastPositionHeld,
                                     NameOfSuperior = model.NameOfSuperior,
                                     DesignationOfSuperior = model.DesignationOfSuperior,
                                     LastDrawnSalary = decimal.Parse(Cryptography.Decryption(model.LastDrawnSalary)),
                                     ReasonForLeaving = model.ReasonForLeaving
                                 }).ToList();
                return histories;
            }
            catch { }
            return new List<JobApplicationWorkingHistoryInfo>();
        }

        public bool AcceptJobApplication(PreBoardingInfo model)
        {
            var jobApplication = (from item in GetAll()
                                  where item.ID == model.JobID && item.IsDeleted == false
                                  select item).FirstOrDefault();

            string userEmail = string.Empty;
            try
            {
                userEmail = (from item in context.Users
                             where item.ID == model.UserID && item.IsDeleted == false
                             select item.EmailAddress).FirstOrDefault();
            }
            catch { }

            string recruiterName = string.Empty;
            try
            {
                recruiterName = (from item in context.Users
                                 where item.ID == model.UserID && item.IsDeleted == false
                                 select item.Name).FirstOrDefault();
            }
            catch { }

            if (jobApplication == null)
                return false;

            if (jobApplication.ApplicationStatus != InitialData.ApplicationStatus.Submitted)
                return false;

            //if (!jobApplication.IsLocked.GetValueOrDefault())
            //    return false;

            jobApplication.IsLocked = true;
            jobApplication.ApplicationStatus = InitialData.ApplicationStatus.Accepted;
            jobApplication.UpdatedDate = DateTime.Now;
            jobApplication.UpdatedBy = userEmail;

            var preBoardings = (from item in context.PreBoardingInformations
                                where item.UserID == jobApplication.UserID && item.IsDeleted == false
                                select item);
            foreach (PreBoardingInformation preBoarding in preBoardings)
            {
                preBoarding.IsDeleted = true;
            }

            context.PreBoardingInformations.Add(new PreBoardingInformation()
            {
                ID = Guid.NewGuid(),
                UserID = jobApplication.UserID,
                Position = model.Position,
                BuddyName = model.BuddyName,
                HRContactPerson = model.HRContactPerson,
                Supervisor = model.Supervisor,
                Department = model.Department,
                JoinDate = model.JoinDate,
                RecruiterName = recruiterName,
                IsDeleted = false,
                CreatedDate = DateTime.Now,
                CreatedBy = userEmail,
                UpdatedDate = DateTime.Now,
                UpdatedBy = userEmail
            });

            try
            {
                context.SaveChanges();
            }
            catch { return false; }

            return true;
        }

        public bool RejectJobApplication(Guid id, Guid userID)
        {
            var jobApplication = (from item in GetAll()
                                  where item.ID == id && item.IsDeleted == false
                                  select item).FirstOrDefault();

            string userEmail = string.Empty;
            try
            {
                userEmail = (from item in context.Users
                             where item.ID == userID && item.IsDeleted == false
                             select item.EmailAddress).FirstOrDefault();
            }
            catch { }

            if (jobApplication == null)
                return false;

            if (jobApplication.ApplicationStatus != InitialData.ApplicationStatus.Submitted)
                return false;

            //if (!jobApplication.IsLocked.GetValueOrDefault())
            //    return false;

            jobApplication.IsLocked = true;
            jobApplication.ApplicationStatus = InitialData.ApplicationStatus.Rejected;
            jobApplication.UpdatedDate = DateTime.Now;
            jobApplication.UpdatedBy = userEmail;

            try
            {
                context.SaveChanges();
            }
            catch { return false; }

            return true;
        }

        public bool UnlockJobApplication(Guid id, Guid userID, bool isUnlock)
        {
            var jobApplication = (from item in GetAll()
                                  where item.ID == id && item.IsDeleted == false
                                  select item).FirstOrDefault();

            string userEmail = string.Empty;
            try
            {
                userEmail = (from item in context.Users
                             where item.ID == userID && item.IsDeleted == false
                             select item.EmailAddress).FirstOrDefault();
            }
            catch { }

            if (jobApplication == null)
                return false;

            jobApplication.IsLocked = !isUnlock;
            jobApplication.UpdatedDate = DateTime.Now;
            jobApplication.UpdatedBy = userEmail;

            try
            {
                context.SaveChanges();
            }
            catch { return false; }

            return true;
        }

        public bool KIVJobApplication(Guid id, Guid userID)
        {
            var jobApplication = (from item in GetAll()
                                  where item.ID == id && item.IsDeleted == false
                                  select item).FirstOrDefault();

            string userEmail = string.Empty;
            try
            {
                userEmail = (from item in context.Users
                             where item.ID == userID && item.IsDeleted == false
                             select item.EmailAddress).FirstOrDefault();
            }
            catch { }

            if (jobApplication == null)
                return false;

            jobApplication.IsLocked = true;
            jobApplication.ApplicationStatus = InitialData.ApplicationStatus.KIV;
            jobApplication.UpdatedDate = DateTime.Now;
            jobApplication.UpdatedBy = userEmail;

            try
            {
                context.SaveChanges();
            }
            catch { return false; }

            return true;
        }

        public string SaveJobApplication(JobApplicationInfo info)
        {
            var jobApplication = (from item in GetAll()
                                  where item.UserID == info.UserID && item.IsDeleted == false
                                  select item).FirstOrDefault();

            string userEmail = string.Empty;
            try
            {
                userEmail = (from item in context.Users
                             where item.ID == info.UserID && item.IsDeleted == false
                             select item.EmailAddress).FirstOrDefault();
            }
            catch { }

            if (jobApplication == null)
            {
                Guid jobAppID = Guid.NewGuid();
                info.ID = jobAppID;

                context.JobApplications.Add(new JobApplication()
                {
                    ID = jobAppID,
                    UserID = info.UserID,
                    Title = info.Title,
                    FirstName = info.FirstName,
                    LastName = info.LastName,
                    KnownAs = info.KnownAs,
                    ChineseCharacter = info.ChineseCharacter,
                    Gender = info.Gender,
                    DateOfBirth = info.DateOfBirth,
                    CountryOfBirth = info.CountryOfBirth,
                    Nationality = info.Nationality,
                    Race = info.Race,
                    MaritalStatus = info.MaritalStatus,
                    Religion = info.Religion,
                    IdentityNo = info.IdentityNo,
                    IsPassport = info.IsPassport,
                    DateOfIssue = info.DateOfIssue,
                    DateOfExpiry = info.DateOfExpiry,
                    CountryOfIssue = info.CountryOfIssue,
                    EmailAddress = info.EmailAddress,
                    EmergencyContact = info.EmergencyContact,
                    ServiceCompleted = info.ServiceCompleted,
                    HighestRankAttained = info.HighestRankAttained,
                    ExemptionReason = info.ExemptionReason,
                    LiabilityForDuties = info.LiabilityForDuties,
                    ApplicationStatus = InitialData.ApplicationStatus.Submitted,
                    IsDeleted = false,
                    CreatedDate = DateTime.Now,
                    UpdatedDate = DateTime.Now,
                    CreatedBy = userEmail,
                    UpdatedBy = userEmail
                });
            }
            else
            {
                if (jobApplication.IsLocked.GetValueOrDefault())
                {
                    return "Job application form has been locked for verification.";
                }

                if (jobApplication.ApplicationStatus == InitialData.ApplicationStatus.Accepted ||
                    jobApplication.ApplicationStatus == InitialData.ApplicationStatus.Rejected)
                {
                    return "Job application form has been processed. - " + jobApplication.ApplicationStatus;
                }

                info.ID = jobApplication.ID;

                jobApplication.UserID = info.UserID;
                jobApplication.Title = info.Title;
                jobApplication.FirstName = info.FirstName;
                jobApplication.LastName = info.LastName;
                jobApplication.KnownAs = info.KnownAs;
                jobApplication.ChineseCharacter = info.ChineseCharacter;
                jobApplication.Gender = info.Gender;
                jobApplication.DateOfBirth = info.DateOfBirth;
                jobApplication.CountryOfBirth = info.CountryOfBirth;
                jobApplication.Nationality = info.Nationality;
                jobApplication.Race = info.Race;
                jobApplication.MaritalStatus = info.MaritalStatus;
                jobApplication.Religion = info.Religion;
                jobApplication.IdentityNo = info.IdentityNo;
                jobApplication.IsPassport = info.IsPassport;
                jobApplication.DateOfIssue = info.DateOfIssue;
                jobApplication.DateOfExpiry = info.DateOfExpiry;
                jobApplication.CountryOfIssue = info.CountryOfIssue;
                jobApplication.EmailAddress = info.EmailAddress;
                jobApplication.EmergencyContact = info.EmergencyContact;
                jobApplication.ServiceCompleted = info.ServiceCompleted;
                jobApplication.HighestRankAttained = info.HighestRankAttained;
                jobApplication.ExemptionReason = info.ExemptionReason;
                jobApplication.LiabilityForDuties = info.LiabilityForDuties;
                jobApplication.ApplicationStatus = InitialData.ApplicationStatus.Submitted;
                jobApplication.UpdatedDate = DateTime.Now;
                jobApplication.UpdatedBy = userEmail;
            }

            SaveOtherInfo(info);

            try
            {
                context.SaveChanges();
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                return "Submission failed";
            }

            return string.Empty;
        }

        //public string UploadProfilePicture(byte[] picData, Guid userID)
        //{
        //    var jobApplication = (from item in GetAll()
        //                          where item.UserID == userID && item.IsDeleted == false
        //                          select item).FirstOrDefault();

        //    string userEmail = string.Empty;
        //    try
        //    {
        //        userEmail = (from item in context.Users
        //                     where item.ID == userID && item.IsDeleted == false
        //                     select item.EmailAddress).FirstOrDefault();
        //    }
        //    catch { }

        //    if (jobApplication == null)
        //    {
        //        Guid jobAppID = Guid.NewGuid();

        //        context.JobApplications.Add(new JobApplication()
        //        {
        //            ID = jobAppID,
        //            UserID = userID,
        //            Photo = picData,
        //            ApplicationStatus = InitialData.ApplicationStatus.New,
        //            IsLocked = false,
        //            IsDeleted = false,
        //            CreatedDate = DateTime.Now,
        //            UpdatedDate = DateTime.Now,
        //            CreatedBy = userEmail,
        //            UpdatedBy = userEmail
        //        });
        //    }
        //    else
        //    {
        //        jobApplication.UserID = userID;
        //        jobApplication.Photo = picData;
        //        jobApplication.UpdatedDate = DateTime.Now;
        //        jobApplication.UpdatedBy = userEmail;
        //    }

        //    try
        //    {
        //        context.SaveChanges();
        //    }
        //    catch { return "Submission failed"; }

        //    return string.Empty;
        //}

        private void SaveOtherInfo(JobApplicationInfo info)
        {
            #region Address
            var addresses = (from item in context.JobApplicationAddresses
                             where item.JobApplicationID == info.ID
                             select item);
            foreach (JobApplicationAddress item in addresses)
            {
                context.JobApplicationAddresses.Remove(item);
            }

            if (info.CurrentAddress != null)
            {
                context.JobApplicationAddresses.Add(new JobApplicationAddress()
                {
                    ID = Guid.NewGuid(),
                    JobApplicationID = info.ID,
                    AddressType = InitialData.AddressType.CurrentAddress,
                    Address = info.CurrentAddress.Address,
                    Country = info.CurrentAddress.Country,
                    PostalCode = info.CurrentAddress.PostalCode,
                    HomeNumber = info.CurrentAddress.HomeNumber,
                    MobileNumber = info.CurrentAddress.MobileNumber
                });
            }

            if (info.HomeAddress != null)
            {
                context.JobApplicationAddresses.Add(new JobApplicationAddress()
                {
                    ID = Guid.NewGuid(),
                    JobApplicationID = info.ID,
                    AddressType = InitialData.AddressType.HomeAddress,
                    Address = info.HomeAddress.Address,
                    Country = info.HomeAddress.Country,
                    PostalCode = info.HomeAddress.PostalCode,
                    HomeNumber = info.HomeAddress.HomeNumber,
                    MobileNumber = info.HomeAddress.MobileNumber
                });
            }

            if (info.EmergencyAddress != null)
            {
                context.JobApplicationAddresses.Add(new JobApplicationAddress()
                {
                    ID = Guid.NewGuid(),
                    JobApplicationID = info.ID,
                    AddressType = InitialData.AddressType.EmergencyAddress,
                    Address = info.EmergencyAddress.Address,
                    Country = info.EmergencyAddress.Country,
                    PostalCode = info.EmergencyAddress.PostalCode,
                    HomeNumber = info.EmergencyAddress.HomeNumber,
                    MobileNumber = info.EmergencyAddress.MobileNumber
                });
            }
            #endregion

            #region Package Detail
            var packageDetail = (from item in context.JobApplicationPackageDetails
                                 where item.JobApplicationID == info.ID
                                 select item);
            foreach (JobApplicationPackageDetail item in packageDetail)
            {
                context.JobApplicationPackageDetails.Remove(item);
            }

            if (info.PackageDetail != null)
            {
                context.JobApplicationPackageDetails.Add(new JobApplicationPackageDetail()
                {
                    ID = Guid.NewGuid(),
                    JobApplicationID = info.ID,
                    EPFNumber = info.PackageDetail.EPFNumber,
                    SOCSONumber = info.PackageDetail.SOCSONumber,
                    IncomeTaxNumber = info.PackageDetail.IncomeTaxNumber,
                    BankAccountNumber = info.PackageDetail.BankAccountNumber,
                    BaseSalary = info.PackageDetail.BaseSalary,
                    ExpectedSalary = info.PackageDetail.ExpectedSalary,
                    ContractualBonus = info.PackageDetail.ContractualBonus,
                    PerformanceBonus = info.PackageDetail.PerformanceBonus,
                    HousingAllowance = info.PackageDetail.HousingAllowance,
                    TransportAllowance = info.PackageDetail.TransportAllowance,
                    ConnectivityAllowance = info.PackageDetail.ConnectivityAllowance,
                    ProjectAlowance = info.PackageDetail.ProjectAlowance,
                    SpecialSkillsAllowance = info.PackageDetail.SpecialSkillsAllowance,
                    CarParkAllowance = info.PackageDetail.CarParkAllowance,
                    CarParkClaim = info.PackageDetail.CarParkClaim,
                    PhoneClaim = info.PackageDetail.PhoneClaim,
                    MileageClaim = info.PackageDetail.MileageClaim,
                    MealClaim = info.PackageDetail.MealClaim,
                    OvertimeClaim = info.PackageDetail.OvertimeClaim,
                    StandbyClaim = info.PackageDetail.StandbyClaim,
                    SelfMedicalBenefit = info.PackageDetail.SelfMedicalBenefit,
                    FamilyMedicalBenefit = info.PackageDetail.FamilyMedicalBenefit,
                    SelfInsuranceBenefit = info.PackageDetail.SelfInsuranceBenefit,
                    FamilyInsuranceBenefit = info.PackageDetail.FamilyInsuranceBenefit,
                    DentalBenefit = info.PackageDetail.DentalBenefit,
                    OpticalBenefit = info.PackageDetail.OpticalBenefit,
                    RetirementBenefit = info.PackageDetail.RetirementBenefit,
                    AnnualLeave = info.PackageDetail.AnnualLeave,
                    MedicalLeave = info.PackageDetail.MedicalLeave
                });
            }
            #endregion

            #region Social/Political Activity
            var activities = (from item in context.JobApplicationActivities
                              where item.JobApplicationID == info.ID
                              select item);
            foreach (JobApplicationActivity item in activities)
            {
                context.JobApplicationActivities.Remove(item);
            }

            if (info.Activities != null)
            {
                foreach (JobApplicationActivityInfo model in info.Activities)
                {
                    context.JobApplicationActivities.Add(new JobApplicationActivity()
                    {
                        ID = Guid.NewGuid(),
                        JobApplicationID = info.ID,
                        Organisation = model.Organisation,
                        FromDate = model.FromDate,
                        ToDate = model.ToDate,
                        Country = model.Country,
                        NatureOfActivities = model.NatureOfActivities
                    });
                }
            }
            #endregion

            #region Declaration
            var declarations = (from item in context.JobApplicationDeclarations
                                where item.JobApplicationID == info.ID
                                select item);
            foreach (JobApplicationDeclaration item in declarations)
            {
                context.JobApplicationDeclarations.Remove(item);
            }

            if (info.Declarations != null)
            {
                foreach (JobApplicationDeclarationInfo model in info.Declarations)
                {
                    context.JobApplicationDeclarations.Add(new JobApplicationDeclaration()
                    {
                        ID = Guid.NewGuid(),
                        JobApplicationID = info.ID,
                        DeclarationID = model.DeclarationID,
                        Answer = model.Answer,
                        Remarks = model.Remarks
                    });
                }
            }
            #endregion

            #region Education
            var educations = (from item in context.JobApplicationEducations
                              where item.JobApplicationID == info.ID
                              select item);
            foreach (JobApplicationEducation item in educations)
            {
                context.JobApplicationEducations.Remove(item);
            }

            if (info.Educations != null)
            {
                foreach (JobApplicationEducationInfo model in info.Educations)
                {
                    context.JobApplicationEducations.Add(new JobApplicationEducation()
                    {
                        ID = Guid.NewGuid(),
                        JobApplicationID = info.ID,
                        StartDate = model.StartDate,
                        EndDate = model.EndDate,
                        Institution = model.Institution,
                        Country = model.Country,
                        Qualification = model.Qualification,
                        CourseOfStudy = model.CourseOfStudy
                    });
                }
            }
            #endregion

            #region Family
            var families = (from item in context.JobApplicationFamilies
                            where item.JobApplicationID == info.ID
                            select item);
            foreach (JobApplicationFamily item in families)
            {
                context.JobApplicationFamilies.Remove(item);
            }

            if (info.Families != null)
            {
                foreach (JobApplicationFamilyInfo model in info.Families)
                {
                    context.JobApplicationFamilies.Add(new JobApplicationFamily()
                    {
                        ID = Guid.NewGuid(),
                        JobApplicationID = info.ID,
                        Relationship = model.Relationship,
                        FirstName = model.FirstName,
                        LastName = model.LastName,
                        IdentityNo = model.IdentityNo,
                        Gender = model.Gender,
                        DateOfBirth = model.DateOfBirth,
                        CountryOfBirth = model.CountryOfBirth,
                        Nationality = model.Nationality,
                        JobTitle = model.JobTitle,
                        Employer = model.Employer,
                        IsSameCountry = model.IsSameCountry
                    });
                }
            }
            #endregion

            #region Language
            var languages = (from item in context.JobApplicationLanguages
                             where item.JobApplicationID == info.ID
                             select item);
            foreach (JobApplicationLanguage item in languages)
            {
                context.JobApplicationLanguages.Remove(item);
            }

            if (info.Languages != null)
            {
                foreach (JobApplicationLanguageInfo model in info.Languages)
                {
                    context.JobApplicationLanguages.Add(new JobApplicationLanguage()
                    {
                        ID = Guid.NewGuid(),
                        JobApplicationID = info.ID,
                        Language = model.Language,
                        ReadAbility = model.ReadAbility,
                        WriteAbility = model.WriteAbility,
                        SpeakAbility = model.SpeakAbility
                    });
                }
            }
            #endregion

            #region Reference
            var references = (from item in context.JobApplicationReferences
                              where item.JobApplicationID == info.ID
                              select item);
            foreach (JobApplicationReference item in references)
            {
                context.JobApplicationReferences.Remove(item);
            }

            if (info.References != null)
            {
                foreach (JobApplicationReferenceInfo model in info.References)
                {
                    context.JobApplicationReferences.Add(new JobApplicationReference()
                    {
                        ID = Guid.NewGuid(),
                        JobApplicationID = info.ID,
                        Name = model.Name,
                        Occupation = model.Occupation,
                        YearsKnown = model.YearsKnown,
                        Address = model.Address,
                        Employer = model.Employer,
                        HomeNumber = model.HomeNumber,
                        MobileNumber = model.MobileNumber,
                        OfficeNumber = model.OfficeNumber
                    });
                }
            }
            #endregion

            #region Working History
            var workingHistories = (from item in context.JobApplicationWorkingHistories
                                    where item.JobApplicationID == info.ID
                                    select item);
            foreach (JobApplicationWorkingHistory item in workingHistories)
            {
                context.JobApplicationWorkingHistories.Remove(item);
            }

            if (info.WorkingHistories != null)
            {
                foreach (JobApplicationWorkingHistoryInfo model in info.WorkingHistories)
                {
                    context.JobApplicationWorkingHistories.Add(new JobApplicationWorkingHistory()
                    {
                        ID = Guid.NewGuid(),
                        JobApplicationID = info.ID,
                        StartDate = model.StartDate,
                        EndDate = model.EndDate,
                        Company = model.Company,
                        Country = model.Country,
                        LastPositionHeld = model.LastPositionHeld,
                        NameOfSuperior = model.NameOfSuperior,
                        DesignationOfSuperior = model.DesignationOfSuperior,
                        LastDrawnSalary = Cryptography.Encryption(model.LastDrawnSalary.GetValueOrDefault().ToString("#,##")),
                        ReasonForLeaving = model.ReasonForLeaving
                    });
                }
            }
            #endregion
        }

        public PreBoardingInfo GetPreBoardingInfo(Guid userID)
        {
            var preBoardingInfo = (from item in context.PreBoardingInformations
                                   join jobApp in context.JobApplications on item.UserID equals jobApp.UserID
                                   where item.UserID == userID && item.IsDeleted == false
                                   && jobApp.UserID == userID && jobApp.IsDeleted == false
                                   select new PreBoardingInfo()
                                   {
                                       ID = item.ID,
                                       UserID = item.UserID,
                                       FirstName = jobApp.FirstName,
                                       LastName = jobApp.LastName,
                                       Position = item.Position,
                                       BuddyName = item.BuddyName,
                                       HRContactPerson = item.HRContactPerson,
                                       Supervisor = item.Supervisor,
                                       Department = item.Department,
                                       JoinDate = item.JoinDate,
                                       RecruiterName = item.RecruiterName
                                   }).FirstOrDefault();
            return preBoardingInfo;
        }

        public MessageInfo GetNotificationData(Guid jobID)
        {
            var notifInfo = (from jobApp in context.JobApplications
                             join item in context.PreBoardingInformations on jobApp.UserID equals item.UserID
                             join user in context.Users on item.UserID equals user.ID
                             where jobApp.ID == jobID && item.IsDeleted == false && user.IsDeleted == false
                             && jobApp.IsDeleted == false
                             select new MessageInfo()
                             {
                                 UserID = item.UserID,
                                 FirstName = jobApp.FirstName,
                                 LastName = jobApp.LastName,
                                 Position = item.Position,
                                 JoinDate = item.JoinDate,
                                 RecruiterName = item.RecruiterName,
                                 DeviceToken = user.DeviceToken
                             }).FirstOrDefault();
            return notifInfo;
        }

        public MessageInfo GetRejectNotificationData(Guid jobID)
        {
            var notifInfo = (from jobApp in context.JobApplications
                             join user in context.Users on jobApp.UserID equals user.ID
                             where jobApp.ID == jobID && user.IsDeleted == false
                             && jobApp.IsDeleted == false
                             select new MessageInfo()
                             {
                                 UserID = jobApp.UserID,
                                 FirstName = jobApp.FirstName,
                                 LastName = jobApp.LastName,
                                 DeviceToken = user.DeviceToken
                             }).FirstOrDefault();
            return notifInfo;
        }
    }
}
