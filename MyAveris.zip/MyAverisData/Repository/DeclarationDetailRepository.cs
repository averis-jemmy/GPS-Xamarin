﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyAverisEntity;

namespace MyAverisData
{
    public class DeclarationDetailRepository : RepositoryBase<DeclarationDetail>
    {
        public DeclarationDetailRepository(AverisMobileDb context) : base(context) { }

        public List<DeclarationDetailInfo> GetDeclarationDetails()
        {
            var declarations = (from item in GetAll()
                                where item.IsDeleted == false
                                select new DeclarationDetailInfo()
                                {
                                    ID = item.ID,
                                    No = item.No,
                                    Declaration = item.Declaration
                                });

            return declarations.ToList();
        }
    }
}
