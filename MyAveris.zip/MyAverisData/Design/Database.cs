﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisData
{
    public class Database
    {
        public static AverisMobileDb Instant
        {
            get
            {
                return new AverisMobileDb();
            }
        }
    }
}
