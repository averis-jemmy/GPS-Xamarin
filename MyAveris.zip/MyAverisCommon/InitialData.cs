﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisCommon
{
    public static class InitialData
    {
        public static class NotificationType
        {
            public const string Sms = "SMS";
            public const string Notification = "NOTIFICATION";
        }

        public static class AddressType
        {
            public const string CurrentAddress = "CURRENT";
            public const string HomeAddress = "HOME";
            public const string EmergencyAddress = "EMERGENCY";
        }

        public static class ApplicationStatus
        {
            public const string New = "DRAFT";
            public const string Submitted = "PROCESSING";
            public const string Accepted = "SUCCESSFUL";
            public const string Rejected = "UNSUCCESSFUL";
            public const string KIV = "KIV";
        }

        public static class DeviceType
        {
            public const string Android = "ANDROID";
            public const string IOS = "IOS";
        }

        public static List<KeyValuePair<string, byte>> GetLanguageAbilities()
        {
            return new List<KeyValuePair<string, byte>>()
            {
                new KeyValuePair<string, byte>("AVERAGE", 1),
                new KeyValuePair<string, byte>("GOOD", 2),
                new KeyValuePair<string, byte>("EXCELLENT", 3)
            };
        }
    }
}
