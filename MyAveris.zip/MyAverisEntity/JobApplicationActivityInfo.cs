﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationActivityInfo
    {
        public Guid ID { get; set; }
        public Guid UID { get; set; }
        public Guid? JobApplicationID { get; set; }
        public string Organisation { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Country { get; set; }
        public string NatureOfActivities { get; set; }
    }
}
