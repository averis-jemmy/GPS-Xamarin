﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationPackageDetailInfo
    {
        public Guid ID { get; set; }
        public Guid? JobApplicationID { get; set; }
        public string EPFNumber { get; set; }
        public string SOCSONumber { get; set; }
        public string IncomeTaxNumber { get; set; }
        public string BankAccountNumber { get; set; }
        public string BaseSalary { get; set; }
        public string ExpectedSalary { get; set; }
        public string ContractualBonus { get; set; }
        public string PerformanceBonus { get; set; }
        public string HousingAllowance { get; set; }
        public string TransportAllowance { get; set; }
        public string ConnectivityAllowance { get; set; }
        public string ProjectAlowance { get; set; }
        public string SpecialSkillsAllowance { get; set; }
        public string CarParkAllowance { get; set; }
        public string CarParkClaim { get; set; }
        public string PhoneClaim { get; set; }
        public string MileageClaim { get; set; }
        public string MealClaim { get; set; }
        public string OvertimeClaim { get; set; }
        public string StandbyClaim { get; set; }
        public string SelfMedicalBenefit { get; set; }
        public string FamilyMedicalBenefit { get; set; }
        public string SelfInsuranceBenefit { get; set; }
        public string FamilyInsuranceBenefit { get; set; }
        public string DentalBenefit { get; set; }
        public string OpticalBenefit { get; set; }
        public string RetirementBenefit { get; set; }
        public string AnnualLeave { get; set; }
        public string MedicalLeave { get; set; }
    }
}
