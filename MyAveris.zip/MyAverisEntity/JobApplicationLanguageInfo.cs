﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationLanguageInfo
    {
        public Guid ID { get; set; }
        public Guid UID { get; set; }
        public Guid? JobApplicationID { get; set; }
        public string Language { get; set; }
        public byte? ReadAbility { get; set; }
        public byte? WriteAbility { get; set; }
        public byte? SpeakAbility { get; set; }
    }
}
