﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class DeclarationDetailInfo
    {
        public Guid ID { get; set; }
        public byte? No { get; set; }
        public string Declaration { get; set; }
    }
}
