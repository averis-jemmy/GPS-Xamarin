﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationWorkingHistoryInfo
    {
        public Guid ID { get; set; }
        public Guid UID { get; set; }
        public Guid? JobApplicationID { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Company { get; set; }
        public string Country { get; set; }
        public string LastPositionHeld { get; set; }
        public string NameOfSuperior { get; set; }
        public string DesignationOfSuperior { get; set; }
        public decimal? LastDrawnSalary { get; set; }
        public string ReasonForLeaving { get; set; }
    }
}
