﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationDeclarationInfo
    {
        public Guid ID { get; set; }
        public Guid? JobApplicationID { get; set; }
        public Guid? DeclarationID { get; set; }
        public string DeclarationDetail { get; set; }
        public bool? Answer { get; set; }
        public string Remarks { get; set; }
    }
}
