﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationReferenceInfo
    {
        public Guid ID { get; set; }
        public Guid? JobApplicationID { get; set; }
        public string Name { get; set; }
        public string Occupation { get; set; }
        public byte? YearsKnown { get; set; }
        public string Address { get; set; }
        public string Employer { get; set; }
        public string HomeNumber { get; set; }
        public string MobileNumber { get; set; }
        public string OfficeNumber { get; set; }
    }
}
