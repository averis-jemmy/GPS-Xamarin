﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationInfo
    {
        public Guid ID { get; set; }
        public Guid? UserID { get; set; }
        public byte[] Photo { get; set; }
        public string Title { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string KnownAs { get; set; }
        public string ChineseCharacter { get; set; }
        public string Gender { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string CountryOfBirth { get; set; }
        public string Nationality { get; set; }
        public string Race { get; set; }
        public string MaritalStatus { get; set; }
        public string Religion { get; set; }
        public string IdentityNo { get; set; }
        public bool? IsPassport { get; set; }
        public DateTime? DateOfIssue { get; set; }
        public DateTime? DateOfExpiry { get; set; }
        public string CountryOfIssue { get; set; }
        public string EmailAddress { get; set; }
        public string EmergencyContact { get; set; }
        public DateTime? ServiceCompleted { get; set; }
        public string HighestRankAttained { get; set; }
        public string ExemptionReason { get; set; }
        public bool? LiabilityForDuties { get; set; }
        public string ApplicationStatus { get; set; }
        public bool? IsLocked { get; set; }
        public bool? IsDeleted { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? UpdatedDate { get; set; }

        public JobApplicationAddressInfo CurrentAddress { get; set; }
        public JobApplicationAddressInfo HomeAddress { get; set; }
        public JobApplicationAddressInfo EmergencyAddress { get; set; }
        public JobApplicationPackageDetailInfo PackageDetail { get; set; }

        public List<JobApplicationActivityInfo> Activities { get; set; }
        public List<JobApplicationDeclarationInfo> Declarations { get; set; }
        public List<JobApplicationEducationInfo> Educations { get; set; }
        public List<JobApplicationFamilyInfo> Families { get; set; }
        public List<JobApplicationLanguageInfo> Languages { get; set; }
        public List<JobApplicationReferenceInfo> References { get; set; }
        public List<JobApplicationWorkingHistoryInfo> WorkingHistories { get; set; }
    }
}
