﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class ShortJobApplicationInfo
    {
        public Guid ID { get; set; }
        public Guid? UserID { get; set; }
        public string FullName { get; set; }
        public string PositionApplied { get; set; }
        public string ApplicationStatus { get; set; }
        public bool? IsLocked { get; set; }
    }
}
