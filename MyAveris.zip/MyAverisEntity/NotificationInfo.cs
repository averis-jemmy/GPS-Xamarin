﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class NotificationInfo
    {
        public Guid ID { get; set; }
        public Guid? UserID { get; set; }
        public string Title { get; set; }
        public string Message { get; set; }
        public string NotificationType { get; set; }
        public string DeviceToken { get; set; }
        public string MobileNumber { get; set; }
    }
}
