﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisEntity
{
    public class JobApplicationEducationInfo
    {
        public Guid ID { get; set; }
        public Guid UID { get; set; }
        public Guid? JobApplicationID { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Institution { get; set; }
        public string Country { get; set; }
        public string Qualification { get; set; }
        public string CourseOfStudy { get; set; }
    }
}
