﻿using MyAverisCommon;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyAverisEncryptor
{
    public partial class FormEncrypt : Form
    {
        public FormEncrypt()
        {
            InitializeComponent();
        }

        private void btnEncrypt_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtMessage.Text))
                txtEncryptedMessage.Text = Cryptography.Encryption(txtMessage.Text);
            else
                txtEncryptedMessage.Text = string.Empty;
        }
    }
}
