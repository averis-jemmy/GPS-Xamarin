﻿using MyAverisCommon;
using MyAverisData;
using MyAverisEntity;
using MyAverisWorkerCommon;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Net.Security;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisNotificationWorker
{
    public class NotificationWorker : WorkerBase
    {
        enum MethodReturnCode { Success, UnknownError, ConnectionError, DatabaseError }

        public override void Run()
        {
            this.Status = WorkerStatus.Running;
            ServicePointManager.ServerCertificateValidationCallback =
                delegate(System.Object obj, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
                {
                    return (true);
                };
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls | SecurityProtocolType.Tls11 | SecurityProtocolType.Tls12;
            DoWork();
            this.Status = WorkerStatus.Stopped;
        }

        private void DoWork()
        {
            try
            {
                NotificationRepository notifRep = new NotificationRepository(Database.Instant);
                List<NotificationInfo> notifications = notifRep.GetPendingNotifications();

                if (notifications != null)
                {
                    foreach (NotificationInfo info in notifications)
                    {
                        try
                        {
                            if (info.NotificationType == InitialData.NotificationType.Sms)
                                SendSms(info);
                            if (info.NotificationType == InitialData.NotificationType.Notification)
                                SendNotification(info);
                        }
                        catch(Exception ex)
                        {
                            WriteExceptionLog(ex);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteExceptionLog(ex);
            }
        }

        private void SendSms(NotificationInfo info)
        {
            NotificationRepository notifRep = new NotificationRepository(Database.Instant);
            string result = HttpSubmit.HttpGet(ConfigurationManager.AppSettings["SmsGatewayUrl"],
                                "+" + info.MobileNumber, info.Message);

            if (!result.Contains("ErrorMessage"))
            {
                notifRep.UpdateSentStatus(info.ID);
            }
        }

        private void SendNotification(NotificationInfo info)
        {
            NotificationRepository notifRep = new NotificationRepository(Database.Instant);
            if (!string.IsNullOrEmpty(info.DeviceToken))
            {
                var API_KEY = ConfigurationManager.AppSettings["GcmApiKey"];

                var jGcmData = new JObject();
                var jData = new JObject();

                jData.Add("title", info.Title);
                jData.Add("message", info.Message.Trim());

                if (!string.IsNullOrEmpty(info.DeviceToken))
                {
                    jGcmData.Add("to", info.DeviceToken.Trim());
                }
                else
                {
                    jGcmData.Add("to", "/topics/averis");
                }

                jGcmData.Add("data", jData);

                var url = new Uri(ConfigurationManager.AppSettings["GoogleGcmUrl"]);

                if (bool.Parse(ConfigurationManager.AppSettings["UseProxy"]))
                {
                    // First create a proxy object
                    string proxyServer = ConfigurationManager.AppSettings["ProxyServer"];
                    string proxyPort = ConfigurationManager.AppSettings["ProxyPort"];
                    string userName = Cryptography.Decryption(ConfigurationManager.AppSettings["UserName"]);
                    string password = Cryptography.Decryption(ConfigurationManager.AppSettings["Password"]);

                    string proxyUri = string.Format("{0}:{1}", proxyServer, proxyPort);

                    NetworkCredential proxyCreds = new NetworkCredential(userName, password);
                    WebProxy proxy = new WebProxy(proxyUri, false)
                    {
                        UseDefaultCredentials = false,
                        Credentials = proxyCreds,
                    };

                    // Now create a client handler which uses that proxy
                    HttpClientHandler httpClientHandler = new HttpClientHandler()
                    {
                        Proxy = proxy,
                        PreAuthenticate = true,
                        UseDefaultCredentials = false,
                    };

                    // You only need this part if the server wants a username and password:
                    httpClientHandler.Credentials = new NetworkCredential(userName, password);
                    using (var client = new HttpClient(httpClientHandler))
                    {
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "key=" + API_KEY);

                        Task.WaitAll(client.PostAsync(url, new StringContent(jGcmData.ToString(), Encoding.Default, "application/json")).ContinueWith(response =>
                        {
                            if (response.Result.StatusCode == HttpStatusCode.OK)
                            {
                                notifRep.UpdateSentStatus(info.ID);
                            }
                        }));

                        //var response = client.PostAsync(url, new StringContent(jGcmData.ToString(), Encoding.Default, "application/json")).Result;
                        //var responseValue = string.Empty;
                        //if (response != null && response.StatusCode == HttpStatusCode.OK)
                        //{
                        //    Task task = response.Content.ReadAsStreamAsync().ContinueWith(t =>
                        //    {
                        //        var stream = t.Result;
                        //        using (var reader = new StreamReader(stream))
                        //        {
                        //            responseValue = reader.ReadToEnd();
                        //        }
                        //    });

                        //    task.Wait();

                        //    JObject result;

                        //    try
                        //    {
                        //        result = (JObject)JsonConvert.DeserializeObject(responseValue);
                        //        JArray results = ((JArray)result.SelectToken("results", false));
                        //        if (results != null && results != null && results.Count > 0)
                        //        {
                        //            try
                        //            {
                        //                JToken error = results[0].SelectToken("error", false);
                        //                if (error == null)
                        //                    notifRep.UpdateSentStatus(info.ID);
                        //            }
                        //            catch { }
                        //        }
                        //    }
                        //    catch { }
                        //}
                    }
                }
                else
                {
                    using (var client = new HttpClient())
                    {
                        client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                        client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "key=" + API_KEY);
                        Task.WaitAll(client.PostAsync(url, new StringContent(jGcmData.ToString(), Encoding.Default, "application/json")).ContinueWith(response =>
                        {
                            if (response.Result.StatusCode == HttpStatusCode.OK)
                                notifRep.UpdateSentStatus(info.ID);
                        }));
                    }
                }
            }
            else
                notifRep.UpdateSentStatus(info.ID);
        }
    }
}
