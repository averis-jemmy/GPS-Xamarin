﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace MyAverisNotificationWorker
{
    public static class HttpSubmit
    {
        public static string HttpGet(string httpUrl, string phoneNumber, string message)
        {
            string content = "tar_num=" + HttpUtility.UrlEncode(phoneNumber) + "&tar_msg=" + HttpUtility.UrlEncode(message);
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(httpUrl + "?" + content);
            request.Method = "GET";

            try
            {
                using (var response = (HttpWebResponse)request.GetResponse())
                {
                    var responseValue = string.Empty;
                    using (var responseStream = response.GetResponseStream())
                    {
                        if (responseStream != null)
                        {
                            using (var reader = new StreamReader(responseStream))
                            {
                                responseValue += reader.ReadToEnd();
                            }
                        }
                    }

                    return responseValue;
                }
            }
            catch (Exception ex)
            {
                return "ErrorMessage - " + ex.Message;
            }
        }
    }
}
