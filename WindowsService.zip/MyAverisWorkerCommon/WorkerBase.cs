﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisWorkerCommon
{
    public class WorkerBase : IWorker
    {
        public WorkerStatus Status { get; set; }
        public string LogFile { get; set; }

        public WorkerBase()
        {
            this.Status = WorkerStatus.Stopped;
        }

        public virtual void Run()
        {

        }

        public void WriteLog(string content)
        {
            try
            {
                File.AppendAllText(LogFile, string.Format("\r\n===================={0}====================\r\n", DateTime.Now));
                File.AppendAllText(LogFile, content);
            }
            catch { }
        }

        public void WriteExceptionLog(Exception ex)
        {
            try
            {
                File.AppendAllText(LogFile, string.Format("\r\n===================={0}====================\r\n", DateTime.Now));
                File.AppendAllText(LogFile, ex.Message + "\t" + ex.StackTrace);
            }
            catch { }
        }
    }
}
