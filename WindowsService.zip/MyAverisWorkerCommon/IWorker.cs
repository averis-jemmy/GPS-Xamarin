﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisWorkerCommon
{
    public interface IWorker
    {
        WorkerStatus Status { get; set; }
        string LogFile { get; set; }

        void Run();
    }
}
