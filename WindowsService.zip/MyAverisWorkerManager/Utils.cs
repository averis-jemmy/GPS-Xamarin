﻿using MyAverisWorkerCommon;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace MyAverisWorkerManager
{
    public class Utils
    {
        /// <summary>
        /// Load Worker Setting from XML file (defined in app.config)
        /// </summary>
        /// <returns></returns>
        public static List<WorkerSetting> LoadWorkerSettings()
        {
            List<WorkerSetting> lst = new List<WorkerSetting>();

            string workerSettingFileName = ConfigurationManager.AppSettings["WorkerSettingFile"];
            string workerSettingFile = string.Format(@"{0}\{1}", GetWorkingDirectory(), workerSettingFileName);
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(workerSettingFile);

                XmlNodeList nodes = doc.SelectNodes("//Worker");
                foreach (XmlNode node in nodes)
                {
                    try
                    {
                        WorkerSetting workerSetting = new WorkerSetting();
                        workerSetting.Name = node.Attributes["Name"].Value;
                        workerSetting.Library = node.Attributes["Library"].Value;
                        workerSetting.Class = node.Attributes["Class"].Value;
                        workerSetting.LogFile = node.Attributes["LogFile"].Value;
                        workerSetting.Enabled = node.Attributes["Enabled"].Value.ToLower() == "true";

                        switch (node.Attributes["Type"].Value)
                        {
                            case "Daily":
                                workerSetting.Type = TaskType.Daily;
                                break;
                            case "Monthly":
                                workerSetting.Type = TaskType.Monthly;
                                break;
                            case "Weekly":
                                workerSetting.Type = TaskType.Weekly;
                                break;
                            case "Time":
                            default:
                                workerSetting.Type = TaskType.Time;
                                break;
                        }

                        workerSetting.StartAt = DateTime.ParseExact(node.Attributes["StartAt"].Value, "dd/MM/yyyy HH:mm:ss", null);
                        workerSetting.Duration = Convert.ToDateTime(node.Attributes["Duration"].Value);

                        lst.Add(workerSetting);
                    }
                    catch (Exception ex)
                    {
                        WriteLog(ex.Message);
                        WriteLog(ex.StackTrace);
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog(ex.Message);
                WriteLog(ex.StackTrace);
            }

            return lst;
        }

        public static List<WorkerTaskScheduler> LoadWorkerTaskShedulers()
        {
            List<WorkerTaskScheduler> tasks = new List<WorkerTaskScheduler>();

            List<WorkerSetting> workerSettings = Utils.LoadWorkerSettings();

            foreach (WorkerSetting workerSetting in workerSettings)
            {
                if (workerSetting.Enabled)
                {
                    WorkerTaskScheduler workerTask = new WorkerTaskScheduler();
                    workerTask.Worker = InitWorkerObject(workerSetting.Library, workerSetting.Class);

                    if (workerTask.Worker != null)
                    {
                        workerTask.RepeatOn = workerSetting.Type;
                        workerTask.StartAt = workerSetting.StartAt;
                        workerTask.Duration = workerSetting.Duration;
                        workerTask.LogFile = string.Format(@"{0}\{1}", ConfigurationManager.AppSettings["GlobalLogFolder"], workerSetting.LogFile);
                        workerTask.Worker.LogFile = workerTask.LogFile;
                        workerTask.WorkerName = workerSetting.Name;

                        tasks.Add(workerTask);
                    }
                }
            }

            return tasks;
        }

        public static IWorker InitWorkerObject(string lib, string className)
        {
            try
            {
                System.Reflection.Assembly o = System.Reflection.Assembly.LoadFile(string.Format(@"{0}\{1}", GetWorkingDirectory(), lib));

                Type type = o.GetType(className);

                object obj = Activator.CreateInstance(type);

                if (obj is IWorker)
                {
                    return (IWorker)obj;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                Utils.WriteLog(string.Format("Failed to Create Object from class {0}", className));

                throw ex;
            }
        }

        /// <summary>
        /// Write log to file, define in app.config [GlobalLogFile]
        /// </summary>
        /// <param name="contents"></param>
        public static void WriteLog(string contents)
        {
            try
            {
                string globalLogFile = string.Format(@"{0}\WorkerManager.log", ConfigurationManager.AppSettings["GlobalLogFolder"]);
                File.AppendAllText(globalLogFile, string.Format("\r\n============={0}=======================\r\n", DateTime.Now));
                File.AppendAllText(globalLogFile, contents);
            }
            catch { }
        }

        /// <summary>
        /// Return Application Working Dir
        /// </summary>
        /// <returns></returns>
        public static string GetWorkingDirectory()
        {
            return Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory);
        }
    }
}
