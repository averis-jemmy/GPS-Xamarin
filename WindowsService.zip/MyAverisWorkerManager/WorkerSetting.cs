﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MyAverisWorkerManager
{
    public class WorkerSetting
    {
        public string Name { get; set; }
        public string Library { get; set; }
        public string Class { get; set; }
        public TaskType Type { get; set; }
        public DateTime StartAt { get; set; }
        public DateTime Duration { get; set; }
        public string LogFile { get; set; }
        public bool Enabled { get; set; }
    }
}
