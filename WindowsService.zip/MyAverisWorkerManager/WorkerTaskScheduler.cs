﻿using MyAverisWorkerCommon;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace MyAverisWorkerManager
{
    public enum TaskType { Daily, Weekly, Monthly, Time }

    /// <summary>
    /// 
    /// </summary>
    public class WorkerTaskScheduler
    {
        public TaskType RepeatOn { get; set; }
        public DateTime StartAt { get; set; }
        public DateTime Duration { get; set; }
        public IWorker Worker { get; set; }
        public string LogFile { get; set; }
        public string WorkerName { get; set; }

        Thread thread = null;
        System.Timers.Timer timer = null;

        DateTime nextRun;

        /// <summary>
        /// Constructor
        /// </summary>
        public WorkerTaskScheduler()
        {
            timer = new System.Timers.Timer();
            timer.Interval = 1000;
            timer.Elapsed += new System.Timers.ElapsedEventHandler(timer_Elapsed);
        }

        /// <summary>
        /// Init object and timer.
        /// </summary>
        public void Start()
        {
            InitForNextRun();

            timer.Start();
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        void timer_Elapsed(object sender, System.Timers.ElapsedEventArgs e)
        {
            if (thread == null || Worker.Status == WorkerStatus.Stopped)
            {
                timer.Stop();

                if (DateTime.Now > nextRun)
                    Run();

                timer.Start();
            }

            CalculateForNextRun();
        }

        private void Run()
        {
            ThreadStart start = new ThreadStart(Worker.Run);
            thread = new Thread(start);
            thread.Start();
        }

        /// <summary>
        /// Force stop TaskScheduler
        /// </summary>
        public void Stop()
        {
            try
            {
                if (timer != null
                    && timer.Enabled)
                {
                    timer.Stop();
                }

                if (thread != null
                    && thread.ThreadState == ThreadState.Running)
                {
                    thread.Abort();
                }
            }
            catch (Exception ex)
            {
                Utils.WriteLog(ex.Message);
                Utils.WriteLog(ex.StackTrace);
            }
        }

        /// <summary>
        /// 
        /// </summary>
        private void CalculateForNextRun()
        {
            DateTime now = DateTime.Now;

            if (now > nextRun)
            {
                switch (RepeatOn)
                {
                    case TaskType.Monthly:
                        nextRun = nextRun.AddMonths(1);
                        break;
                    case TaskType.Daily:
                        nextRun = nextRun.AddDays(1);
                        break;
                    case TaskType.Weekly:
                        nextRun = nextRun.AddDays(7);
                        break;
                    case TaskType.Time:
                        nextRun = nextRun.AddSeconds(Duration.Hour * 3600 + Duration.Minute * 600 + Duration.Second);
                        break;
                }
            }
        }


        private void InitForNextRun()
        {
            DateTime now = DateTime.Now;

            switch (RepeatOn)
            {
                case TaskType.Monthly:

                    nextRun = new DateTime(now.Year, StartAt.Month, StartAt.Day, StartAt.Hour, StartAt.Minute, StartAt.Second);

                    if (now > nextRun)
                    {
                        nextRun = nextRun.AddMonths(1);
                    }

                    break;
                case TaskType.Daily:
                    nextRun = new DateTime(now.Year, now.Month, now.Day, StartAt.Hour, StartAt.Minute, StartAt.Second);

                    if (now > nextRun)
                    {
                        nextRun = nextRun.AddDays(1);
                    }

                    break;
                case TaskType.Weekly:
                    nextRun = new DateTime(now.Year, now.Month, now.Day, StartAt.Hour, StartAt.Minute, StartAt.Second);

                    if (now > nextRun)
                    {
                        nextRun = nextRun.AddDays(1);
                    }

                    while (StartAt.DayOfWeek != nextRun.DayOfWeek)
                    {
                        nextRun = nextRun.AddDays(1);
                    }

                    break;
                case TaskType.Time:
                    nextRun = now.AddSeconds(Duration.Hour * 3600 + Duration.Minute * 600 + Duration.Second);
                    break;
            }
        }
    }
}
