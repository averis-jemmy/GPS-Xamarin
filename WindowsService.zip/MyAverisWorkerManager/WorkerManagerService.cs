﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace MyAverisWorkerManager
{
    public partial class WorkerManagerService : ServiceBase
    {
        List<WorkerTaskScheduler> taskShedulers = null;
        Timer timer;

        public WorkerManagerService()
        {
            InitializeComponent();

            timer = new Timer();
            timer.Interval = 1000;
            timer.Elapsed += new ElapsedEventHandler(timer_Elapsed);
        }

        System.Reflection.Assembly CurrentDomain_AssemblyResolve(object sender, ResolveEventArgs args)
        {
            return args.RequestingAssembly;
        }

        protected override void OnStart(string[] args)
        {
            System.Threading.Thread.Sleep(10000);

            try
            {
                taskShedulers = Utils.LoadWorkerTaskShedulers();

                foreach (WorkerTaskScheduler task in taskShedulers)
                {
                    try
                    {
                        task.Start();
                        Utils.WriteLog("Start:" + task.WorkerName);
                    }
                    catch (Exception ex)
                    {
                        Utils.WriteLog(ex.Message);
                        Utils.WriteLog(ex.StackTrace);
                    }
                }
            }
            catch (Exception ex)
            {
                Utils.WriteLog(ex.Message);
                Utils.WriteLog(ex.StackTrace);
            }
        }

        void timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            Utils.WriteLog("WorkerManager is running");
        }

        protected override void OnStop()
        {
            if (taskShedulers != null)
            {
                foreach (WorkerTaskScheduler task in taskShedulers)
                {
                    try
                    {
                        task.Stop();
                    }
                    catch (Exception ex)
                    {
                        Utils.WriteLog(ex.Message);
                        Utils.WriteLog(ex.StackTrace);
                    }
                }

                timer.Stop();
            }
        }
    }
}
