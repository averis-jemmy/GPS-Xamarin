﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using ServicesController.Classes;

namespace ServicesController.UserControls
{
    public partial class CommonControl : UserControl
    {
        public CommonControl()
        {
            InitializeComponent();
            InitData();
        }

        private void InitData()
        {
            InitTaskType();

        }

        private void InitTaskType()
        {
            List<string> lst = new List<string>();
            lst.Add(TaskType.Daily.ToString());
            lst.Add(TaskType.Monthly.ToString());
            lst.Add(TaskType.Weekly.ToString());
            lst.Add(TaskType.Time.ToString());

            cboType.DataSource = lst;
        }

        public void SetValue(WorkerInfo workerInfo)
        {
            dtpStartDate.Text = workerInfo.StartDate;
            dtpStartTime.Text = workerInfo.StartTime;
            dtpDuration.Text = workerInfo.Duration;

            txtLogFile.Text = workerInfo.LogFile;

            if (workerInfo.Enabled == "True")
            {
                rdEnable.Checked = true;
            }
            else
            {
                rdDisable.Checked = true;
            }

            cboType.Text = workerInfo.TaskType;
        }

        public WorkerInfo GetValue()
        {
            var workerInfo = new WorkerInfo();

            workerInfo.LogFile = txtLogFile.Text;
            workerInfo.Enabled = rdEnable.Checked ? "True" : "False";
            workerInfo.TaskType = cboType.Text;
            workerInfo.StartAt = string.Format("{0} {1}", dtpStartDate.Value.ToString(Common.DateTimeFormat.SHORT_DATE), dtpStartTime.Value.ToString(Common.DateTimeFormat.TIME));
            workerInfo.StartTime = dtpStartTime.Value.ToString(Common.DateTimeFormat.TIME);
            workerInfo.Duration = dtpDuration.Value.ToString(Common.DateTimeFormat.TIME);

            return workerInfo;
        }

        private void cboType_SelectedIndexChanged(object sender, EventArgs e)
        {
            var combobox = sender as ComboBox;
            if (combobox != null)
            {
                string taskType = (string)combobox.SelectedItem;
                if (taskType == TaskType.Time.ToString())
                {
                    dtpDuration.Enabled = true;
                    dtpStartTime.Enabled = false;
                }
                else
                {
                    dtpDuration.Enabled = false;
                    dtpStartTime.Enabled = true;
                }
            }
        }
    }
}
