﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.ServiceProcess;
using System.Threading;
using ServicesController.Classes;
using System.Xml;
using ServicesController.UserControls;

namespace ServicesController
{
    public partial class Form1 : Form
    {
        BackgroundWorker bg = null;
        Form2 frmStatus = null;
        bool isStart = false;
        List<WorkerInfo> LstWorkers = new List<WorkerInfo>();
        List<CommonControl> userControl = new List<CommonControl>();

        public Form1()
        {
            InitializeComponent();
            InitData();
            treeView.ExpandAll();
            treeView.SelectedNode = treeView.Nodes[Common.ServiceName.SERVICES].Nodes[0];
        }

        private void InitData()
        {
            try
            {
                LstWorkers = Utils.LoadWorkerInfos();

                for (int i = 0; i < LstWorkers.Count; i++)
                {
                    treeView.Nodes[Common.ServiceName.SERVICES].Nodes.Add(LstWorkers[i].Name);

                    tabControl.TabPages.Add(LstWorkers[i].Name);

                    CommonControl tempCtrl = new CommonControl();
                    tempCtrl.Location = new Point(3, 5);
                    tempCtrl.SetValue(LstWorkers[i]);
                    userControl.Add(tempCtrl);
                    tabControl.TabPages[i].Controls.Add(userControl[i]);
                }
            }
            catch { }
        }

        private void btnStop_Click(object sender, EventArgs e)
        {
            try
            {
                isStart = false;
            bg = new BackgroundWorker();
            bg.DoWork += new DoWorkEventHandler(bg_DoWork);
            bg.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bg_RunWorkerCompleted);
            bg.RunWorkerAsync();

            frmStatus = new Form2();
            frmStatus.ShowDialog();
            }
            catch { }
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            try
            {
                SaveConfigFile();

                isStart = true;
                bg = new BackgroundWorker();
                bg.DoWork += new DoWorkEventHandler(bg_DoWork);
                bg.RunWorkerCompleted += new RunWorkerCompletedEventHandler(bg_RunWorkerCompleted);
                bg.RunWorkerAsync();

                frmStatus = new Form2();
                frmStatus.ShowDialog();
            }
            catch { }
        }

        void bg_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            frmStatus.Close();
            frmStatus.Dispose();
        }

        void bg_DoWork(object sender, DoWorkEventArgs e)
        {
            StartService();
        }

        private void StartService()
        {
            try
            {
                ServiceController myService = new ServiceController();
                myService.ServiceName = "WorkerManagerService";
                string svcStatus = myService.Status.ToString();

                if (isStart)
                {
                    if (svcStatus == "Stopped")
                    {
                        myService.Start();
                        myService.WaitForStatus(ServiceControllerStatus.Running);
                    }
                }
                else
                {
                    if (svcStatus == "Running")
                    {
                        myService.Stop();
                        myService.WaitForStatus(ServiceControllerStatus.Stopped);
                        Thread.Sleep(2000);
                    }
                }
            }
            catch { }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SaveConfigFile();

            MessageBox.Show("The config file was saved successfully", "Service Control Manager", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void SaveConfigFile()
        {
            try
            {
                string workerSettingFile = string.Format(@"{0}\{1}", Utils.GetWorkingDirectory(), Common.WORKING_FILE_NAME);

                //Here is the variable with which you assign a new value to the attribute

                XmlDocument xmlDoc = new XmlDocument();

                xmlDoc.Load(workerSettingFile);
                XmlNodeList nodes = xmlDoc.SelectNodes("//Worker");
                
                for (int i = 0; i < nodes.Count; i++)
                {
                    UpdateNod(nodes[i], userControl[i]);
                }
                
                xmlDoc.Save(workerSettingFile);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Service Control Manager", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            LstWorkers = Utils.LoadWorkerInfos();
        }

        private void UpdateNod(XmlNode node, CommonControl control)
        {
            WorkerInfo workerInfo = control.GetValue();
            node.Attributes["Type"].Value = workerInfo.TaskType;
            node.Attributes["StartAt"].Value = workerInfo.StartAt;
            node.Attributes["Duration"].Value = workerInfo.Duration;
            node.Attributes["LogFile"].Value = workerInfo.LogFile;
            node.Attributes["Enabled"].Value = workerInfo.Enabled;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            ServiceController myService = new ServiceController();
            myService.ServiceName = "WorkerManagerService";
            string svcStatus = myService.Status.ToString();

            if (svcStatus == "Stopped")
            {
                btnStop.Enabled = false;
                btnStart.Enabled = true;
                btnSave.Enabled = true;
            }
            else if (svcStatus == "Running")
            {
                btnStart.Enabled = false;
                btnStop.Enabled = true;
                btnSave.Enabled = false;
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void treeView_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Name == Common.ServiceName.SERVICES)
                return;

            tabControl.SelectedIndex = e.Node.Index;
        }

        private void Form1_Resize(object sender, EventArgs e)
        {
            if (FormWindowState.Minimized == this.WindowState)
            {
                notifyIcon.Visible = true;
                notifyIcon.ShowBalloonTip(500);
                this.Hide();
            }
            else if (FormWindowState.Normal == this.WindowState)
            {
                notifyIcon.Visible = false;
            }
        }

        private void notifyIcon_DoubleClick(object sender, EventArgs e)
        {
            OpenApp();
        }

        private void OpenApp()
        {
            notifyIcon.Visible = false;
            this.Show();
            this.WindowState = FormWindowState.Normal;
        }

        private void notifyIcon_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Right)
            {
                contextMenuStrip.Show(Control.MousePosition);
            }
        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {
            OpenApp();
        }

        private void toolStripMenuItem2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private DialogResult CheckingDataChanged(bool isFormClose)
        {
            return DialogResult.OK;
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            var result = CheckingDataChanged(true);

            if (result == DialogResult.Cancel)
            {
                e.Cancel = true;
            }
        }
    }
}
