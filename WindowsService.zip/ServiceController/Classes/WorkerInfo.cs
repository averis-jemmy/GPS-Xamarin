﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServicesController.Classes
{
    public class WorkerInfo : IEquatable<WorkerInfo>
    {
        public string Name { get; set; }
        public string Library { get; set; }
        public string Class { get; set; }
        public string TaskType { get; set; }
        public string StartAt { get; set; }
        public string StartDate { get; set; }
        public string StartTime { get; set; }
        public string Duration { get; set; }
        public string LogFile { get; set; }
        public string Enabled { get; set; }

        public bool Equals(WorkerInfo other)
        {
            return other.TaskType == TaskType
                && other.StartTime == StartTime
                && other.Duration == Duration
                && other.LogFile == LogFile
                && other.Enabled == Enabled;
        }

        
    }
}
