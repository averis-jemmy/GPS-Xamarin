﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using System.Xml;

namespace ServicesController.Classes
{
    public class Utils
    {
        /// <summary>
        /// Return Application Working Dir
        /// </summary>
        /// <returns></returns>
        public static string GetWorkingDirectory()
        {
            return Path.GetDirectoryName(AppDomain.CurrentDomain.BaseDirectory);
        }

        public static List<WorkerInfo> LoadWorkerInfos()
        {
            List<WorkerInfo> lst = new List<WorkerInfo>();

            string workerSettingFile = string.Format(@"{0}\{1}", GetWorkingDirectory(), Common.WORKING_FILE_NAME);
            try
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(workerSettingFile);

                XmlNodeList nodes = doc.SelectNodes("//Worker");
                foreach (XmlNode node in nodes)
                {
                    try
                    {
                        WorkerInfo workerInfo = new WorkerInfo();
                        workerInfo.Name = node.Attributes["Name"].Value;
                        workerInfo.Library = node.Attributes["Library"].Value;
                        workerInfo.Class = node.Attributes["Class"].Value;
                        workerInfo.LogFile = node.Attributes["LogFile"].Value;
                        workerInfo.Enabled = node.Attributes["Enabled"].Value;
                        workerInfo.TaskType = node.Attributes["Type"].Value;

                        var dateTime = DateTime.ParseExact(node.Attributes["StartAt"].Value, "dd/MM/yyyy HH:mm:ss", null);
                        workerInfo.StartDate = DateTime.Now.ToShortDateString();
                        workerInfo.StartTime = dateTime.ToString(Common.DateTimeFormat.TIME);
                        workerInfo.Duration = node.Attributes["Duration"].Value;

                        lst.Add(workerInfo);
                    }
                    catch //(Exception ex)
                    {
                        //WriteLog(ex.Message);
                        //WriteLog(ex.StackTrace);
                    }
                }
            }
            catch //(Exception ex)
            {
                //WriteLog(ex.Message);
                //WriteLog(ex.StackTrace);
            }

            return lst;
        }


    }
}
