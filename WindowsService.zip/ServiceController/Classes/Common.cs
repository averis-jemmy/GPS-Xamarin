﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ServicesController.Classes
{
    public class Common
    {
        public const string WORKING_FILE_NAME = "WorkerSettings.xml";

        public struct ServiceName
        {
            public const string SERVICES = "Services";
            //public const string PAYMENT_UPDATING = "PaymentUpdating";
            //public const string NOTICE_UPLOADING = "NoticeUploading";
            //public const string REMINDER_PRINTING = "ReminderPrinting";
            //public const string COURT_COMPLAINT_PRINTING = "CourtComplaintPrinting";
            //public const string OWNER_SHIP_UPDATE = "OwnershipUpdate";
            //public const string PAYMENT_EXPORT = "PaymentExport";
            //public const string TRANSACTION_CHECKING = "TransactionChecking";
            //public const string UPDATE_RECEIPT_NUMBER = "UpdateReceiptNumber";
            //public const string COURT_PROCESSING = "CourtProcessing";
            //public const string UPDATE_REPORTING = "UpdateReporting";
            //public const string BLACKLIST = "Blacklist";
            //public const string UPDATE_COMPOUND_AMOUNT = "UpdateCompoundAmount";
        }

        public struct DateTimeFormat
        {
            public const string SHORT_DATE = "dd/MM/yyyy";
            public const string TIME = "HH:mm:ss";
        }
    }

    public enum TaskType
    {
        Daily,
        Weekly,
        Monthly,
        Time
    }
}
