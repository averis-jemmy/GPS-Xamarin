﻿using MyAverisCommon;
using MyAverisData;
using MyAverisEntity;
using MyAverisWorkerCommon;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

namespace MyAverisAlertWorker
{
    public class AlertWorker : WorkerBase
    {
        enum MethodReturnCode { Success, UnknownError, ConnectionError, DatabaseError }

        public override void Run()
        {
            this.Status = WorkerStatus.Running;
            DoWork();
            this.Status = WorkerStatus.Stopped;
        }

        private void DoWork()
        {
            try
            {
                NotificationRepository notifRep = new NotificationRepository(Database.Instant);
                List<PreBoardingInfo> infos = notifRep.GetPendingAlerts();

                if (infos != null)
                {
                    foreach (PreBoardingInfo info in infos)
                    {
                        if ((info.JoinDate.GetValueOrDefault().Date - DateTime.Now.Date).TotalDays == 7)
                        {
                            UpdateNotification(1, info);
                        }
                        if ((info.JoinDate.GetValueOrDefault().Date - DateTime.Now.Date).TotalDays == 1)
                        {
                            UpdateNotification(2, info);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                WriteExceptionLog(ex);
            }
        }

        private void UpdateNotification(int type, PreBoardingInfo info)
        {
            NotificationRepository notifRep = new NotificationRepository(Database.Instant);
            string title = string.Empty;
            string message = string.Empty;
            string name = string.Empty;
            switch(type)
            {
                case 1:
                    title = "Welcome on Board";
                    message = "Please tap for more info";
                    break;
                case 2:
                    title = "Congratulations from Averis";
                    message = "Please tap for more info";
                    break;
                default:
                    break;
            }

            if (!string.IsNullOrEmpty(message))
            {
                notifRep.Update(new NotificationInfo()
                {
                    ID = Guid.NewGuid(),
                    UserID = info.UserID,
                    Title = title,
                    Message = message,
                    NotificationType = InitialData.NotificationType.Notification
                });
            }
        }
    }
}
