using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Newtonsoft.Json;
using Android.Support.V7.App;

namespace MyAveris.Droid
{
    [Activity(Label = "VideoListActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class VideoListActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        String strResult;
        ListView listView;
        VideosList adapter;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.VideoList);

            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                    Database.CreateTables();

                    CacheManager.Init(Application.Context);

                    var user = CacheManager.GetFromSharedPreferences();

                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;
                    CacheManager.LoadData();
                }
            }
            catch { }

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Video);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            listView = FindViewById<ListView>(Resource.Id.listVideo);
            listView.ItemClick += OnListItemClick;

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            _processProgress.Show();

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            string videoCode = adapter[e.Position].VideoCode;
            if (!string.IsNullOrEmpty(videoCode))
            {
                CacheManager.VideoCode = videoCode;
                var intent = new Intent(this, typeof(YouTubePlayerActivity));
                StartActivity(intent);
            }
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.Category + "\"");
            strResult = client.ProcessRequest("GetVideoFromCategory", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle("Error");
                        alert.SetMessage("Your session has expired. Please login again.");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle("Error");
                        alert.SetMessage("Failed to refresh");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        List<VideoInfo> infos = JsonConvert.DeserializeObject<List<VideoInfo>>(strResult);
                        adapter = new VideosList(this, infos);
                        listView.Adapter = adapter;
                    }
                }
            }
            catch { }
            try { _processProgress.Dismiss(); }
            catch { }
        }
    }
}