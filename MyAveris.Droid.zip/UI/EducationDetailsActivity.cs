using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAveris.Droid
{
    [Activity(Label = "EducationDetailsActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class EducationDetailsActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.EducationDetails);

            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                    Database.CreateTables();

                    CacheManager.Init(Application.Context);

                    var user = CacheManager.GetFromSharedPreferences();

                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;
                    CacheManager.LoadData();
                }
            }
            catch { }

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Education);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.EducationInfo != null && !CacheManager.IsLocked)
            {
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Visible;
                FindViewById<Button>(Resource.Id.btnDelete).Click += Delete_OnClick;
            }
            else
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Gone;

            FindViewById<Spinner>(Resource.Id.spinCountry).Adapter = new SpinnerData(this, CommonData.GetCountries());

            FindViewById<CheckBox>(Resource.Id.chkPresent).CheckedChange += Present_CheckedChange;

            if (!CacheManager.IsLocked)
            {
                FindViewById<TextView>(Resource.Id.etStartDate).Click += StartDate_OnClick;
                FindViewById<TextView>(Resource.Id.etEndDate).Click += EndDate_OnClick;
            }

            if (CacheManager.EducationInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void Present_CheckedChange(object sender, CompoundButton.CheckedChangeEventArgs e)
        {
            if (FindViewById<CheckBox>(Resource.Id.chkPresent).Checked)
                FindViewById<TextView>(Resource.Id.etEndDate).Text = string.Empty;
        }

        private void StartDate_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DateTime? endDate = null;
            try
            {
                endDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etStartDate).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now.AddYears(-50), endDate.HasValue ? endDate : DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        private void EndDate_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DateTime? startDate = null;
            try
            {
                startDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etEndDate).Text = time.ToString("dd - MMM - yyyy");
            }, selected, startDate.HasValue ? startDate : DateTime.Now.AddYears(-50), DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);

            FindViewById<CheckBox>(Resource.Id.chkPresent).Checked = false;
        }

        void Delete_OnClick(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle("Logout");
            alert.SetMessage("Do you really want to delete this information?");
            alert.SetPositiveButton("Yes", (senderAlert, args) =>
            {
                JobApplicationEducation model = new JobApplicationEducation()
                {
                    ID = CacheManager.EducationInfo.UID
                };

                Database.DeleteEducation(model);

                if (CacheManager.JobInfo.Educations.Count >= CacheManager.EducationPosition + 1 &&
                            CacheManager.JobInfo.Educations[CacheManager.EducationPosition] != null)
                {
                    CacheManager.JobInfo.Educations.RemoveAt(CacheManager.EducationPosition);
                }

                Finish();
            });
            alert.SetNegativeButton("No", (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            FindViewById<EditText>(Resource.Id.etInstitutionName).Text = CacheManager.EducationInfo.Institution;
            FindViewById<EditText>(Resource.Id.etQualification).Text = CacheManager.EducationInfo.Qualification;
            FindViewById<EditText>(Resource.Id.etCourseOfStudy).Text = CacheManager.EducationInfo.CourseOfStudy;

            if (CacheManager.EducationInfo.StartDate.HasValue)
                FindViewById<TextView>(Resource.Id.etStartDate).Text = CacheManager.EducationInfo.StartDate.Value.ToString("dd - MMM - yyyy");

            if (CacheManager.EducationInfo.EndDate.HasValue)
            {
                FindViewById<CheckBox>(Resource.Id.chkPresent).Checked = false;
                FindViewById<TextView>(Resource.Id.etEndDate).Text = CacheManager.EducationInfo.EndDate.Value.ToString("dd - MMM - yyyy");
            }

            FindViewById<Spinner>(Resource.Id.spinCountry).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.EducationInfo.Country));
        }

        private void LockData()
        {
            FindViewById<CheckBox>(Resource.Id.chkPresent).Enabled = false;
            FindViewById<EditText>(Resource.Id.etInstitutionName).Enabled = false;
            FindViewById<EditText>(Resource.Id.etQualification).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCourseOfStudy).Enabled = false;

            FindViewById<Spinner>(Resource.Id.spinCountry).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.Educations == null)
                    CacheManager.JobInfo.Educations = new List<JobApplicationEducationInfo>();

                if (CacheManager.EducationInfo == null)
                {
                    JobApplicationEducationInfo info = new JobApplicationEducationInfo();
                    info.UID = Guid.NewGuid();
                    info.Institution = FindViewById<EditText>(Resource.Id.etInstitutionName).Text;
                    info.Qualification = FindViewById<EditText>(Resource.Id.etQualification).Text;
                    info.CourseOfStudy = FindViewById<EditText>(Resource.Id.etCourseOfStudy).Text;

                    try
                    {
                        info.StartDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        info.StartDate = null;
                    }

                    try
                    {
                        info.EndDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        info.EndDate = null;
                    }

                    info.Country = FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString();

                    CacheManager.JobInfo.Educations.Add(info);

                    JobApplicationEducation model = new JobApplicationEducation()
                    {
                        ID = info.UID,
                        Institution = info.Institution,
                        Qualification = info.Qualification,
                        Country = info.Country,
                        CourseOfStudy = info.CourseOfStudy,
                        StartDate = info.StartDate,
                        EndDate = info.EndDate
                    };

                    Database.UpdateEducation(model);
                }
                else
                {
                    if (CacheManager.JobInfo.Educations.Count >= CacheManager.EducationPosition + 1 &&
                        CacheManager.JobInfo.Educations[CacheManager.EducationPosition] != null)
                    {
                        Guid UID = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].UID;
                        CacheManager.JobInfo.Educations[CacheManager.EducationPosition] = new JobApplicationEducationInfo();
                        CacheManager.JobInfo.Educations[CacheManager.EducationPosition].UID = UID;

                        CacheManager.JobInfo.Educations[CacheManager.EducationPosition].Institution = FindViewById<EditText>(Resource.Id.etInstitutionName).Text;
                        CacheManager.JobInfo.Educations[CacheManager.EducationPosition].Qualification = FindViewById<EditText>(Resource.Id.etQualification).Text;
                        CacheManager.JobInfo.Educations[CacheManager.EducationPosition].CourseOfStudy = FindViewById<EditText>(Resource.Id.etCourseOfStudy).Text;

                        try
                        {
                            CacheManager.JobInfo.Educations[CacheManager.EducationPosition].StartDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etStartDate).Text,
                            "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            CacheManager.JobInfo.Educations[CacheManager.EducationPosition].StartDate = null;
                        }

                        try
                        {
                            CacheManager.JobInfo.Educations[CacheManager.EducationPosition].EndDate = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etEndDate).Text,
                            "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            CacheManager.JobInfo.Educations[CacheManager.EducationPosition].EndDate = null;
                        }

                        CacheManager.JobInfo.Educations[CacheManager.EducationPosition].Country = FindViewById<Spinner>(Resource.Id.spinCountry).SelectedItem.ToString();

                        JobApplicationEducation model = new JobApplicationEducation()
                        {
                            ID = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].UID,
                            Institution = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].Institution,
                            Qualification = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].Qualification,
                            CourseOfStudy = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].CourseOfStudy,
                            Country = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].Country,
                            StartDate = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].StartDate,
                            EndDate = CacheManager.JobInfo.Educations[CacheManager.EducationPosition].EndDate
                        };

                        Database.UpdateEducation(model);
                    }
                }
            }

            Finish();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etInstitutionName).Text))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle("Info");
                alert.SetMessage("The institution name is not entered. Data will not be saved. Proceed?");
                alert.SetPositiveButton("Yes", (senderAlert, args) =>
                {
                    Finish();
                });
                alert.SetNegativeButton("No", (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return false;
            }
            return true;
        }
    }
}