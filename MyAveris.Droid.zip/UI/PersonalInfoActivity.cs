using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using Android.Graphics;
using MyAverisCommon;

namespace MyAveris.Droid
{
    [Activity(Label = "PersonalInfoActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class PersonalInfoActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.PersonalInfo);

            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                    Database.CreateTables();

                    CacheManager.Init(Application.Context);

                    var user = CacheManager.GetFromSharedPreferences();

                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;
                    CacheManager.LoadData();
                }
            }
            catch { }

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.PersonalInfo);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            FindViewById<RadioButton>(Resource.Id.rbIC).Click += RadioIdentity_OnClick;
            FindViewById<RadioButton>(Resource.Id.rbPassport).Click += RadioIdentity_OnClick;

            FindViewById<Spinner>(Resource.Id.spinTitle).Adapter = new SpinnerData(this, CommonData.Titles);
            FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).Adapter = new SpinnerData(this, CommonData.GetCountries());
            FindViewById<Spinner>(Resource.Id.spinNationality).Adapter = new SpinnerData(this, CommonData.GetCountries());
            FindViewById<Spinner>(Resource.Id.spinRace).Adapter = new SpinnerData(this, CommonData.Races);
            FindViewById<Spinner>(Resource.Id.spinMaritalStatus).Adapter = new SpinnerData(this, CommonData.MaritalStatuses);
            FindViewById<Spinner>(Resource.Id.spinReligion).Adapter = new SpinnerData(this, CommonData.Religions);
            FindViewById<Spinner>(Resource.Id.spinCountryOfIssue).Adapter = new SpinnerData(this, CommonData.GetCountries());

            if (!CacheManager.IsLocked)
            {
                FindViewById<TextView>(Resource.Id.etDOB).Click += DOB_OnClick;
                FindViewById<TextView>(Resource.Id.etDOI).Click += DOI_OnClick;
                FindViewById<TextView>(Resource.Id.etDOE).Click += DOE_OnClick;
            }

            if (CacheManager.JobInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        private void DOB_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOB).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etDOB).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now.AddYears(-60), DateTime.Now.AddYears(-15));
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        private void DOI_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOI).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etDOI).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now.AddYears(-12), DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        private void DOE_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOE).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etDOE).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now, DateTime.Now.AddYears(12));
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        private void RadioIdentity_OnClick(object sender, EventArgs e)
        {
            RadioButton rb = (RadioButton)sender;
            if (rb.Text == "IC")
            {
                FindViewById<TextView>(Resource.Id.etDOI).Text = string.Empty;
                FindViewById<TextView>(Resource.Id.etDOE).Text = string.Empty;
                FindViewById<Spinner>(Resource.Id.spinCountryOfIssue).SetSelection(0);

                //collapse;
                int finalHeight = FindViewById<LinearLayout>(Resource.Id.layPassportDetail).Height;

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPassportDetail), finalHeight, 0);
                mAnimator.Start();
                mAnimator.AnimationEnd += (object IntentSender, EventArgs arg) =>
                {
                    FindViewById<LinearLayout>(Resource.Id.layPassportDetail).Visibility = ViewStates.Gone;
                };
            }
            else
            {
                //expand
                FindViewById<LinearLayout>(Resource.Id.layPassportDetail).Visibility = ViewStates.Visible;
                int widthSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                int heightSpec = View.MeasureSpec.MakeMeasureSpec(0, MeasureSpecMode.Unspecified);
                FindViewById<LinearLayout>(Resource.Id.layPassportDetail).Measure(widthSpec, heightSpec);

                ValueAnimator mAnimator = SlideAnimator(FindViewById<LinearLayout>(Resource.Id.layPassportDetail), 0, FindViewById<LinearLayout>(Resource.Id.layPassportDetail).MeasuredHeight);
                mAnimator.Start();
            }
        }

        private ValueAnimator SlideAnimator(LinearLayout mLinearLayout, int start, int end)
        {
            ValueAnimator animator = ValueAnimator.OfInt(start, end);
            animator.Update +=
                (object sender, ValueAnimator.AnimatorUpdateEventArgs e) =>
                {
                    var value = (int)animator.AnimatedValue;
                    ViewGroup.LayoutParams layoutParams = mLinearLayout.LayoutParameters;
                    layoutParams.Height = value;
                    mLinearLayout.LayoutParameters = layoutParams;
                };
            return animator;
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            FindViewById<RadioButton>(Resource.Id.rbIC).Checked = true;
            FindViewById<Spinner>(Resource.Id.spinTitle).SetSelection(CommonData.Titles.IndexOf(CacheManager.JobInfo.Title));
            FindViewById<EditText>(Resource.Id.etFirstName).Text = CacheManager.JobInfo.FirstName;
            FindViewById<EditText>(Resource.Id.etLastName).Text = CacheManager.JobInfo.LastName;
            FindViewById<EditText>(Resource.Id.etKnownAs).Text = CacheManager.JobInfo.KnownAs;
            FindViewById<EditText>(Resource.Id.etChineseCharacter).Text = CacheManager.JobInfo.ChineseCharacter;
            if (CacheManager.JobInfo.Gender == "M")
                FindViewById<RadioButton>(Resource.Id.rbMale).Checked = true;
            if (CacheManager.JobInfo.Gender == "F")
                FindViewById<RadioButton>(Resource.Id.rbFemale).Checked = true;

            if (CacheManager.JobInfo.DateOfBirth.HasValue)
                FindViewById<TextView>(Resource.Id.etDOB).Text = CacheManager.JobInfo.DateOfBirth.Value.ToString("dd - MMM - yyyy");

            FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.JobInfo.CountryOfBirth));
            FindViewById<Spinner>(Resource.Id.spinNationality).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.JobInfo.Nationality));
            FindViewById<Spinner>(Resource.Id.spinRace).SetSelection(CommonData.Races.IndexOf(CacheManager.JobInfo.Race));
            FindViewById<Spinner>(Resource.Id.spinMaritalStatus).SetSelection(CommonData.MaritalStatuses.IndexOf(CacheManager.JobInfo.MaritalStatus));
            FindViewById<Spinner>(Resource.Id.spinReligion).SetSelection(CommonData.Religions.IndexOf(CacheManager.JobInfo.Religion));

            FindViewById<EditText>(Resource.Id.etIdentityNo).Text = CacheManager.JobInfo.IdentityNo;

            if (CacheManager.JobInfo.IsPassport.GetValueOrDefault())
            {
                FindViewById<LinearLayout>(Resource.Id.layPassportDetail).Visibility = ViewStates.Visible;
                FindViewById<RadioButton>(Resource.Id.rbPassport).Checked = true;
            }
            else
            {
                FindViewById<LinearLayout>(Resource.Id.layPassportDetail).Visibility = ViewStates.Gone;
                FindViewById<RadioButton>(Resource.Id.rbIC).Checked = true;
            }

            if (CacheManager.JobInfo.DateOfIssue.HasValue)
                FindViewById<TextView>(Resource.Id.etDOI).Text = CacheManager.JobInfo.DateOfIssue.Value.ToString("dd - MMM - yyyy");
            if (CacheManager.JobInfo.DateOfExpiry.HasValue)
                FindViewById<TextView>(Resource.Id.etDOE).Text = CacheManager.JobInfo.DateOfExpiry.Value.ToString("dd - MMM - yyyy");

            FindViewById<Spinner>(Resource.Id.spinCountryOfIssue).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.JobInfo.CountryOfIssue));
        }

        private void LockData()
        {
            FindViewById<RadioButton>(Resource.Id.rbPassport).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbIC).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbMale).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbFemale).Enabled = false;

            FindViewById<Spinner>(Resource.Id.spinTitle).Enabled = false;
            FindViewById<EditText>(Resource.Id.etFirstName).Enabled = false;
            FindViewById<EditText>(Resource.Id.etLastName).Enabled = false;
            FindViewById<EditText>(Resource.Id.etKnownAs).Enabled = false;
            FindViewById<EditText>(Resource.Id.etChineseCharacter).Enabled = false;

            FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinNationality).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinRace).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinMaritalStatus).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinReligion).Enabled = false;
            FindViewById<EditText>(Resource.Id.etIdentityNo).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinCountryOfIssue).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                CacheManager.JobInfo.Title = FindViewById<Spinner>(Resource.Id.spinTitle).SelectedItem.ToString();
                CacheManager.JobInfo.FirstName = FindViewById<EditText>(Resource.Id.etFirstName).Text;
                CacheManager.JobInfo.LastName = FindViewById<EditText>(Resource.Id.etLastName).Text;
                CacheManager.JobInfo.KnownAs = FindViewById<EditText>(Resource.Id.etKnownAs).Text;
                CacheManager.JobInfo.ChineseCharacter = FindViewById<EditText>(Resource.Id.etChineseCharacter).Text;
                if (FindViewById<RadioButton>(Resource.Id.rbMale).Checked)
                    CacheManager.JobInfo.Gender = "M";
                if (FindViewById<RadioButton>(Resource.Id.rbFemale).Checked)
                    CacheManager.JobInfo.Gender = "F";

                try
                {
                    CacheManager.JobInfo.DateOfBirth = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOB).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                }
                catch
                {
                    CacheManager.JobInfo.DateOfBirth = null;
                }

                CacheManager.JobInfo.CountryOfBirth = FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).SelectedItem.ToString();
                CacheManager.JobInfo.Nationality = FindViewById<Spinner>(Resource.Id.spinNationality).SelectedItem.ToString();
                CacheManager.JobInfo.Race = FindViewById<Spinner>(Resource.Id.spinRace).SelectedItem.ToString();
                CacheManager.JobInfo.MaritalStatus = FindViewById<Spinner>(Resource.Id.spinMaritalStatus).SelectedItem.ToString();
                CacheManager.JobInfo.Religion = FindViewById<Spinner>(Resource.Id.spinReligion).SelectedItem.ToString();

                CacheManager.JobInfo.IdentityNo = FindViewById<EditText>(Resource.Id.etIdentityNo).Text;
                CacheManager.JobInfo.IsPassport = FindViewById<RadioButton>(Resource.Id.rbPassport).Checked;

                if (FindViewById<RadioButton>(Resource.Id.rbPassport).Checked)
                {
                    try
                    {
                        CacheManager.JobInfo.DateOfIssue = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOI).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        CacheManager.JobInfo.DateOfIssue = null;
                    }

                    try
                    {
                        CacheManager.JobInfo.DateOfExpiry = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOE).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        CacheManager.JobInfo.DateOfExpiry = null;
                    }

                    CacheManager.JobInfo.CountryOfIssue = FindViewById<Spinner>(Resource.Id.spinCountryOfIssue).SelectedItem.ToString();
                }
                else
                {
                    CacheManager.JobInfo.DateOfIssue = null;
                    CacheManager.JobInfo.DateOfExpiry = null;
                    CacheManager.JobInfo.CountryOfIssue = string.Empty;
                }

                JobApplication app = Database.GetJobApplication();
                app.Title = CacheManager.JobInfo.Title;
                app.FirstName = CacheManager.JobInfo.FirstName;
                app.LastName = CacheManager.JobInfo.LastName;
                app.KnownAs = CacheManager.JobInfo.KnownAs;
                app.ChineseCharacter = CacheManager.JobInfo.ChineseCharacter;
                app.Gender = CacheManager.JobInfo.Gender;
                app.DateOfBirth = CacheManager.JobInfo.DateOfBirth;
                app.CountryOfBirth = CacheManager.JobInfo.CountryOfBirth;
                app.Nationality = CacheManager.JobInfo.Nationality;
                app.Race = CacheManager.JobInfo.Race;
                app.MaritalStatus = CacheManager.JobInfo.MaritalStatus;
                app.Religion = CacheManager.JobInfo.Religion;
                app.IdentityNo = CacheManager.JobInfo.IdentityNo;
                app.IsPassport = CacheManager.JobInfo.IsPassport;
                app.DateOfIssue = CacheManager.JobInfo.DateOfIssue;
                app.DateOfExpiry = CacheManager.JobInfo.DateOfExpiry;
                app.CountryOfIssue = CacheManager.JobInfo.CountryOfIssue;

                Database.UpdateJobApplication(app);
            }

            Finish();
        }

        private bool ValidateData()
        {
            return true;
        }
    }
}