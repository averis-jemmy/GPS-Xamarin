using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;

namespace MyAveris.Droid
{
    [Activity(Label = "NationalServiceActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class NationalServiceActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.NationalService);

            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                    Database.CreateTables();

                    CacheManager.Init(Application.Context);

                    var user = CacheManager.GetFromSharedPreferences();

                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;
                    CacheManager.LoadData();
                }
            }
            catch { }

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.NationalService);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (!CacheManager.IsLocked)
                FindViewById<TextView>(Resource.Id.etDC).Click += DC_OnClick;

            if (CacheManager.JobInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        private void DC_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDC).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etDC).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now.AddYears(-50), DateTime.Now);
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            FindViewById<EditText>(Resource.Id.etHighestRank).Text = CacheManager.JobInfo.HighestRankAttained;
            FindViewById<EditText>(Resource.Id.etExemptionReason).Text = CacheManager.JobInfo.ExemptionReason;

            if (CacheManager.JobInfo.LiabilityForDuties.HasValue)
            {
                if (CacheManager.JobInfo.LiabilityForDuties.GetValueOrDefault())
                    FindViewById<RadioButton>(Resource.Id.rbYes).Checked = true;
                else
                    FindViewById<RadioButton>(Resource.Id.rbNo).Checked = true;
            }

            if (CacheManager.JobInfo.ServiceCompleted.HasValue)
                FindViewById<TextView>(Resource.Id.etDC).Text = CacheManager.JobInfo.ServiceCompleted.Value.ToString("dd - MMM - yyyy");
        }

        private void LockData()
        {
            FindViewById<RadioButton>(Resource.Id.rbYes).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbNo).Enabled = false;

            FindViewById<EditText>(Resource.Id.etExemptionReason).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHighestRank).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                CacheManager.JobInfo.HighestRankAttained = FindViewById<EditText>(Resource.Id.etHighestRank).Text;
                CacheManager.JobInfo.ExemptionReason = FindViewById<EditText>(Resource.Id.etExemptionReason).Text;

                try
                {
                    CacheManager.JobInfo.ServiceCompleted = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDC).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                }
                catch
                {
                    CacheManager.JobInfo.ServiceCompleted = null;
                }

                if (!FindViewById<RadioButton>(Resource.Id.rbYes).Checked && !FindViewById<RadioButton>(Resource.Id.rbNo).Checked)
                    CacheManager.JobInfo.LiabilityForDuties = null;
                else
                    CacheManager.JobInfo.LiabilityForDuties = FindViewById<RadioButton>(Resource.Id.rbYes).Checked;

                JobApplication app = Database.GetJobApplication();
                app.ExemptionReason = CacheManager.JobInfo.ExemptionReason;
                app.HighestRankAttained = CacheManager.JobInfo.HighestRankAttained;
                app.ServiceCompleted = CacheManager.JobInfo.ServiceCompleted;
                app.LiabilityForDuties = CacheManager.JobInfo.LiabilityForDuties;

                Database.UpdateJobApplication(app);
            }

            Finish();
        }

        private bool ValidateData()
        {
            return true;
        }
    }
}