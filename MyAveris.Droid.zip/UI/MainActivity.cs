﻿using System;
using System.Linq;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using System.ComponentModel;
using MyAverisClient;
using System.Collections.Generic;
using MyAverisEntity;
using Newtonsoft.Json;
using System.Net;
using System.Security.Cryptography.X509Certificates;
using System.Net.Security;
using Android.Support.V4.Widget;
using Android.Support.V7.App;
using Android.Support.Design.Widget;
using Android.Views.InputMethods;
using MyAverisCommon;
using Android.Gms.Common;
using Android.Util;
using Android.Support.V4.Content;
using Android.Preferences;
using System.IO;
using Android.Gms.Gcm.Iid;

namespace MyAveris.Droid
{
    [Activity(Label = "MYAveris", Theme = "@style/MyTheme.Base", WindowSoftInputMode = SoftInput.StateHidden, Icon = "@drawable/icon", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class MainActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        string strResult, strLookupResult;

        Android.Support.V7.Widget.Toolbar toolbar;
        DrawerLayout drawerLayout;
        NavigationView navigationView;

        const int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
        const string TAG = "LoginActivity";

        BroadcastReceiver mRegistrationBroadcastReceiver;

        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            ServicePointManager.ServerCertificateValidationCallback =
                delegate(System.Object obj, X509Certificate certificate, X509Chain chain, SslPolicyErrors errors)
                {
                    return (true);
                };
            System.Security.Cryptography.AesCryptoServiceProvider b = new System.Security.Cryptography.AesCryptoServiceProvider();
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            try
            {
                Database.newInstance(Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                Database.CreateTables();

                CacheManager.Init(Application.Context);

                var user = CacheManager.GetFromSharedPreferences();//Database.GetUser();

                if (user == null)
                {
                    var intent = new Intent(this, typeof(DiscoverAverisActivity));
                    StartActivity(intent);
                    Finish();
                }
                else
                {
                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;

                    mRegistrationBroadcastReceiver = new BroadcastReceiver();
                    mRegistrationBroadcastReceiver.Receive += (sender, e) =>
                    {
                        var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences((Context)sender);
                        var sentToken = sharedPreferences.GetBoolean(QuickstartPreferences.SENT_TOKEN_TO_SERVER, false);
                    };

                    if (CheckPlayServices())
                    {
                        var intent = new Intent(this, typeof(RegistrationIntentService));
                        StartService(intent);
                    }

                    SetContentView(Resource.Layout.Main);
                    drawerLayout = FindViewById<DrawerLayout>(Resource.Id.drawerLayout);

                    #region Load Data
                    JobApplication jobApp = Database.GetJobApplication();
                    if (jobApp != null)
                    {
                        CacheManager.JobApplicationID = jobApp.ID;
                        CacheManager.IsLocked = jobApp.IsLocked;
                        CacheManager.JobInfo = new JobApplicationInfo()
                        {
                            Photo = jobApp.Photo,
                            Title = jobApp.Title,
                            FirstName = jobApp.FirstName,
                            LastName = jobApp.LastName,
                            KnownAs = jobApp.KnownAs,
                            ChineseCharacter = jobApp.ChineseCharacter,
                            Gender = jobApp.Gender,
                            DateOfBirth = jobApp.DateOfBirth,
                            CountryOfBirth = jobApp.CountryOfBirth,
                            Nationality = jobApp.Nationality,
                            Race = jobApp.Race,
                            MaritalStatus = jobApp.MaritalStatus,
                            Religion = jobApp.Religion,
                            IdentityNo = jobApp.IdentityNo,
                            IsPassport = jobApp.IsPassport,
                            DateOfIssue = jobApp.DateOfIssue,
                            DateOfExpiry = jobApp.DateOfExpiry,
                            CountryOfIssue = jobApp.CountryOfIssue,
                            EmailAddress = jobApp.EmailAddress,
                            EmergencyContact = jobApp.EmergencyContact,
                            ServiceCompleted = jobApp.ServiceCompleted,
                            HighestRankAttained = jobApp.HighestRankAttained,
                            ExemptionReason = jobApp.ExemptionReason,
                            LiabilityForDuties = jobApp.LiabilityForDuties,
                            ApplicationStatus = jobApp.ApplicationStatus,
                            IsLocked = jobApp.IsLocked
                        };
                    }

                    JobApplicationAddress current = Database.GetAddress(InitialData.AddressType.CurrentAddress);
                    if (current != null && CacheManager.JobInfo != null)
                    {
                        CacheManager.JobInfo.CurrentAddress = new JobApplicationAddressInfo()
                        {
                            AddressType = current.AddressType,
                            Address = current.Address,
                            PostalCode = current.PostalCode,
                            Country = current.Country,
                            HomeNumber = current.HomeNumber,
                            MobileNumber = current.MobileNumber
                        };
                    }

                    JobApplicationAddress home = Database.GetAddress(InitialData.AddressType.HomeAddress);
                    if (home != null && CacheManager.JobInfo != null)
                    {
                        CacheManager.JobInfo.HomeAddress = new JobApplicationAddressInfo()
                        {
                            AddressType = home.AddressType,
                            Address = home.Address,
                            PostalCode = home.PostalCode,
                            Country = home.Country,
                            HomeNumber = home.HomeNumber,
                            MobileNumber = home.MobileNumber
                        };
                    }

                    JobApplicationAddress emergency = Database.GetAddress(InitialData.AddressType.EmergencyAddress);
                    if (emergency != null && CacheManager.JobInfo != null)
                    {
                        CacheManager.JobInfo.EmergencyAddress = new JobApplicationAddressInfo()
                        {
                            AddressType = emergency.AddressType,
                            Address = emergency.Address,
                            PostalCode = emergency.PostalCode,
                            Country = emergency.Country,
                            HomeNumber = emergency.HomeNumber,
                            MobileNumber = emergency.MobileNumber
                        };
                    }

                    List<JobApplicationFamily> families = Database.GetFamilies();
                    if (families != null && families.Count > 0)
                    {
                        CacheManager.JobInfo.Families = new List<JobApplicationFamilyInfo>();
                        foreach (JobApplicationFamily item in families)
                        {
                            CacheManager.JobInfo.Families.Add(new JobApplicationFamilyInfo()
                            {
                                UID = item.ID,
                                FirstName = item.FirstName,
                                LastName = item.LastName,
                                Relationship = item.Relationship,
                                IdentityNo = item.IdentityNo,
                                JobTitle = item.JobTitle,
                                Employer = item.Employer,
                                Gender = item.Gender,
                                DateOfBirth = item.DateOfBirth,
                                Nationality = item.Nationality,
                                CountryOfBirth = item.CountryOfBirth,
                                IsSameCountry = item.IsSameCountry
                            });
                        }
                    }

                    List<JobApplicationEducation> educations = Database.GetEducations();
                    if (educations != null && educations.Count > 0)
                    {
                        CacheManager.JobInfo.Educations = new List<JobApplicationEducationInfo>();
                        foreach (JobApplicationEducation item in educations)
                        {
                            CacheManager.JobInfo.Educations.Add(new JobApplicationEducationInfo()
                            {
                                UID = item.ID,
                                Institution = item.Institution,
                                CourseOfStudy = item.CourseOfStudy,
                                Country = item.Country,
                                StartDate = item.StartDate,
                                EndDate = item.EndDate,
                                Qualification = item.Qualification
                            });
                        }
                    }

                    List<JobApplicationLanguage> languages = Database.GetLanguages();
                    if (languages != null && languages.Count > 0)
                    {
                        CacheManager.JobInfo.Languages = new List<JobApplicationLanguageInfo>();
                        foreach (JobApplicationLanguage item in languages)
                        {
                            CacheManager.JobInfo.Languages.Add(new JobApplicationLanguageInfo()
                            {
                                UID = item.ID,
                                Language = item.Language,
                                SpeakAbility = item.SpeakAbility,
                                ReadAbility = item.ReadAbility,
                                WriteAbility = item.WriteAbility
                            });
                        }
                    }

                    List<JobApplicationWorkingHistory> workingHistories = Database.GetWorkingHistories();
                    if (workingHistories != null && workingHistories.Count > 0)
                    {
                        CacheManager.JobInfo.WorkingHistories = new List<JobApplicationWorkingHistoryInfo>();
                        foreach (JobApplicationWorkingHistory item in workingHistories)
                        {
                            CacheManager.JobInfo.WorkingHistories.Add(new JobApplicationWorkingHistoryInfo()
                            {
                                UID = item.ID,
                                Company = item.Company,
                                LastPositionHeld = item.LastPositionHeld,
                                Country = item.Country,
                                StartDate = item.StartDate,
                                EndDate = item.EndDate,
                                NameOfSuperior = item.NameOfSuperior,
                                DesignationOfSuperior = item.DesignationOfSuperior,
                                LastDrawnSalary = item.LastDrawnSalary,
                                ReasonForLeaving = item.ReasonForLeaving
                            });
                        }
                    }

                    List<JobApplicationActivity> activities = Database.GetActivities();
                    if (activities != null && activities.Count > 0)
                    {
                        CacheManager.JobInfo.Activities = new List<JobApplicationActivityInfo>();
                        foreach (JobApplicationActivity item in activities)
                        {
                            CacheManager.JobInfo.Activities.Add(new JobApplicationActivityInfo()
                            {
                                UID = item.ID,
                                Organisation = item.Organisation,
                                NatureOfActivities = item.NatureOfActivities,
                                Country = item.Country,
                                FromDate = item.FromDate,
                                ToDate = item.ToDate
                            });
                        }
                    }

                    List<JobApplicationReference> references = Database.GetReferences();
                    if (references != null && references.Count > 0)
                    {
                        CacheManager.JobInfo.References = new List<JobApplicationReferenceInfo>();
                        foreach (JobApplicationReference item in references)
                        {
                            CacheManager.JobInfo.References.Add(new JobApplicationReferenceInfo()
                            {
                                Name = item.Name,
                                Occupation = item.Occupation,
                                YearsKnown = item.YearsKnown,
                                Address = item.Address,
                                Employer = item.Employer,
                                MobileNumber = item.MobileNumber,
                                HomeNumber = item.HomeNumber,
                                OfficeNumber = item.OfficeNumber
                            });
                        }
                    }

                    List<JobApplicationDeclaration> declarations = Database.GetDeclarations();
                    if (declarations != null && declarations.Count > 0)
                    {
                        CacheManager.JobInfo.Declarations = new List<JobApplicationDeclarationInfo>();
                        foreach (JobApplicationDeclaration item in declarations)
                        {
                            CacheManager.JobInfo.Declarations.Add(new JobApplicationDeclarationInfo()
                            {
                                DeclarationID = item.DeclarationID,
                                Answer = item.Answer,
                                Remarks = item.Remarks
                            });
                        }
                    }

                    JobApplicationPackageDetail detail = Database.GetPackageDetail();
                    if (detail != null)
                    {
                        CacheManager.JobInfo.PackageDetail = new JobApplicationPackageDetailInfo()
                        {
                            BaseSalary = detail.BaseSalary,
                            ExpectedSalary = detail.ExpectedSalary,
                            ContractualBonus = detail.ContractualBonus,
                            PerformanceBonus = detail.PerformanceBonus,
                            HousingAllowance = detail.HousingAllowance,
                            TransportAllowance = detail.TransportAllowance,
                            ConnectivityAllowance = detail.ConnectivityAllowance,
                            ProjectAlowance = detail.ProjectAlowance,
                            SpecialSkillsAllowance = detail.SpecialSkillsAllowance,
                            CarParkAllowance = detail.CarParkAllowance,
                            CarParkClaim = detail.CarParkClaim,
                            PhoneClaim = detail.PhoneClaim,
                            MileageClaim = detail.MileageClaim,
                            MealClaim = detail.MealClaim,
                            OvertimeClaim = detail.OvertimeClaim,
                            StandbyClaim = detail.StandbyClaim,
                            SelfMedicalBenefit = detail.SelfMedicalBenefit,
                            FamilyMedicalBenefit = detail.FamilyMedicalBenefit,
                            SelfInsuranceBenefit = detail.SelfInsuranceBenefit,
                            FamilyInsuranceBenefit = detail.FamilyInsuranceBenefit,
                            OpticalBenefit = detail.OpticalBenefit,
                            DentalBenefit = detail.DentalBenefit,
                            AnnualLeave = detail.AnnualLeave,
                            MedicalLeave = detail.MedicalLeave,
                            RetirementBenefit = detail.RetirementBenefit,
                            EPFNumber = detail.EPFNumber,
                            SOCSONumber = detail.SOCSONumber,
                            IncomeTaxNumber = detail.IncomeTaxNumber,
                            BankAccountNumber = detail.BankAccountNumber
                        };
                    }
                    #endregion

                    // Initialize toolbar
                    toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
                    SetSupportActionBar(toolbar);
                    SupportActionBar.SetTitle(Resource.String.MyAveris);
                    //SupportActionBar.SetIcon(Resource.Drawable.Icon);
                    SupportActionBar.SetDisplayHomeAsUpEnabled(true);
                    SupportActionBar.SetDisplayShowHomeEnabled(true);
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Click += Submit_OnClick;
                    toolbar.FindViewById<TextView>(Resource.Id.lblRefresh).Click += Refresh_OnClick;

                    // Attach item selected handler to navigation view
                    navigationView = FindViewById<NavigationView>(Resource.Id.navView);
                    navigationView.NavigationItemSelected += NavigationView_NavigationItemSelected;
                    navigationView.Menu.Clear();
                    if (!CacheManager.IsRecruiter)
                    {
                        navigationView.InflateMenu(Resource.Menu.menu_applicant);
                    }
                    else
                    {
                        navigationView.InflateMenu(Resource.Menu.menu_recruiter);
                    }

                    // Create ActionBarDrawerToggle button and add it to the toolbar
                    var drawerToggle = new ActionBarDrawerToggle(this, drawerLayout, toolbar, Resource.String.open_drawer, Resource.String.close_drawer);
                    drawerLayout.AddDrawerListener(drawerToggle);
                    drawerToggle.SyncState();

                    //Load default screen
                    var ft = FragmentManager.BeginTransaction();
                    //ft.AddToBackStack(null);
                    ft.Add(Resource.Id.HomeFrameLayout, new HomeFragment());
                    ft.Commit();

                    FindViewById<Button>(Resource.Id.nav_logout).Click += LogoutButton_OnClick;

                    _processProgress = new ProgressDialog(this);
                    _processProgress.Indeterminate = true;
                    _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
                    _processProgress.SetMessage("Loading...");
                    _processProgress.SetCancelable(false);
                    _processProgress.Show();

                    BackgroundWorker lookupWorker = new BackgroundWorker();
                    lookupWorker.DoWork += lookupWorker_DoWork;
                    lookupWorker.RunWorkerCompleted += lookupWorker_RunWorkerCompleted;
                    lookupWorker.RunWorkerAsync();
                }
            }
            catch (Exception ex)
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle("Error");
                alert.SetMessage(ex.Message + "\t" + ex.StackTrace);
                alert.SetPositiveButton("OK", (senderAlert, args) =>
                {
                    var intent = new Intent(this, typeof(MainActivity));
                    StartActivity(intent);
                    FinishAffinity();
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        public override void OnBackPressed()
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle("Info");
            alert.SetMessage("Do you want to exit this application?");
            alert.SetPositiveButton("YES", (senderAlert, args) =>
            {
                FinishAffinity();
            });
            alert.SetNegativeButton("NO", (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void Submit_OnClick(object sender, EventArgs e)
        {
            if (ValidateData() && !CacheManager.IsLocked)
            {
                var intent = new Intent(this, typeof(DeclarationActivity));
                StartActivity(intent);
            }
        }

        void Refresh_OnClick(object sender, EventArgs e)
        {
            //Load default screen
            var ft = FragmentManager.BeginTransaction();
            ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationListFragment());
            ft.Commit();
        }

        protected override void OnPause()
        {
            GC.Collect();
            LocalBroadcastManager.GetInstance(this).UnregisterReceiver(mRegistrationBroadcastReceiver);
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        protected override void OnResume()
        {
            base.OnResume();
            LocalBroadcastManager.GetInstance(this).RegisterReceiver(mRegistrationBroadcastReceiver,
                new IntentFilter(QuickstartPreferences.REGISTRATION_COMPLETE));

            try
            {
                if (CacheManager.IsLocked)
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;

                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }
        }

        public void UpdateControl()
        {
            try
            {
                if (CacheManager.IsLocked)
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;
                else
                    toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Visible;
            }
            catch { }
        }

        bool CheckPlayServices()
        {
            int resultCode = GooglePlayServicesUtil.IsGooglePlayServicesAvailable(this);
            if (resultCode != ConnectionResult.Success)
            {
                if (GooglePlayServicesUtil.IsUserRecoverableError(resultCode))
                {
                    GooglePlayServicesUtil.GetErrorDialog(resultCode, this,
                        PLAY_SERVICES_RESOLUTION_REQUEST).Show();
                }
                else
                {
                    Log.Info(TAG, "This device is not supported.");
                    Finish();
                }
                return false;
            }
            return true;
        }

        class BroadcastReceiver : Android.Content.BroadcastReceiver
        {
            public EventHandler<BroadcastEventArgs> Receive { get; set; }

            public override void OnReceive(Context context, Intent intent)
            {
                if (Receive != null)
                    Receive(context, new BroadcastEventArgs(intent));
            }
        }

        class BroadcastEventArgs : EventArgs
        {
            public Intent Intent { get; private set; }

            public BroadcastEventArgs(Intent intent)
            {
                Intent = intent;
            }
        }

        void NavigationView_NavigationItemSelected(object sender, NavigationView.NavigationItemSelectedEventArgs e)
        {
            if (!e.MenuItem.IsChecked)
            {
                var ft = FragmentManager.BeginTransaction();
                toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;
                toolbar.FindViewById<TextView>(Resource.Id.lblRefresh).Visibility = ViewStates.Gone;
                SupportActionBar.SetTitle(Resource.String.MyAveris);
                switch (e.MenuItem.ItemId)
                {
                    case (Resource.Id.navHome):
                        ft.Replace(Resource.Id.HomeFrameLayout, new HomeFragment());
                        break;
                    case (Resource.Id.navApplicationForm):
                        SupportActionBar.SetTitle(Resource.String.ApplicationForm);
                        if (!CacheManager.IsLocked && CacheManager.JobInfo != null &&
                            CacheManager.JobInfo.ApplicationStatus != InitialData.ApplicationStatus.Accepted &&
                            CacheManager.JobInfo.ApplicationStatus == InitialData.ApplicationStatus.Rejected)
                        {
                            toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Visible;
                        }
                        ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationFormFragment());
                        break;
                    case (Resource.Id.navApplicationList):
                        SupportActionBar.SetTitle(Resource.String.ApplicationList);
                        toolbar.FindViewById<TextView>(Resource.Id.lblRefresh).Visibility = ViewStates.Visible;
                        ft.Replace(Resource.Id.HomeFrameLayout, new ApplicationListFragment());
                        break;
                    case (Resource.Id.navPhoto):
                        SupportActionBar.SetTitle(Resource.String.Photo);
                        ft.Replace(Resource.Id.HomeFrameLayout, new PhotoFragment());
                        break;
                    case (Resource.Id.navVideo):
                        SupportActionBar.SetTitle(Resource.String.Video);
                        ft.Replace(Resource.Id.HomeFrameLayout, new VideoFragment());
                        break;
                    case (Resource.Id.navPreBoarding):
                        SupportActionBar.SetTitle(Resource.String.AverisInfo);
                        ft.Replace(Resource.Id.HomeFrameLayout, new PreBoardingFragment());
                        break;
                }
                ft.Commit();
            }
            drawerLayout.CloseDrawers();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    drawerLayout.OpenDrawer(Android.Support.V4.View.GravityCompat.Start);
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        void LogoutButton_OnClick(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle("Logout");
            alert.SetMessage("Do you really want to logout?");
            if (CacheManager.JobInfo != null && CacheManager.JobInfo.ApplicationStatus == InitialData.ApplicationStatus.New)
                alert.SetMessage("Do you really want to logout? (Your job application form will not be saved)");
            alert.SetPositiveButton("Yes", (senderAlert, args) =>
            {
                CacheManager.ClearSharedPreferences();
                Database.ClearData();
                CacheManager.JobInfo = null;
                CacheManager.ProfileBitmap = null;
                try
                {
                    var instanceID = InstanceID.GetInstance(this);
                    instanceID.DeleteInstanceID();
                }
                catch { }
                var intent = new Intent(this, typeof(MainActivity));
                StartActivity(intent);
                FinishAffinity();
            });
            alert.SetNegativeButton("No", (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void lookupWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strLookupResult = client.ProcessRequest("GetDeclarationDetails", null);
        }

        void lookupWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strLookupResult))
                {
                    List<DeclarationDetailInfo> info = JsonConvert.DeserializeObject<List<DeclarationDetailInfo>>(strLookupResult);
                    var details = (from item in info
                                   select new DeclarationDetail()
                                   {
                                       ID = item.ID,
                                       No = item.No.GetValueOrDefault(),
                                       Declaration = item.Declaration
                                   }).ToList();

                    if (details != null && details.Count > 0)
                        Database.UpdateDeclarationDetails(details);
                }
            }
            catch { }

            if (!CacheManager.IsRecruiter)
            {
                if (CacheManager.JobInfo == null)
                {
                    BackgroundWorker worker = new BackgroundWorker();
                    worker.DoWork += worker_DoWork;
                    worker.RunWorkerCompleted += worker_RunWorkerCompleted;
                    worker.RunWorkerAsync();
                }
                else
                {
                    if (CacheManager.JobInfo != null && CacheManager.FromNotification)
                    {
                        BackgroundWorker shortWorker = new BackgroundWorker();
                        shortWorker.DoWork += shortWorker_DoWork;
                        shortWorker.RunWorkerCompleted += shortWorker_RunWorkerCompleted;
                        shortWorker.RunWorkerAsync();
                    }
                    else
                    {
                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                }
            }
            else
            {
                try { _processProgress.Dismiss(); }
                catch { }
            }
        }

        void shortWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetJobApplicationStatus", headers);
        }

        void shortWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle("Error");
                        alert.SetMessage("Your session has expired. Please login again.");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        if (CacheManager.JobInfo == null)
                        {
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                            alert.SetTitle("Error");
                            alert.SetMessage("Please enable your internet for a while");
                            alert.SetPositiveButton("OK", (senderAlert, args) =>
                            {
                                var intent = new Intent(this, typeof(MainActivity));
                                StartActivity(intent);
                                FinishAffinity();
                            });

                            RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                    else
                    {
                        ShortJobApplicationInfo info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<ShortJobApplicationInfo>(strResult);
                        }
                        catch { }

                        CacheManager.PositionApplied = info.PositionApplied;
                        Database.UpdateUserPositionApplied(info.PositionApplied);
                        var sharedPreferences = PreferenceManager.GetDefaultSharedPreferences(this);
                        try
                        {
                            sharedPreferences.Edit().PutString(QuickstartPreferences.POSITION_APPLIED, info.PositionApplied).Apply();
                        }
                        catch { }

                        CacheManager.JobInfo.ApplicationStatus = info.ApplicationStatus;
                        CacheManager.JobInfo.IsLocked = info.IsLocked;
                        CacheManager.IsLocked = CacheManager.JobInfo.IsLocked.GetValueOrDefault();

                        JobApplication app = Database.GetJobApplication();
                        app.ApplicationStatus = info.ApplicationStatus;
                        app.IsLocked = info.IsLocked.GetValueOrDefault();

                        Database.UpdateJobApplication(app);

                        try
                        {
                            toolbar.FindViewById<TextView>(Resource.Id.lblSubmit).Visibility = ViewStates.Gone;
                        }
                        catch { }

                        var ft = FragmentManager.BeginTransaction();
                        CacheManager.FromNotification = false;
                        SupportActionBar.SetTitle(Resource.String.AverisInfo);
                        ft.Replace(Resource.Id.HomeFrameLayout, new PreBoardingFragment());
                        ft.Commit();
                        navigationView.Menu.GetItem(4).SetChecked(true);
                    }
                }
            }
            catch { }

            if (CacheManager.FromNotification)
                CacheManager.FromNotification = false;

            try { _processProgress.Dismiss(); }
            catch { }
        }


        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetLatestJobApplication", headers);
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle("Error");
                        alert.SetMessage("Your session has expired. Please login again.");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        if (CacheManager.JobInfo == null)
                        {
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                            alert.SetTitle("Error");
                            alert.SetMessage("Please enable your internet for a while");
                            alert.SetPositiveButton("OK", (senderAlert, args) =>
                            {
                                var intent = new Intent(this, typeof(MainActivity));
                                StartActivity(intent);
                                FinishAffinity();
                            });

                            RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                    else
                    {
                        JobApplicationInfo info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<JobApplicationInfo>(strResult);
                        }
                        catch { }

                        if (CacheManager.JobInfo == null)
                        {
                            if (info == null)
                            {
                                JobApplication model = new JobApplication()
                                {
                                    ApplicationStatus = InitialData.ApplicationStatus.New,
                                    IsLocked = false
                                };

                                JobApplication final = Database.InsertJobApplication(model);

                                CacheManager.JobApplicationID = final.ID;

                                CacheManager.JobInfo = new JobApplicationInfo()
                                {
                                    ApplicationStatus = InitialData.ApplicationStatus.New,
                                    IsLocked = false
                                };
                            }
                            else
                            {
                                CacheManager.JobInfo = info;
                                JobApplication model = new JobApplication()
                                {
                                    Title = info.Title,
                                    FirstName = info.FirstName,
                                    LastName = info.LastName,
                                    KnownAs = info.KnownAs,
                                    ChineseCharacter = info.ChineseCharacter,
                                    Gender = info.Gender,
                                    DateOfBirth = info.DateOfBirth,
                                    CountryOfBirth = info.CountryOfBirth,
                                    Nationality = info.Nationality,
                                    Race = info.Race,
                                    MaritalStatus = info.MaritalStatus,
                                    Religion = info.Religion,
                                    IdentityNo = info.IdentityNo,
                                    IsPassport = info.IsPassport,
                                    DateOfIssue = info.DateOfIssue,
                                    DateOfExpiry = info.DateOfExpiry,
                                    CountryOfIssue = info.CountryOfIssue,
                                    EmailAddress = info.EmailAddress,
                                    EmergencyContact = info.EmergencyContact,
                                    ServiceCompleted = info.ServiceCompleted,
                                    HighestRankAttained = info.HighestRankAttained,
                                    ExemptionReason = info.ExemptionReason,
                                    LiabilityForDuties = info.LiabilityForDuties,
                                    Photo = info.Photo,
                                    ApplicationStatus = info.ApplicationStatus,
                                    IsLocked = info.IsLocked.GetValueOrDefault()
                                };

                                JobApplication final = Database.InsertJobApplication(model);

                                if (info.CurrentAddress != null)
                                {
                                    JobApplicationAddress address = new JobApplicationAddress()
                                    {
                                        AddressType = InitialData.AddressType.CurrentAddress,
                                        Address = info.CurrentAddress.Address,
                                        PostalCode = info.CurrentAddress.PostalCode,
                                        Country = info.CurrentAddress.Country,
                                        HomeNumber = info.CurrentAddress.HomeNumber,
                                        MobileNumber = info.CurrentAddress.MobileNumber
                                    };

                                    Database.UpdateAddress(address);
                                }

                                if (info.HomeAddress != null)
                                {
                                    JobApplicationAddress address = new JobApplicationAddress()
                                    {
                                        AddressType = InitialData.AddressType.HomeAddress,
                                        Address = info.HomeAddress.Address,
                                        PostalCode = info.HomeAddress.PostalCode,
                                        Country = info.HomeAddress.Country,
                                        HomeNumber = info.HomeAddress.HomeNumber,
                                        MobileNumber = info.HomeAddress.MobileNumber
                                    };

                                    Database.UpdateAddress(address);
                                }

                                if (info.EmergencyAddress != null)
                                {
                                    JobApplicationAddress address = new JobApplicationAddress()
                                    {
                                        AddressType = InitialData.AddressType.EmergencyAddress,
                                        Address = info.EmergencyAddress.Address,
                                        PostalCode = info.EmergencyAddress.PostalCode,
                                        Country = info.EmergencyAddress.Country,
                                        HomeNumber = info.EmergencyAddress.HomeNumber,
                                        MobileNumber = info.EmergencyAddress.MobileNumber
                                    };

                                    Database.UpdateAddress(address);
                                }

                                if (info.PackageDetail != null)
                                {
                                    JobApplicationPackageDetail detail = new JobApplicationPackageDetail()
                                    {
                                        BaseSalary = info.PackageDetail.BaseSalary,
                                        ExpectedSalary = info.PackageDetail.ExpectedSalary,
                                        ContractualBonus = info.PackageDetail.ContractualBonus,
                                        PerformanceBonus = info.PackageDetail.PerformanceBonus,
                                        HousingAllowance = info.PackageDetail.HousingAllowance,
                                        TransportAllowance = info.PackageDetail.TransportAllowance,
                                        ConnectivityAllowance = info.PackageDetail.ConnectivityAllowance,
                                        ProjectAlowance = info.PackageDetail.ProjectAlowance,
                                        SpecialSkillsAllowance = info.PackageDetail.SpecialSkillsAllowance,
                                        CarParkAllowance = info.PackageDetail.CarParkAllowance,
                                        CarParkClaim = info.PackageDetail.CarParkClaim,
                                        PhoneClaim = info.PackageDetail.PhoneClaim,
                                        MileageClaim = info.PackageDetail.MileageClaim,
                                        MealClaim = info.PackageDetail.MealClaim,
                                        OvertimeClaim = info.PackageDetail.OvertimeClaim,
                                        StandbyClaim = info.PackageDetail.StandbyClaim,
                                        SelfMedicalBenefit = info.PackageDetail.SelfMedicalBenefit,
                                        FamilyMedicalBenefit = info.PackageDetail.FamilyMedicalBenefit,
                                        SelfInsuranceBenefit = info.PackageDetail.SelfInsuranceBenefit,
                                        FamilyInsuranceBenefit = info.PackageDetail.FamilyInsuranceBenefit,
                                        OpticalBenefit = info.PackageDetail.OpticalBenefit,
                                        DentalBenefit = info.PackageDetail.DentalBenefit,
                                        AnnualLeave = info.PackageDetail.AnnualLeave,
                                        MedicalLeave = info.PackageDetail.MedicalLeave,
                                        RetirementBenefit = info.PackageDetail.RetirementBenefit,
                                        EPFNumber = info.PackageDetail.EPFNumber,
                                        SOCSONumber = info.PackageDetail.SOCSONumber,
                                        IncomeTaxNumber = info.PackageDetail.IncomeTaxNumber,
                                        BankAccountNumber = info.PackageDetail.BankAccountNumber
                                    };

                                    Database.UpdatePackageDetail(detail);
                                }

                                foreach (JobApplicationFamilyInfo item in info.Families)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationFamily family = new JobApplicationFamily()
                                    {
                                        ID = item.UID,
                                        FirstName = item.FirstName,
                                        LastName = item.LastName,
                                        Relationship = item.Relationship,
                                        IdentityNo = item.IdentityNo,
                                        JobTitle = item.JobTitle,
                                        Employer = item.Employer,
                                        Gender = item.Gender,
                                        DateOfBirth = item.DateOfBirth,
                                        Nationality = item.Nationality,
                                        CountryOfBirth = item.CountryOfBirth,
                                        IsSameCountry = item.IsSameCountry
                                    };

                                    Database.UpdateFamily(family);
                                }

                                foreach (JobApplicationEducationInfo item in info.Educations)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationEducation education = new JobApplicationEducation()
                                    {
                                        ID = item.UID,
                                        Institution = item.Institution,
                                        Qualification = item.Qualification,
                                        CourseOfStudy = item.CourseOfStudy,
                                        Country = item.Country,
                                        StartDate = item.StartDate,
                                        EndDate = item.EndDate
                                    };

                                    Database.UpdateEducation(education);
                                }

                                foreach (JobApplicationLanguageInfo item in info.Languages)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationLanguage language = new JobApplicationLanguage()
                                    {
                                        ID = item.UID,
                                        Language = item.Language,
                                        ReadAbility = item.ReadAbility,
                                        WriteAbility = item.WriteAbility,
                                        SpeakAbility = item.SpeakAbility
                                    };

                                    Database.UpdateLanguage(language);
                                }

                                foreach (JobApplicationWorkingHistoryInfo item in info.WorkingHistories)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationWorkingHistory working = new JobApplicationWorkingHistory()
                                    {
                                        ID = item.UID,
                                        Company = item.Company,
                                        LastPositionHeld = item.LastPositionHeld,
                                        Country = item.Country,
                                        StartDate = item.StartDate,
                                        EndDate = item.EndDate,
                                        NameOfSuperior = item.NameOfSuperior,
                                        DesignationOfSuperior = item.DesignationOfSuperior,
                                        LastDrawnSalary = item.LastDrawnSalary,
                                        ReasonForLeaving = item.ReasonForLeaving,
                                    };

                                    Database.UpdateWorkingHistory(working);
                                }

                                foreach (JobApplicationActivityInfo item in info.Activities)
                                {
                                    item.UID = Guid.NewGuid();
                                    JobApplicationActivity activity = new JobApplicationActivity()
                                    {
                                        ID = item.UID,
                                        Organisation = item.Organisation,
                                        NatureOfActivities = item.NatureOfActivities,
                                        Country = item.Country,
                                        FromDate = item.FromDate,
                                        ToDate = item.ToDate
                                    };

                                    Database.UpdateActivity(activity);
                                }

                                foreach (JobApplicationReferenceInfo item in info.References)
                                {
                                    JobApplicationReference reference = new JobApplicationReference()
                                    {
                                        Name = item.Name,
                                        Occupation = item.Occupation,
                                        YearsKnown = item.YearsKnown,
                                        Address = item.Address,
                                        Employer = item.Employer,
                                        MobileNumber = item.MobileNumber,
                                        HomeNumber = item.HomeNumber,
                                        OfficeNumber = item.OfficeNumber
                                    };
                                    Database.UpdateReference(reference);
                                }

                                foreach (JobApplicationDeclarationInfo item in info.Declarations)
                                {
                                    JobApplicationDeclaration declaration = new JobApplicationDeclaration()
                                    {
                                        DeclarationID = item.DeclarationID,
                                        Answer = item.Answer,
                                        Remarks = item.Remarks
                                    };
                                    Database.UpdateDeclaration(declaration);
                                }

                                CacheManager.JobApplicationID = final.ID;
                            }

                            CacheManager.IsLocked = CacheManager.JobInfo.IsLocked.GetValueOrDefault();

                            if (CacheManager.JobInfo != null && CacheManager.JobInfo.ApplicationStatus == InitialData.ApplicationStatus.Accepted && CacheManager.FromNotification)
                            {
                                var ft = FragmentManager.BeginTransaction();
                                CacheManager.FromNotification = false;
                                SupportActionBar.SetTitle(Resource.String.AverisInfo);
                                ft.Replace(Resource.Id.HomeFrameLayout, new PreBoardingFragment());
                                ft.Commit();
                                navigationView.Menu.GetItem(4).SetChecked(true);
                            }
                        }
                    }
                }
            }
            catch { }

            if (CacheManager.FromNotification)
                CacheManager.FromNotification = false;

            try { _processProgress.Dismiss(); }
            catch { }
        }

        private void MessageBox(string title, string message)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle(title);
            alert.SetMessage(message);
            alert.SetPositiveButton("OK", (senderAlert, args) =>
            {

            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        private bool ValidateData()
        {
            #region Personal Info
            if (string.IsNullOrEmpty(CacheManager.JobInfo.FirstName))
            {
                MessageBox("Error", "Please input your first name in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Gender))
            {
                MessageBox("Error", "Please input your gender in Personal Information section.");
                return false;
            }
            if (!CacheManager.JobInfo.DateOfBirth.HasValue)
            {
                MessageBox("Error", "Please input your date of birth in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Nationality))
            {
                MessageBox("Error", "Please input your nationality in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Race))
            {
                MessageBox("Error", "Please input your race in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.MaritalStatus))
            {
                MessageBox("Error", "Please input your marital status in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.Religion))
            {
                MessageBox("Error", "Please input your religion in Personal Information section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.IdentityNo))
            {
                MessageBox("Error", "Please input your identity number in Personal Information section.");
                return false;
            }
            if (CacheManager.JobInfo.IsPassport.GetValueOrDefault())
            {
                if (!CacheManager.JobInfo.DateOfIssue.HasValue)
                {
                    MessageBox("Error", "Please input your date of issue in Personal Information section.");
                    return false;
                }
                if (!CacheManager.JobInfo.DateOfExpiry.HasValue)
                {
                    MessageBox("Error", "Please input your date of expiry in Personal Information section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CountryOfIssue))
                {
                    MessageBox("Error", "Please input your country of issue in Personal Information section.");
                    return false;
                }
            }
            #endregion

            #region Contact Details
            if (string.IsNullOrEmpty(CacheManager.JobInfo.EmailAddress))
            {
                MessageBox("Error", "Please input your email address in Contact Details section.");
                return false;
            }
            if (string.IsNullOrEmpty(CacheManager.JobInfo.EmergencyContact))
            {
                MessageBox("Error", "Please input your emergency contact name in Contact Details section.");
                return false;
            }
            if (CacheManager.JobInfo.CurrentAddress == null)
            {
                MessageBox("Error", "Please input your current address in Contact Details section.");
                return false;
            }
            if (CacheManager.JobInfo.CurrentAddress != null)
            {
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.Address))
                {
                    MessageBox("Error", "Please input your current address in Contact Details section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.PostalCode))
                {
                    MessageBox("Error", "Please input your current postal code in Contact Details section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.Country))
                {
                    MessageBox("Error", "Please input your current country in Contact Details section.");
                    return false;
                }
                if (string.IsNullOrEmpty(CacheManager.JobInfo.CurrentAddress.MobileNumber))
                {
                    MessageBox("Error", "Please input your current mobile number in Contact Details section.");
                    return false;
                }
            }
            if (CacheManager.JobInfo.EmergencyAddress == null)
            {
                MessageBox("Error", "Please input your emergency details in Contact Details section.");
                return false;
            }
            if (CacheManager.JobInfo.EmergencyAddress != null)
            {
                if (string.IsNullOrEmpty(CacheManager.JobInfo.EmergencyAddress.MobileNumber))
                {
                    MessageBox("Error", "Please input your emergency contact's mobile number in Contact Details section.");
                    return false;
                }
                else if (CacheManager.JobInfo.EmergencyAddress.MobileNumber == CacheManager.JobInfo.CurrentAddress.MobileNumber)
                {
                    MessageBox("Error", "Emergency contact's mobile number cannot be the same as current mobile number.");
                    return false;
                }
                else if (CacheManager.JobInfo.HomeAddress != null && CacheManager.JobInfo.EmergencyAddress.MobileNumber == CacheManager.JobInfo.HomeAddress.MobileNumber)
                {
                    MessageBox("Error", "Emergency contact's mobile number cannot be the same as home mobile number.");
                    return false;
                }
            }
            #endregion

            #region Family Details
            if (CacheManager.JobInfo.Families != null)
            {
                string name = string.Empty;
                foreach (JobApplicationFamilyInfo info in CacheManager.JobInfo.Families)
                {
                    if (string.IsNullOrEmpty(info.FirstName) ||
                        string.IsNullOrEmpty(info.Relationship))
                    {
                        name = info.FirstName + " " + info.LastName;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox("Error", "Please complete your family information (" + name + ") in Family Details section.");
                    return false;
                }
            }
            #endregion

            #region Education
            if (CacheManager.JobInfo.Educations == null)
            {
                MessageBox("Error", "Please input your education history in Education section.");
                return false;
            }
            if (CacheManager.JobInfo.Educations != null)
            {
                if (CacheManager.JobInfo.Educations.Count == 0)
                {
                    MessageBox("Error", "Please input your family member in Education section.");
                    return false;
                }
                string name = string.Empty;
                foreach (JobApplicationEducationInfo info in CacheManager.JobInfo.Educations)
                {
                    if (string.IsNullOrEmpty(info.Institution) || string.IsNullOrEmpty(info.Country) ||
                        !info.StartDate.HasValue)
                    {
                        name = info.Institution;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox("Error", "Please complete your education history (" + name + ") in Education section.");
                    return false;
                }
            }
            #endregion

            #region Language
            if (CacheManager.JobInfo.Languages == null)
            {
                MessageBox("Error", "Please input your language skills in Language Skills section.");
                return false;
            }
            if (CacheManager.JobInfo.Languages != null)
            {
                if (CacheManager.JobInfo.Languages.Count == 0)
                {
                    MessageBox("Error", "Please input your language skills in Language Skills section.");
                    return false;
                }
                string name = string.Empty;
                foreach (JobApplicationLanguageInfo info in CacheManager.JobInfo.Languages)
                {
                    if (string.IsNullOrEmpty(info.Language))
                    {
                        name = info.Language;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox("Error", "Please complete your language skills (" + name + ") in Language Skills section.");
                    return false;
                }
            }
            #endregion

            #region Working History
            if (CacheManager.JobInfo.WorkingHistories != null)
            {
                string name = string.Empty;
                foreach (JobApplicationWorkingHistoryInfo info in CacheManager.JobInfo.WorkingHistories)
                {
                    if (string.IsNullOrEmpty(info.Company) || string.IsNullOrEmpty(info.Country) ||
                        !info.StartDate.HasValue || !info.LastDrawnSalary.HasValue ||
                        string.IsNullOrEmpty(info.LastPositionHeld) || string.IsNullOrEmpty(info.ReasonForLeaving))
                    {
                        name = info.Company;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox("Error", "Please complete your working history (" + name + ") in Working History section.");
                    return false;
                }
            }
            #endregion

            #region Activity
            if (CacheManager.JobInfo.Activities != null)
            {
                string name = string.Empty;
                foreach (JobApplicationActivityInfo info in CacheManager.JobInfo.Activities)
                {
                    if (string.IsNullOrEmpty(info.Organisation) || string.IsNullOrEmpty(info.Country) ||
                        !info.FromDate.HasValue ||
                        string.IsNullOrEmpty(info.NatureOfActivities))
                    {
                        name = info.Organisation;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox("Error", "Please complete your activities information (" + name + ") in Social/Political Activities section.");
                    return false;
                }
            }
            #endregion

            #region Reference
            if (CacheManager.JobInfo.References != null)
            {
                string name = string.Empty;
                foreach (JobApplicationReferenceInfo info in CacheManager.JobInfo.References)
                {
                    if (string.IsNullOrEmpty(info.Name) || !info.YearsKnown.HasValue ||
                        string.IsNullOrEmpty(info.Occupation) || string.IsNullOrEmpty(info.MobileNumber))
                    {
                        name = info.Name;
                    }
                }
                if (!string.IsNullOrEmpty(name))
                {
                    MessageBox("Error", "Please complete your reference details (" + name + ") in References section.");
                    return false;
                }
            }
            #endregion

            return true;
        }
    }
}