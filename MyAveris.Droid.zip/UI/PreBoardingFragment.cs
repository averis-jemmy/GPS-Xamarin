using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using Newtonsoft.Json;
using MyAverisEntity;
using MyAverisCommon;
using Google.YouTube.Player;

namespace MyAveris.Droid
{
    [Activity(Label = "PreBoardingFragment")]
    public class PreBoardingFragment : Fragment, IYouTubePlayerOnInitializedListener
    {
        ProgressDialog _processProgress;
        String strResult, strWelcomeSpeechCode;
        RelativeLayout layWelcomePart;
        LinearLayout layWelcomeMessage, layWelcomeMessage7, layWelcomeMessage1;
        TextView tvWelcomeMessage7, tvWelcomeMessage1, tvFinalWelcomeMessage7;
        TextView tvPosition, tvBuddy, tvSupervisor, tvDepartment, tvHRContact;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            _processProgress = new ProgressDialog(this.Activity);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            CacheManager.ProcessProgress = new ProgressDialog(this.Activity);
            CacheManager.ProcessProgress.Indeterminate = true;
            CacheManager.ProcessProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            CacheManager.ProcessProgress.SetMessage("Loading...");
            CacheManager.ProcessProgress.SetCancelable(false);
        }

        public override void OnResume()
        {
            base.OnResume();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.PreBoardingFragment, container, false);
            layWelcomePart = view.FindViewById<RelativeLayout>(Resource.Id.layWelcomePart);
            layWelcomeMessage = view.FindViewById<LinearLayout>(Resource.Id.layWelcomeMessage);
            layWelcomeMessage7 = view.FindViewById<LinearLayout>(Resource.Id.layWelcomeMessage7);
            layWelcomeMessage1 = view.FindViewById<LinearLayout>(Resource.Id.layWelcomeMessage1);
            tvWelcomeMessage7 = view.FindViewById<TextView>(Resource.Id.tvWelcomeMessage7);
            tvWelcomeMessage1 = view.FindViewById<TextView>(Resource.Id.tvWelcomeMessage1);
            tvFinalWelcomeMessage7 = view.FindViewById<TextView>(Resource.Id.tvFinalWelcomeMessage7);
            tvPosition = view.FindViewById<TextView>(Resource.Id.tvPosition);
            tvBuddy = view.FindViewById<TextView>(Resource.Id.tvBuddyName);
            tvHRContact = view.FindViewById<TextView>(Resource.Id.tvHRContact);
            tvSupervisor = view.FindViewById<TextView>(Resource.Id.tvSupervisor);
            tvDepartment = view.FindViewById<TextView>(Resource.Id.tvDepartment);

            view.FindViewById<RelativeLayout>(Resource.Id.layFollowAveris).Click += FollowAveris_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layDressCode).Click += DressCode_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layOfficeLocation).Click += OfficeLocation_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layLeaveClaims).Click += LeaveClaims_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layHelpdesk).Click += Helpdesk_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layFunAtWork).Click += FunAtWork_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layFacilities).Click += Facilities_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layTransportation).Click += Transportation_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layParking).Click += Parking_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layWorkingHours).Click += WorkingHours_Click;
            view.FindViewById<RelativeLayout>(Resource.Id.layFoodBeverage).Click += FoodBeverage_Click;

            _processProgress.Show();
            layWelcomePart.Visibility = ViewStates.Gone;
            layWelcomeMessage.Visibility = ViewStates.Gone;
            layWelcomeMessage7.Visibility = ViewStates.Gone;
            layWelcomeMessage1.Visibility = ViewStates.Gone;

            if (CacheManager.JobInfo != null && CacheManager.JobInfo.ApplicationStatus == InitialData.ApplicationStatus.Accepted)
            {
                layWelcomePart.Visibility = ViewStates.Visible;
                view.FindViewById<LinearLayout>(Resource.Id.layOnBoarding).Visibility = ViewStates.Visible;
                BackgroundWorker refreshWorker = new BackgroundWorker();
                refreshWorker.DoWork += refreshWorker_DoWork;
                refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
                refreshWorker.RunWorkerAsync();
            }
            else
            {
                view.FindViewById<LinearLayout>(Resource.Id.layOnBoarding).Visibility = ViewStates.Gone;
                try { _processProgress.Dismiss(); }
                catch { }
            }

            return view;
        }

        public override void OnPause()
        {
            base.OnPause();
        }

        public override void OnDestroyView()
        {
            GC.Collect();
            base.OnDestroyView();
        }

        public override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        void FoodBeverage_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(FoodBeverageActivity));
            StartActivity(intent);
        }

        void WorkingHours_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(WorkingHoursActivity));
            StartActivity(intent);
        }

        void Parking_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(ParkingActivity));
            StartActivity(intent);
        }

        void FunAtWork_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(FunAtAverisActivity));
            StartActivity(intent);
        }

        void Transportation_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(TransportationActivity));
            StartActivity(intent);
        }

        void Facilities_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(FacilitiesActivity));
            StartActivity(intent);
        }

        void LeaveClaims_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(LeaveClaimsActivity));
            StartActivity(intent);
        }

        void Helpdesk_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(HelpdeskActivity));
            StartActivity(intent);
        }

        void OfficeLocation_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(AverisLocationActivity));
            StartActivity(intent);
        }

        void FollowAveris_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(FollowAverisActivity));
            StartActivity(intent);
        }

        void DressCode_Click(object sender, EventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            var intent = new Intent(this.Activity, typeof(DressCodeActivity));
            StartActivity(intent);
        }

        public override void OnCreateContextMenu(IContextMenu menu, View v, IContextMenuContextMenuInfo menuInfo)
        {
            base.OnCreateContextMenu(menu, v, menuInfo);
            if (v.Id == Resource.Id.listPhoto)
            {
                MenuInflater inflater = this.Activity.MenuInflater;
                inflater.Inflate(Resource.Menu.menu_list, menu);
            }
        }

        public override bool OnContextItemSelected(IMenuItem item)
        {
            Android.Widget.AdapterView.AdapterContextMenuInfo info = (Android.Widget.AdapterView.AdapterContextMenuInfo)item.MenuInfo;
            switch (item.ItemId)
            {
                case Resource.Id.menuOpen:
                    return true;
                case Resource.Id.menuDelete:
                    return true;
                default:
                    return base.OnContextItemSelected(item);
            }
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetPreBoardingInfo", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle("Error");
                        alert.SetMessage("Your session has expired. Please login again.");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });

                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        layWelcomeMessage.Visibility = ViewStates.Visible;

                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                    else
                    {
                        PreBoardingInfo info = JsonConvert.DeserializeObject<PreBoardingInfo>(strResult);
                        if ((info.JoinDate.GetValueOrDefault() - DateTime.Now).TotalDays < 1)
                        {
                            layWelcomeMessage1.Visibility = ViewStates.Visible;
                            string name = string.Empty;
                            name += info.FirstName;
                            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(info.LastName))
                                name += " ";
                            name += info.LastName;
                            tvWelcomeMessage1.Text = tvWelcomeMessage1.Text.Replace("FIRST_NAME_LAST_NAME", name);
                        }
                        else if ((info.JoinDate.GetValueOrDefault() - DateTime.Now).TotalDays < 7)
                        {
                            layWelcomeMessage7.Visibility = ViewStates.Visible;
                            string name = string.Empty;
                            name += info.FirstName;
                            if (!string.IsNullOrEmpty(name) && !string.IsNullOrEmpty(info.LastName))
                                name += " ";
                            name += info.LastName;
                            tvWelcomeMessage7.Text = tvWelcomeMessage7.Text.Replace("FIRST_NAME_LAST_NAME", name);
                            tvPosition.Text = info.Position;
                            tvBuddy.Text = info.BuddyName;
                            tvHRContact.Text = info.HRContactPerson;
                            tvSupervisor.Text = info.Supervisor;
                            tvDepartment.Text = info.Department;
                            tvFinalWelcomeMessage7.Text = tvFinalWelcomeMessage7.Text
                                .Replace("RECRUITER_NAME", info.RecruiterName)
                                .Replace("JOIN_DATE", info.JoinDate.GetValueOrDefault().ToString("dd-MMM-yyyy"));
                        }
                        else
                        {
                            layWelcomeMessage.Visibility = ViewStates.Visible;
                        }

                        //BackgroundWorker welcomeSpeechWorker = new BackgroundWorker();
                        //welcomeSpeechWorker.DoWork += welcomeSpeechWorker_DoWork;
                        //welcomeSpeechWorker.RunWorkerCompleted += welcomeSpeechWorker_RunWorkerCompleted;
                        //welcomeSpeechWorker.RunWorkerAsync();

                        try { _processProgress.Dismiss(); }
                        catch { }
                    }
                }
                else
                {
                    layWelcomeMessage.Visibility = ViewStates.Visible;

                    try { _processProgress.Dismiss(); }
                    catch { }
                }
            }
            catch
            {
                layWelcomeMessage.Visibility = ViewStates.Visible;

                try { _processProgress.Dismiss(); }
                catch { }
            }
        }

        void welcomeSpeechWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetWelcomeSpeechCode", null);
        }

        void welcomeSpeechWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                strWelcomeSpeechCode = JsonConvert.DeserializeObject<string>(strResult);
            }
            catch { }

            if (!string.IsNullOrEmpty(strWelcomeSpeechCode))
            {
                YouTubePlayerFragment mYoutubePlayerFragment = new YouTubePlayerFragment();
                mYoutubePlayerFragment.Initialize(CacheManager.DeveloperKey, this);
                FragmentTransaction fragmentTransaction = FragmentManager.BeginTransaction();
                fragmentTransaction.Replace(Resource.Id.youtube_fragment, mYoutubePlayerFragment);
                fragmentTransaction.Commit();
            }

            try { _processProgress.Dismiss(); }
            catch { }
        }

        public void OnInitializationFailure(IYouTubePlayerProvider provider, YouTubeInitializationResult errorReason)
        {
            if (errorReason.IsUserRecoverableError)
            {
                errorReason.GetErrorDialog(this.Activity, 1).Show();
            }
            else
            {
                String errorMessage = String.Format(
                        GetString(Resource.String.ErrorMessage), errorReason.ToString());
                Toast.MakeText(this.Activity, errorMessage, ToastLength.Long).Show();
            }
        }

        public void OnInitializationSuccess(IYouTubePlayerProvider p0, IYouTubePlayer yPlayer, bool p2)
        {
            if (yPlayer != null)
                yPlayer.CueVideo(strWelcomeSpeechCode);
        }
    }
}