using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Content.PM;
using System.IO;
using Java.Lang;

namespace MyAveris.Droid
{
    [Activity(Label = "MYAveris", Icon = "@drawable/icon", NoHistory = true, Theme = "@style/Theme.Splash", ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation)]
    public class DummyActivity : Activity
    {
        protected override void OnCreate(Bundle bundle)
        {
            base.OnCreate(bundle);

            Database.newInstance(Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
            Database.CreateTables();

            CacheManager.Init(Application.Context);

            CacheManager.FromNotification = true;

            var intent = new Intent(this, typeof(MainActivity));
            StartActivity(intent);
            FinishAffinity();
        }
    }
}