using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Newtonsoft.Json;

namespace MyAveris.Droid
{
    [Activity(Label = "ApplicationListFragment")]
    public class ApplicationListFragment : Fragment
    {
        ProgressDialog _processProgress;
        String strResult;
        ListView listView;

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            _processProgress = new ProgressDialog(this.Activity);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            CacheManager.ProcessProgress = new ProgressDialog(this.Activity);
            CacheManager.ProcessProgress.Indeterminate = true;
            CacheManager.ProcessProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            CacheManager.ProcessProgress.SetMessage("Loading...");
            CacheManager.ProcessProgress.SetCancelable(false);
        }

        public override void OnResume()
        {
            base.OnResume();

            CacheManager.JobApplicationInfos = new List<ShortJobApplicationInfo>();
            listView.Adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);

            _processProgress.Show();

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        public override void OnPause()
        {
            base.OnPause();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            View view = inflater.Inflate(Resource.Layout.ApplicationListFragment, container, false);
            listView = view.FindViewById<ListView>(Resource.Id.listJob); // get reference to the ListView in the layout
            // populate the listview with data
            listView.Adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);
            listView.ItemClick += OnListItemClick;  // to be defined
            return view;
        }

        void OnListItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            CacheManager.ProcessProgress.Show();
            CacheManager.JobID = CacheManager.JobApplicationInfos[e.Position].ID;
            CacheManager.PositionApplied = CacheManager.JobApplicationInfos[e.Position].PositionApplied;

            BackgroundWorker worker = new BackgroundWorker();
            worker.DoWork += worker_DoWork;
            worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            worker.RunWorkerAsync();
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            strResult = client.ProcessRequest("GetAllJobApplications", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle("Error");
                        alert.SetMessage("Your session has expired. Please login again.");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle("Error");
                        alert.SetMessage("Failed to refresh");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        List<ShortJobApplicationInfo> infos = JsonConvert.DeserializeObject<List<ShortJobApplicationInfo>>(strResult);
                        if (infos != null && infos.Count > 0)
                        {
                            CacheManager.JobApplicationInfos = infos;
                            listView.Adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);
                        }
                        else
                        {
                            listView.Adapter = new CustomApplicationList(this.Activity, CacheManager.JobApplicationInfos);

                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                            alert.SetTitle("Info");
                            alert.SetMessage("No more pending job applications");
                            alert.SetPositiveButton("OK", (senderAlert, args) =>
                            {
                            });

                            this.Activity.RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                }
                else
                {
                    Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                    alert.SetTitle("Error");
                    alert.SetMessage("Failed to refresh");
                    alert.SetPositiveButton("OK", (senderAlert, args) =>
                    {
                    });

                    this.Activity.RunOnUiThread(() =>
                    {
                        alert.Show();
                    });
                }
            }
            catch
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                alert.SetTitle("Error");
                alert.SetMessage("Failed to refresh");
                alert.SetPositiveButton("OK", (senderAlert, args) =>
                {
                });

                this.Activity.RunOnUiThread(() =>
                {
                    alert.Show();
                });
            }

            try
            {
                _processProgress.Dismiss();
            }
            catch { }
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.JobID.ToString() + "\"");
            strResult = client.ProcessRequest("GetJobApplication", headers);
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        try
                        {
                            CacheManager.ProcessProgress.Dismiss();
                        }
                        catch { }
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle("Error");
                        alert.SetMessage("Your session has expired. Please login again.");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                            var intent = new Intent(this.Activity, typeof(MainActivity));
                            StartActivity(intent);
                            this.Activity.FinishAffinity();
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        try
                        {
                            CacheManager.ProcessProgress.Dismiss();
                        }
                        catch { }
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                        alert.SetTitle("Error");
                        alert.SetMessage("Failed to retrieve data");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                        });

                        this.Activity.RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        JobApplicationInfo info = null;
                        try
                        {
                            info = JsonConvert.DeserializeObject<JobApplicationInfo>(strResult);
                        }
                        catch { }

                        if (info != null)
                        {
                            CacheManager.JobInfo = info;
                            var intent = new Intent(this.Activity, typeof(JobApplicationDisplayActivity));
                            StartActivity(intent);
                        }
                        else
                        {
                            try
                            {
                                CacheManager.ProcessProgress.Dismiss();
                            }
                            catch { }
                            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this.Activity);
                            alert.SetTitle("Error");
                            alert.SetMessage("Failed to retrieve data");
                            alert.SetPositiveButton("OK", (senderAlert, args) =>
                            {
                            });

                            this.Activity.RunOnUiThread(() =>
                            {
                                alert.Show();
                            });
                        }
                    }
                }
                else
                {
                    try
                    {
                        CacheManager.ProcessProgress.Dismiss();
                    }
                    catch { }
                }
            }
            catch
            {
                try
                {
                    CacheManager.ProcessProgress.Dismiss();
                }
                catch { }
            }
        }
    }
}