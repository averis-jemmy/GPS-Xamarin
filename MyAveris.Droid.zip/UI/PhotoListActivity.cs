using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Provider;
using Java.IO;
using Android.Content.PM;
using Android.Graphics;
using Android.Media;
using System.IO;
using System.ComponentModel;
using MyAverisClient;
using MyAverisEntity;
using Newtonsoft.Json;
using Android.Support.V7.App;
using Square.Picasso;
using Square.OkHttp;

namespace MyAveris.Droid
{
    [Activity(Label = "PhotoListActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class PhotoListActivity : AppCompatActivity
    {
        ProgressDialog _processProgress;
        String strResult;
        PhotoGridViewAdapter adapter;
        GridView gv;

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.PhotoList);

            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                    Database.CreateTables();

                    CacheManager.Init(Application.Context);

                    var user = CacheManager.GetFromSharedPreferences();

                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;
                    CacheManager.LoadData();
                }
            }
            catch { }

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.Photo);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);

            gv = FindViewById<GridView>(Resource.Id.grid_view);
            gv.ScrollStateChanged += (sender, e) =>
            {
                //Picasso picasso = new Picasso.Builder(this)
                //        .Downloader(new OkHttpDownloader(UnsafeOkHttpClient.GetUnsafeOkHttpClient()))
                //        .Build();

                Picasso picasso = Picasso.With(this);
                if (e.ScrollState == ScrollState.Idle || e.ScrollState == ScrollState.TouchScroll)
                {
                    picasso.ResumeTag(this);
                }
                else
                {
                    picasso.PauseTag(this);
                }
            };
            gv.ItemClick += GridView_ItemClick;

            _processProgress = new ProgressDialog(this);
            _processProgress.Indeterminate = true;
            _processProgress.SetProgressStyle(ProgressDialogStyle.Spinner);
            _processProgress.SetMessage("Loading...");
            _processProgress.SetCancelable(false);

            _processProgress.Show();

            BackgroundWorker refreshWorker = new BackgroundWorker();
            refreshWorker.DoWork += refreshWorker_DoWork;
            refreshWorker.RunWorkerCompleted += refreshWorker_RunWorkerCompleted;
            refreshWorker.RunWorkerAsync();
        }

        void GridView_ItemClick(object sender, AdapterView.ItemClickEventArgs e)
        {
            CacheManager.PhotoAdapterPosition = e.Position;
            var intent = new Intent(this, typeof(PhotoViewPagerActivity));
            StartActivity(intent);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    Finish();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        void refreshWorker_DoWork(object sender, DoWorkEventArgs e)
        {
            List<KeyValuePair<string, string>> headers = new List<KeyValuePair<string, string>>();
            headers.Add(new KeyValuePair<string, string>("UserID", CacheManager.UserID.ToString()));
            headers.Add(new KeyValuePair<string, string>("TokenID", CacheManager.TokenID.ToString()));

            RestClient client = new RestClient(CacheManager.URL, HttpVerb.POST, ContentTypeString.JSON, "\"" + CacheManager.Category + "\"");
            strResult = client.ProcessRequest("GetPhotoFromCategory", headers);
        }

        void refreshWorker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            try
            {
                if (!string.IsNullOrEmpty(strResult))
                {
                    if (strResult.ToUpper().Contains("IT IS FORBIDDEN"))
                    {
                        CacheManager.ClearSharedPreferences();
                        Database.ClearData();
                        CacheManager.JobInfo = null;
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle("Error");
                        alert.SetMessage("Your session has expired. Please login again.");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                            var intent = new Intent(this, typeof(MainActivity));
                            StartActivity(intent);
                            FinishAffinity();
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else if (strResult.Contains("ErrorMessage"))
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle("Error");
                        alert.SetMessage("Failed to refresh");
                        alert.SetPositiveButton("OK", (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                    }
                    else
                    {
                        List<PhotoInfo> infos = JsonConvert.DeserializeObject<List<PhotoInfo>>(strResult);
                        var photos = (from item in infos
                                      select new PhotoInfo()
                                      {
                                          ID = item.ID,
                                          Name = item.Name,
                                          Category = item.Category,
                                          FilePath = CacheManager.ImageURL + item.FilePath
                                      }).ToList();

                        CacheManager.Photos = photos;
                        adapter = new PhotoGridViewAdapter(this, photos);
                        gv.Adapter = adapter;
                    }
                }
            }
            catch { }
            try { _processProgress.Dismiss(); }
            catch { }
        }

        public override void OnLowMemory()
        {
            GC.Collect();
            base.OnLowMemory();
        }

        protected override void OnPause()
        {
            GC.Collect();
            base.OnPause();
        }

        protected override void OnDestroy()
        {
            GC.Collect();
            base.OnDestroy();
        }
    }
}