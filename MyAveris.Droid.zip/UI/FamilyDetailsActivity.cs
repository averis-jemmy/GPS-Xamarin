using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAveris.Droid
{
    [Activity(Label = "FamilyDetailsActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class FamilyDetailsActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.FamilyDetails);

            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                    Database.CreateTables();

                    CacheManager.Init(Application.Context);

                    var user = CacheManager.GetFromSharedPreferences();

                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;
                    CacheManager.LoadData();
                }
            }
            catch { }

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.FamilyDetails);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.FamilyInfo != null && !CacheManager.IsLocked)
            {
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Visible;
                FindViewById<Button>(Resource.Id.btnDelete).Click += Delete_OnClick;
            }
            else
                FindViewById<Button>(Resource.Id.btnDelete).Visibility = ViewStates.Gone;

            FindViewById<Spinner>(Resource.Id.spinRelationship).Adapter = new SpinnerData(this, CommonData.Relationships);
            FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).Adapter = new SpinnerData(this, CommonData.GetCountries());
            FindViewById<Spinner>(Resource.Id.spinNationality).Adapter = new SpinnerData(this, CommonData.GetCountries());

            if (!CacheManager.IsLocked)
                FindViewById<TextView>(Resource.Id.etDOB).Click += DOB_OnClick;

            if (CacheManager.FamilyInfo != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        private void DOB_OnClick(object sender, EventArgs e)
        {
            DateTime? selected = null;
            try
            {
                selected = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOB).Text,
                    "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
            }
            catch { }

            DatePickerFragment frag = DatePickerFragment.NewInstance(delegate(DateTime time)
            {
                FindViewById<TextView>(Resource.Id.etDOB).Text = time.ToString("dd - MMM - yyyy");
            }, selected, DateTime.Now.AddYears(-80), DateTime.Now.AddYears(-1));
            frag.Show(FragmentManager, DatePickerFragment.TAG);
        }

        void Delete_OnClick(object sender, EventArgs e)
        {
            Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
            alert.SetTitle("Logout");
            alert.SetMessage("Do you really want to delete this information?");
            alert.SetPositiveButton("Yes", (senderAlert, args) =>
            {
                JobApplicationFamily model = new JobApplicationFamily()
                {
                    ID = CacheManager.FamilyInfo.UID
                };

                Database.DeleteFamily(model);

                if (CacheManager.JobInfo.Families.Count >= CacheManager.FamilyPosition + 1 &&
                            CacheManager.JobInfo.Families[CacheManager.FamilyPosition] != null)
                {
                    CacheManager.JobInfo.Families.RemoveAt(CacheManager.FamilyPosition);
                }

                Finish();
            });
            alert.SetNegativeButton("No", (senderAlert, args) =>
            {
            });

            RunOnUiThread(() =>
            {
                alert.Show();
            });
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            FindViewById<EditText>(Resource.Id.etFirstName).Text = CacheManager.FamilyInfo.FirstName;
            FindViewById<EditText>(Resource.Id.etLastName).Text = CacheManager.FamilyInfo.LastName;
            FindViewById<Spinner>(Resource.Id.spinRelationship).SetSelection(CommonData.Relationships.IndexOf(CacheManager.FamilyInfo.Relationship));
            FindViewById<EditText>(Resource.Id.etIdentityNo).Text = CacheManager.FamilyInfo.IdentityNo;
            FindViewById<EditText>(Resource.Id.etJobTitle).Text = CacheManager.FamilyInfo.JobTitle;
            FindViewById<EditText>(Resource.Id.etEmployer).Text = CacheManager.FamilyInfo.Employer;

            if (CacheManager.FamilyInfo.IsSameCountry.HasValue)
            {
                if (CacheManager.FamilyInfo.IsSameCountry.GetValueOrDefault())
                    FindViewById<RadioButton>(Resource.Id.rbYes).Checked = true;
                else
                    FindViewById<RadioButton>(Resource.Id.rbNo).Checked = true;
            }

            if (CacheManager.FamilyInfo.Gender == "M")
                FindViewById<RadioButton>(Resource.Id.rbMale).Checked = true;
            if (CacheManager.FamilyInfo.Gender == "F")
                FindViewById<RadioButton>(Resource.Id.rbFemale).Checked = true;

            if (CacheManager.FamilyInfo.DateOfBirth.HasValue)
                FindViewById<TextView>(Resource.Id.etDOB).Text = CacheManager.FamilyInfo.DateOfBirth.Value.ToString("dd - MMM - yyyy");

            FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.FamilyInfo.CountryOfBirth));
            FindViewById<Spinner>(Resource.Id.spinNationality).SetSelection(CommonData.GetCountries().IndexOf(CacheManager.FamilyInfo.Nationality));
        }

        private void LockData()
        {
            FindViewById<RadioButton>(Resource.Id.rbYes).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbNo).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbMale).Enabled = false;
            FindViewById<RadioButton>(Resource.Id.rbFemale).Enabled = false;

            FindViewById<EditText>(Resource.Id.etFirstName).Enabled = false;
            FindViewById<EditText>(Resource.Id.etLastName).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinRelationship).Enabled = false;
            FindViewById<EditText>(Resource.Id.etIdentityNo).Enabled = false;
            FindViewById<EditText>(Resource.Id.etJobTitle).Enabled = false;
            FindViewById<EditText>(Resource.Id.etEmployer).Enabled = false;

            FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).Enabled = false;
            FindViewById<Spinner>(Resource.Id.spinNationality).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.Families == null)
                    CacheManager.JobInfo.Families = new List<JobApplicationFamilyInfo>();

                if (CacheManager.FamilyInfo == null)
                {
                    JobApplicationFamilyInfo info = new JobApplicationFamilyInfo();
                    info.UID = Guid.NewGuid();
                    info.FirstName = FindViewById<EditText>(Resource.Id.etFirstName).Text;
                    info.LastName = FindViewById<EditText>(Resource.Id.etLastName).Text;
                    info.Relationship = FindViewById<Spinner>(Resource.Id.spinRelationship).SelectedItem.ToString();
                    info.IdentityNo = FindViewById<EditText>(Resource.Id.etIdentityNo).Text;
                    info.JobTitle = FindViewById<EditText>(Resource.Id.etJobTitle).Text;
                    info.Employer = FindViewById<EditText>(Resource.Id.etEmployer).Text;

                    if (FindViewById<RadioButton>(Resource.Id.rbMale).Checked)
                        info.Gender = "M";
                    if (FindViewById<RadioButton>(Resource.Id.rbFemale).Checked)
                        info.Gender = "F";

                    try
                    {
                        info.DateOfBirth = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOB).Text,
                        "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                    }
                    catch
                    {
                        info.DateOfBirth = null;
                    }

                    info.CountryOfBirth = FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).SelectedItem.ToString();
                    info.Nationality = FindViewById<Spinner>(Resource.Id.spinNationality).SelectedItem.ToString();

                    if (!FindViewById<RadioButton>(Resource.Id.rbYes).Checked && !FindViewById<RadioButton>(Resource.Id.rbNo).Checked)
                        info.IsSameCountry = null;
                    else
                        info.IsSameCountry = FindViewById<RadioButton>(Resource.Id.rbYes).Checked;

                    CacheManager.JobInfo.Families.Add(info);

                    JobApplicationFamily model = new JobApplicationFamily()
                    {
                        ID = info.UID,
                        FirstName = info.FirstName,
                        LastName = info.LastName,
                        Relationship = info.Relationship,
                        IdentityNo = info.IdentityNo,
                        JobTitle = info.JobTitle,
                        Employer = info.Employer,
                        Gender = info.Gender,
                        DateOfBirth = info.DateOfBirth,
                        Nationality = info.Nationality,
                        CountryOfBirth = info.CountryOfBirth,
                        IsSameCountry = info.IsSameCountry
                    };

                    Database.UpdateFamily(model);
                }
                else
                {
                    if (CacheManager.JobInfo.Families.Count >= CacheManager.FamilyPosition + 1 &&
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition] != null)
                    {
                        Guid UID = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].UID;
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition] = new JobApplicationFamilyInfo();
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].UID = UID;

                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].FirstName = FindViewById<EditText>(Resource.Id.etFirstName).Text;
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].LastName = FindViewById<EditText>(Resource.Id.etLastName).Text;
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Relationship = FindViewById<Spinner>(Resource.Id.spinRelationship).SelectedItem.ToString();
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].IdentityNo = FindViewById<EditText>(Resource.Id.etIdentityNo).Text;
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].JobTitle = FindViewById<EditText>(Resource.Id.etJobTitle).Text;
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Employer = FindViewById<EditText>(Resource.Id.etEmployer).Text;

                        if (FindViewById<RadioButton>(Resource.Id.rbMale).Checked)
                            CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Gender = "M";
                        if (FindViewById<RadioButton>(Resource.Id.rbFemale).Checked)
                            CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Gender = "F";

                        try
                        {
                            CacheManager.JobInfo.Families[CacheManager.FamilyPosition].DateOfBirth = DateTime.ParseExact(FindViewById<TextView>(Resource.Id.etDOB).Text,
                            "dd - MMM - yyyy", System.Globalization.CultureInfo.InvariantCulture);
                        }
                        catch
                        {
                            CacheManager.JobInfo.Families[CacheManager.FamilyPosition].DateOfBirth = null;
                        }

                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].CountryOfBirth = FindViewById<Spinner>(Resource.Id.spinCountryOfBirth).SelectedItem.ToString();
                        CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Nationality = FindViewById<Spinner>(Resource.Id.spinNationality).SelectedItem.ToString();

                        if (!FindViewById<RadioButton>(Resource.Id.rbYes).Checked && !FindViewById<RadioButton>(Resource.Id.rbNo).Checked)
                            CacheManager.JobInfo.Families[CacheManager.FamilyPosition].IsSameCountry = null;
                        else
                            CacheManager.JobInfo.Families[CacheManager.FamilyPosition].IsSameCountry = FindViewById<RadioButton>(Resource.Id.rbYes).Checked;

                        JobApplicationFamily model = new JobApplicationFamily()
                        {
                            ID = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].UID,
                            FirstName = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].FirstName,
                            LastName = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].LastName,
                            Relationship = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Relationship,
                            IdentityNo = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].IdentityNo,
                            JobTitle = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].JobTitle,
                            Employer = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Employer,
                            Gender = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Gender,
                            DateOfBirth = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].DateOfBirth,
                            Nationality = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].Nationality,
                            CountryOfBirth = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].CountryOfBirth,
                            IsSameCountry = CacheManager.JobInfo.Families[CacheManager.FamilyPosition].IsSameCountry
                        };

                        Database.UpdateFamily(model);
                    }
                }
            }

            Finish();
        }

        private bool ValidateData()
        {
            if (string.IsNullOrEmpty(FindViewById<EditText>(Resource.Id.etFirstName).Text))
            {
                Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                alert.SetTitle("Info");
                alert.SetMessage("The first name is not entered. Data will not be saved. Proceed?");
                alert.SetPositiveButton("Yes", (senderAlert, args) =>
                {
                    Finish();
                });
                alert.SetNegativeButton("No", (senderAlert, args) =>
                {
                });

                RunOnUiThread(() =>
                {
                    alert.Show();
                });
                return false;
            }
            else
            {
                string firstName = FindViewById<EditText>(Resource.Id.etFirstName).Text;
                string lastName = FindViewById<EditText>(Resource.Id.etLastName).Text;
                if (CacheManager.JobInfo.Families != null)
                {
                    bool exists = false;
                    foreach (JobApplicationFamilyInfo info in CacheManager.JobInfo.Families)
                    {
                        if (info.FirstName == firstName && info.LastName == lastName &&
                            (CacheManager.FamilyInfo == null ||
                            (CacheManager.FamilyInfo.FirstName != firstName && CacheManager.FamilyInfo.LastName != lastName)))
                        {
                            exists = true;
                        }
                    }

                    if (exists)
                    {
                        Android.Support.V7.App.AlertDialog.Builder alert = new Android.Support.V7.App.AlertDialog.Builder(this);
                        alert.SetTitle("Info");
                        alert.SetMessage("The same name has been entered. Data will not be saved. Proceed?");
                        alert.SetPositiveButton("Yes", (senderAlert, args) =>
                        {
                            Finish();
                        });
                        alert.SetNegativeButton("No", (senderAlert, args) =>
                        {
                        });

                        RunOnUiThread(() =>
                        {
                            alert.Show();
                        });
                        return false;
                    }
                }
            }
            return true;
        }
    }
}