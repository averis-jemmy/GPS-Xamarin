using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Java.Lang.Reflect;
using Android.Animation;
using MyAverisEntity;
using MyAverisCommon;

namespace MyAveris.Droid
{
    [Activity(Label = "PackageDetailActivity", WindowSoftInputMode = SoftInput.StateHidden, Theme = "@style/MyTheme.Base", ConfigurationChanges = Android.Content.PM.ConfigChanges.Orientation | Android.Content.PM.ConfigChanges.ScreenSize)]
    public class PackageDetailActivity : AppCompatActivity
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.PackageDetail);

            try
            {
                if (CacheManager.mContext == null)
                {
                    Database.newInstance(System.IO.Path.Combine(System.Environment.GetFolderPath(System.Environment.SpecialFolder.Personal), "myaveris.db3"));
                    Database.CreateTables();

                    CacheManager.Init(Application.Context);

                    var user = CacheManager.GetFromSharedPreferences();

                    CacheManager.TokenID = user.TokenID;
                    CacheManager.UserID = user.UserID;
                    CacheManager.IsRecruiter = user.IsRecruiter;
                    CacheManager.HasProfilePicture = user.HasProfilePicture;
                    CacheManager.PositionApplied = user.PositionApplied;
                    CacheManager.LoadData();
                }
            }
            catch { }

            // Initialize toolbar
            var toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.AppBar);
            SetSupportActionBar(toolbar);
            SupportActionBar.SetTitle(Resource.String.PackageDetail);
            SupportActionBar.SetDisplayHomeAsUpEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            if (!CacheManager.IsLocked)
            {
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Visibility = ViewStates.Visible;
                toolbar.FindViewById<TextView>(Resource.Id.lblSave).Click += Save_OnClick;
            }

            if (CacheManager.JobInfo != null && CacheManager.JobInfo.PackageDetail != null)
            {
                PopulateData();

                if (CacheManager.IsLocked)
                    LockData();
            }
        }

        void Save_OnClick(object sender, EventArgs e)
        {
            UpdateData();
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            switch (item.ItemId)
            {
                case Android.Resource.Id.Home:
                    UpdateData();
                    return true;
            }
            return base.OnOptionsItemSelected(item);
        }

        public override void OnBackPressed()
        {
            UpdateData();
        }

        private void PopulateData()
        {
            try
            {
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.BaseSalary))
                        FindViewById<EditText>(Resource.Id.etBaseSalary).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.BaseSalary);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.ExpectedSalary))
                        FindViewById<EditText>(Resource.Id.etExpectedSalary).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ExpectedSalary);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.ContractualBonus))
                        FindViewById<EditText>(Resource.Id.etContractualBonus).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ContractualBonus);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.PerformanceBonus))
                        FindViewById<EditText>(Resource.Id.etPerformanceBonus).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.PerformanceBonus);
                }
                catch { }

                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.HousingAllowance))
                        FindViewById<EditText>(Resource.Id.etHousingAllowance).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.HousingAllowance);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.TransportAllowance))
                        FindViewById<EditText>(Resource.Id.etTransportAllowance).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.TransportAllowance);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.ConnectivityAllowance))
                        FindViewById<EditText>(Resource.Id.etConnectivityAllowance).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ConnectivityAllowance);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.ProjectAlowance))
                        FindViewById<EditText>(Resource.Id.etProjectAllowance).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.ProjectAlowance);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.SpecialSkillsAllowance))
                        FindViewById<EditText>(Resource.Id.etSpecialSkillsAllowance).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.SpecialSkillsAllowance);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.CarParkAllowance))
                        FindViewById<EditText>(Resource.Id.etCarParkAllowance).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.CarParkAllowance);
                }
                catch { }

                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.CarParkClaim))
                        FindViewById<EditText>(Resource.Id.etCarParkClaim).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.CarParkClaim);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.PhoneClaim))
                        FindViewById<EditText>(Resource.Id.etHandphoneClaim).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.PhoneClaim);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.MileageClaim))
                        FindViewById<EditText>(Resource.Id.etMileageClaim).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.MileageClaim);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.MealClaim))
                        FindViewById<EditText>(Resource.Id.etMealClaim).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.MealClaim);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.OvertimeClaim))
                        FindViewById<EditText>(Resource.Id.etOvertimeClaim).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.OvertimeClaim);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.StandbyClaim))
                        FindViewById<EditText>(Resource.Id.etStandbyClaim).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.StandbyClaim);
                }
                catch { }

                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.SelfMedicalBenefit))
                        FindViewById<EditText>(Resource.Id.etSelfMedicalBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.SelfMedicalBenefit);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.FamilyMedicalBenefit))
                        FindViewById<EditText>(Resource.Id.etFamilyMedicalBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.FamilyMedicalBenefit);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.SelfInsuranceBenefit))
                        FindViewById<EditText>(Resource.Id.etSelfInsuranceBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.SelfInsuranceBenefit);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.FamilyInsuranceBenefit))
                        FindViewById<EditText>(Resource.Id.etFamilyInsuranceBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.FamilyInsuranceBenefit);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.DentalBenefit))
                        FindViewById<EditText>(Resource.Id.etDentalBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.DentalBenefit);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.OpticalBenefit))
                        FindViewById<EditText>(Resource.Id.etOpticalBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.OpticalBenefit);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.AnnualLeave))
                        FindViewById<EditText>(Resource.Id.etAnnualLeave).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.AnnualLeave);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.MedicalLeave))
                        FindViewById<EditText>(Resource.Id.etMedicalLeave).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.MedicalLeave);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.RetirementBenefit))
                        FindViewById<EditText>(Resource.Id.etRetirementBenefit).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.RetirementBenefit);
                }
                catch { }

                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.EPFNumber))
                        FindViewById<EditText>(Resource.Id.etEPFNo).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.EPFNumber);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.SOCSONumber))
                        FindViewById<EditText>(Resource.Id.etSOCSONo).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.SOCSONumber);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.IncomeTaxNumber))
                        FindViewById<EditText>(Resource.Id.etIncomeTaxNo).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.IncomeTaxNumber);
                }
                catch { }
                try
                {
                    if (!string.IsNullOrEmpty(CacheManager.JobInfo.PackageDetail.BankAccountNumber))
                        FindViewById<EditText>(Resource.Id.etBankDetails).Text = Cryptography.Decryption(CacheManager.JobInfo.PackageDetail.BankAccountNumber);
                }
                catch { }
            }
            catch { }
        }

        private void LockData()
        {
            FindViewById<EditText>(Resource.Id.etBaseSalary).Enabled = false;
            FindViewById<EditText>(Resource.Id.etExpectedSalary).Enabled = false;
            FindViewById<EditText>(Resource.Id.etContractualBonus).Enabled = false;
            FindViewById<EditText>(Resource.Id.etPerformanceBonus).Enabled = false;

            FindViewById<EditText>(Resource.Id.etHousingAllowance).Enabled = false;
            FindViewById<EditText>(Resource.Id.etTransportAllowance).Enabled = false;
            FindViewById<EditText>(Resource.Id.etConnectivityAllowance).Enabled = false;
            FindViewById<EditText>(Resource.Id.etProjectAllowance).Enabled = false;
            FindViewById<EditText>(Resource.Id.etSpecialSkillsAllowance).Enabled = false;
            FindViewById<EditText>(Resource.Id.etCarParkAllowance).Enabled = false;

            FindViewById<EditText>(Resource.Id.etCarParkClaim).Enabled = false;
            FindViewById<EditText>(Resource.Id.etHandphoneClaim).Enabled = false;
            FindViewById<EditText>(Resource.Id.etMileageClaim).Enabled = false;
            FindViewById<EditText>(Resource.Id.etMealClaim).Enabled = false;
            FindViewById<EditText>(Resource.Id.etOvertimeClaim).Enabled = false;
            FindViewById<EditText>(Resource.Id.etStandbyClaim).Enabled = false;

            FindViewById<EditText>(Resource.Id.etSelfMedicalBenefit).Enabled = false;
            FindViewById<EditText>(Resource.Id.etFamilyMedicalBenefit).Enabled = false;
            FindViewById<EditText>(Resource.Id.etSelfInsuranceBenefit).Enabled = false;
            FindViewById<EditText>(Resource.Id.etFamilyInsuranceBenefit).Enabled = false;
            FindViewById<EditText>(Resource.Id.etDentalBenefit).Enabled = false;
            FindViewById<EditText>(Resource.Id.etOpticalBenefit).Enabled = false;
            FindViewById<EditText>(Resource.Id.etAnnualLeave).Enabled = false;
            FindViewById<EditText>(Resource.Id.etMedicalLeave).Enabled = false;
            FindViewById<EditText>(Resource.Id.etRetirementBenefit).Enabled = false;

            FindViewById<EditText>(Resource.Id.etEPFNo).Enabled = false;
            FindViewById<EditText>(Resource.Id.etSOCSONo).Enabled = false;
            FindViewById<EditText>(Resource.Id.etIncomeTaxNo).Enabled = false;
            FindViewById<EditText>(Resource.Id.etBankDetails).Enabled = false;
        }

        private void UpdateData()
        {
            try
            {
                InputMethodManager inputManager = (InputMethodManager)this.GetSystemService(Context.InputMethodService);
                var currentFocus = this.CurrentFocus;
                if (currentFocus != null)
                {
                    inputManager.HideSoftInputFromWindow(currentFocus.WindowToken, HideSoftInputFlags.None);
                }
            }
            catch { }

            if (!CacheManager.IsLocked)
            {
                if (!ValidateData())
                    return;

                if (CacheManager.JobInfo.PackageDetail == null)
                    CacheManager.JobInfo.PackageDetail = new JobApplicationPackageDetailInfo();

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etBaseSalary).Text);
                    CacheManager.JobInfo.PackageDetail.BaseSalary = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etBaseSalary).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.BaseSalary = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etExpectedSalary).Text);
                    CacheManager.JobInfo.PackageDetail.ExpectedSalary = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etExpectedSalary).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.ExpectedSalary = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etContractualBonus).Text);
                    CacheManager.JobInfo.PackageDetail.ContractualBonus = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etContractualBonus).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.ContractualBonus = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etPerformanceBonus).Text);
                    CacheManager.JobInfo.PackageDetail.PerformanceBonus = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etPerformanceBonus).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.PerformanceBonus = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etHousingAllowance).Text);
                    CacheManager.JobInfo.PackageDetail.HousingAllowance = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etHousingAllowance).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.HousingAllowance = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etTransportAllowance).Text);
                    CacheManager.JobInfo.PackageDetail.TransportAllowance = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etTransportAllowance).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.TransportAllowance = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etConnectivityAllowance).Text);
                    CacheManager.JobInfo.PackageDetail.ConnectivityAllowance = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etConnectivityAllowance).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.ConnectivityAllowance = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etProjectAllowance).Text);
                    CacheManager.JobInfo.PackageDetail.ProjectAlowance = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etProjectAllowance).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.ProjectAlowance = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etSpecialSkillsAllowance).Text);
                    CacheManager.JobInfo.PackageDetail.SpecialSkillsAllowance = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etSpecialSkillsAllowance).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.SpecialSkillsAllowance = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etCarParkAllowance).Text);
                    CacheManager.JobInfo.PackageDetail.CarParkAllowance = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etCarParkAllowance).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.CarParkAllowance = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etCarParkClaim).Text);
                    CacheManager.JobInfo.PackageDetail.CarParkClaim = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etCarParkClaim).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.CarParkClaim = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etHandphoneClaim).Text);
                    CacheManager.JobInfo.PackageDetail.PhoneClaim = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etHandphoneClaim).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.PhoneClaim = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etMileageClaim).Text);
                    CacheManager.JobInfo.PackageDetail.MileageClaim = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etMileageClaim).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.MileageClaim = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etMealClaim).Text);
                    CacheManager.JobInfo.PackageDetail.MealClaim = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etMealClaim).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.MealClaim = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etOvertimeClaim).Text);
                    CacheManager.JobInfo.PackageDetail.OvertimeClaim = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etOvertimeClaim).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.OvertimeClaim = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etStandbyClaim).Text);
                    CacheManager.JobInfo.PackageDetail.StandbyClaim = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etStandbyClaim).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.StandbyClaim = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etSelfMedicalBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.SelfMedicalBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etSelfMedicalBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.SelfMedicalBenefit = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etFamilyMedicalBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.FamilyMedicalBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etFamilyMedicalBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.FamilyMedicalBenefit = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etSelfInsuranceBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.SelfInsuranceBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etSelfInsuranceBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.SelfInsuranceBenefit = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etFamilyInsuranceBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.FamilyInsuranceBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etFamilyInsuranceBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.FamilyInsuranceBenefit = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etDentalBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.DentalBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etDentalBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.DentalBenefit = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etOpticalBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.OpticalBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etOpticalBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.OpticalBenefit = string.Empty;
                }

                try
                {
                    int number = int.Parse(FindViewById<EditText>(Resource.Id.etAnnualLeave).Text);
                    CacheManager.JobInfo.PackageDetail.AnnualLeave = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etAnnualLeave).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.AnnualLeave = string.Empty;
                }

                try
                {
                    int number = int.Parse(FindViewById<EditText>(Resource.Id.etMedicalLeave).Text);
                    CacheManager.JobInfo.PackageDetail.MedicalLeave = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etMedicalLeave).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.MedicalLeave = string.Empty;
                }

                try
                {
                    decimal number = decimal.Parse(FindViewById<EditText>(Resource.Id.etRetirementBenefit).Text);
                    CacheManager.JobInfo.PackageDetail.RetirementBenefit = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etRetirementBenefit).Text);
                }
                catch
                {
                    CacheManager.JobInfo.PackageDetail.RetirementBenefit = string.Empty;
                }

                CacheManager.JobInfo.PackageDetail.EPFNumber = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etEPFNo).Text);
                CacheManager.JobInfo.PackageDetail.SOCSONumber = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etSOCSONo).Text);
                CacheManager.JobInfo.PackageDetail.IncomeTaxNumber = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etIncomeTaxNo).Text);
                CacheManager.JobInfo.PackageDetail.BankAccountNumber = Cryptography.Encryption(FindViewById<EditText>(Resource.Id.etBankDetails).Text);

                JobApplicationPackageDetail model = new JobApplicationPackageDetail()
                {
                    BaseSalary = CacheManager.JobInfo.PackageDetail.BaseSalary,
                    ExpectedSalary = CacheManager.JobInfo.PackageDetail.ExpectedSalary,
                    ContractualBonus = CacheManager.JobInfo.PackageDetail.ContractualBonus,
                    PerformanceBonus = CacheManager.JobInfo.PackageDetail.PerformanceBonus,
                    HousingAllowance = CacheManager.JobInfo.PackageDetail.HousingAllowance,
                    TransportAllowance = CacheManager.JobInfo.PackageDetail.TransportAllowance,
                    ConnectivityAllowance = CacheManager.JobInfo.PackageDetail.ConnectivityAllowance,
                    ProjectAlowance = CacheManager.JobInfo.PackageDetail.ProjectAlowance,
                    SpecialSkillsAllowance = CacheManager.JobInfo.PackageDetail.SpecialSkillsAllowance,
                    CarParkAllowance = CacheManager.JobInfo.PackageDetail.CarParkAllowance,
                    CarParkClaim = CacheManager.JobInfo.PackageDetail.CarParkClaim,
                    PhoneClaim = CacheManager.JobInfo.PackageDetail.PhoneClaim,
                    MileageClaim = CacheManager.JobInfo.PackageDetail.MileageClaim,
                    MealClaim = CacheManager.JobInfo.PackageDetail.MealClaim,
                    OvertimeClaim = CacheManager.JobInfo.PackageDetail.OvertimeClaim,
                    StandbyClaim = CacheManager.JobInfo.PackageDetail.StandbyClaim,
                    SelfMedicalBenefit = CacheManager.JobInfo.PackageDetail.SelfMedicalBenefit,
                    FamilyMedicalBenefit = CacheManager.JobInfo.PackageDetail.FamilyMedicalBenefit,
                    SelfInsuranceBenefit = CacheManager.JobInfo.PackageDetail.SelfInsuranceBenefit,
                    FamilyInsuranceBenefit = CacheManager.JobInfo.PackageDetail.FamilyInsuranceBenefit,
                    OpticalBenefit = CacheManager.JobInfo.PackageDetail.OpticalBenefit,
                    DentalBenefit = CacheManager.JobInfo.PackageDetail.DentalBenefit,
                    AnnualLeave = CacheManager.JobInfo.PackageDetail.AnnualLeave,
                    MedicalLeave = CacheManager.JobInfo.PackageDetail.MedicalLeave,
                    RetirementBenefit = CacheManager.JobInfo.PackageDetail.RetirementBenefit,
                    EPFNumber = CacheManager.JobInfo.PackageDetail.EPFNumber,
                    SOCSONumber = CacheManager.JobInfo.PackageDetail.SOCSONumber,
                    IncomeTaxNumber = CacheManager.JobInfo.PackageDetail.IncomeTaxNumber,
                    BankAccountNumber = CacheManager.JobInfo.PackageDetail.BankAccountNumber
                };

                Database.UpdatePackageDetail(model);
            }

            Finish();
        }

        private bool ValidateData()
        {
            return true;
        }
    }
}