using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisEntity;
using Android.Graphics;

namespace MyAveris.Droid
{
    public static class CommonData
    {
        public static List<string> Departments = new List<string>()
        {
            "",
            "FA",
            "HR",
            "IT",
            "Shipping Doc",
            "Centre Support",
            "Others"
        };

        public static List<string> Titles = new List<string>()
        {
            "",
            "Mr",
            "Mrs",
            "Ms",
            "Miss",
            "Dr",
            "Prof",
            "Others"
        };

        public static List<KeyValuePair<string, string>> CountryCodes = new List<KeyValuePair<string, string>>()
        {
            new KeyValuePair<string, string>("", ""),
            new KeyValuePair<string, string>("Malaysia", "60"),
            new KeyValuePair<string, string>("Algeria", "213"),
            new KeyValuePair<string, string>("Angola", "244"),
            new KeyValuePair<string, string>("Argentina", "54"),
            new KeyValuePair<string, string>("Armenia", "374"),
            new KeyValuePair<string, string>("Australia", "61"),
            new KeyValuePair<string, string>("Austria", "43"),
            new KeyValuePair<string, string>("Azerbaijan", "994"),
            new KeyValuePair<string, string>("Bahrain", "973"),
            new KeyValuePair<string, string>("Belarus", "375"),
            new KeyValuePair<string, string>("Belgium", "32"),
            new KeyValuePair<string, string>("Belize", "501"),
            new KeyValuePair<string, string>("Bolivia", "591"),
            new KeyValuePair<string, string>("Botswana", "267"),
            new KeyValuePair<string, string>("Brazil", "55"),
            new KeyValuePair<string, string>("Brunei Darussalam", "673"),
            new KeyValuePair<string, string>("Bulgaria", "359"),
            new KeyValuePair<string, string>("Canada", "1"),
            new KeyValuePair<string, string>("Chile", "56"),
            new KeyValuePair<string, string>("China", "86"),
            new KeyValuePair<string, string>("Colombia", "57"),
            new KeyValuePair<string, string>("Costa Rica", "506"),
            new KeyValuePair<string, string>("Croatia", "385"),
            new KeyValuePair<string, string>("Cyprus", "357"),
            new KeyValuePair<string, string>("Czech Republic", "420"),
            new KeyValuePair<string, string>("Denmark", "45"),
            new KeyValuePair<string, string>("Ecuador", "593"),
            new KeyValuePair<string, string>("Egypt", "20"),
            new KeyValuePair<string, string>("El Salvador", "503"),
            new KeyValuePair<string, string>("Estonia", "372"),
            new KeyValuePair<string, string>("Finland", "358"),
            new KeyValuePair<string, string>("France", "33"),
            new KeyValuePair<string, string>("Germany", "49"),
            new KeyValuePair<string, string>("Ghana", "233"),
            new KeyValuePair<string, string>("Greece", "30"),
            new KeyValuePair<string, string>("Guatemala", "502"),
            new KeyValuePair<string, string>("Guyana", "592"),
            new KeyValuePair<string, string>("Honduras", "504"),
            new KeyValuePair<string, string>("Hong Kong", "852"),
            new KeyValuePair<string, string>("Hungary", "36"),
            new KeyValuePair<string, string>("Iceland", "354"),
            new KeyValuePair<string, string>("India", "91"),
            new KeyValuePair<string, string>("Indonesia", "62"),
            new KeyValuePair<string, string>("Ireland", "353"),
            new KeyValuePair<string, string>("Israel", "972"),
            new KeyValuePair<string, string>("Italy", "39"),
            new KeyValuePair<string, string>("Japan", "81"),
            new KeyValuePair<string, string>("Jordan", "962"),
            new KeyValuePair<string, string>("Kazakhstan", "7"),
            new KeyValuePair<string, string>("Kenya", "254"),
            new KeyValuePair<string, string>("Kuwait", "965"),
            new KeyValuePair<string, string>("Latvia", "371"),
            new KeyValuePair<string, string>("Lebanon", "961"),
            new KeyValuePair<string, string>("Lithuania", "370"),
            new KeyValuePair<string, string>("Luxembourg", "352"),
            new KeyValuePair<string, string>("Macau", "853"),
            new KeyValuePair<string, string>("Macedonia", "389"),
            new KeyValuePair<string, string>("Madagascar", "261"),
            new KeyValuePair<string, string>("Mali", "223"),
            new KeyValuePair<string, string>("Malta", "356"),
            new KeyValuePair<string, string>("Mauritius", "230"),
            new KeyValuePair<string, string>("Mexico", "52"),
            new KeyValuePair<string, string>("Moldova", "373"),
            new KeyValuePair<string, string>("Netherlands", "31"),
            new KeyValuePair<string, string>("New Zealand", "64"),
            new KeyValuePair<string, string>("Nicaragua", "505"),
            new KeyValuePair<string, string>("Niger", "227"),
            new KeyValuePair<string, string>("Nigeria", "234"),
            new KeyValuePair<string, string>("North Korea", "850"),
            new KeyValuePair<string, string>("Norway", "47"),
            new KeyValuePair<string, string>("Oman", "968"),
            new KeyValuePair<string, string>("Pakistan", "92"),
            new KeyValuePair<string, string>("Panama", "507"),
            new KeyValuePair<string, string>("Paraguay", "595"),
            new KeyValuePair<string, string>("Peru", "51"),
            new KeyValuePair<string, string>("Philippines", "63"),
            new KeyValuePair<string, string>("Poland", "48"),
            new KeyValuePair<string, string>("Portugal", "351"),
            new KeyValuePair<string, string>("Qatar", "974"),
            new KeyValuePair<string, string>("Romania", "40"),
            new KeyValuePair<string, string>("Russia", "7"),
            new KeyValuePair<string, string>("Saudi Arabia", "966"),
            new KeyValuePair<string, string>("Senegal", "221"),
            new KeyValuePair<string, string>("Singapore", "65"),
            new KeyValuePair<string, string>("Slovakia", "421"),
            new KeyValuePair<string, string>("Slovenia", "386"),
            new KeyValuePair<string, string>("South Africa", "27"),
            new KeyValuePair<string, string>("South Korea", "82"),
            new KeyValuePair<string, string>("Spain", "34"),
            new KeyValuePair<string, string>("Sri Lanka", "94"),
            new KeyValuePair<string, string>("Suriname", "597"),
            new KeyValuePair<string, string>("Sweden", "46"),
            new KeyValuePair<string, string>("Switzerland", "41"),
            new KeyValuePair<string, string>("Taiwan", "886"),
            new KeyValuePair<string, string>("Tanzania", "255"),
            new KeyValuePair<string, string>("Thailand", "66"),
            new KeyValuePair<string, string>("Tunisia", "216"),
            new KeyValuePair<string, string>("Turkey", "90"),
            new KeyValuePair<string, string>("Uganda", "256"),
            new KeyValuePair<string, string>("United Arab Emirates", "971"),
            new KeyValuePair<string, string>("United Kingdom", "44"),
            new KeyValuePair<string, string>("United States", "1"),
            new KeyValuePair<string, string>("Uruguay", "598"),
            new KeyValuePair<string, string>("Uzbekistan", "998"),
            new KeyValuePair<string, string>("Venezuela", "58"),
            new KeyValuePair<string, string>("Vietnam", "84"),
            new KeyValuePair<string, string>("Yemen", "967"),
            new KeyValuePair<string, string>("Others", "")
        };

        public static List<string> GetCountries()
        {
            var countries = (from item in CountryCodes
                             select item.Key);
            return countries.ToList();
        }

        public static string GetCountryCode(string key)
        {
            var countryCode = (from item in CountryCodes
                             where item.Key == key
                             select item.Value).FirstOrDefault();
            return countryCode;
        }

        public static List<string> Races = new List<string>()
        {
            "",
            "Malay",
            "Chinese",
            "Indian",
            "Others"
        };

        public static List<string> MaritalStatuses = new List<string>()
        {
            "",
            "Single",
            "Married",
            "Divorced",
            "Others"
        };

        public static List<string> Religions = new List<string>()
        {
            "",
            "Muslim",
            "Christian",
            "Buddhist",
            "Hindu",
            "Others"
        };

        public static List<string> Relationships = new List<string>()
        {
            "",
            "Spouse",
            "Son",
            "Daughter",
            "Father",
            "Mother",
            "Brother",
            "Sister"
        };

        public static List<string> Languages = new List<string>()
        {
            "",
            "English",
            "Mandarin",
            "Bahasa",
            "Other"
        };
    }
}