using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisEntity;
using Square.Picasso;
using System.IO;
using Android.Graphics;
using Square.OkHttp;
using Android.Support.V4.View;

namespace MyAveris.Droid
{
    public class PhotoPagerAdapter : PagerAdapter
    {
        private readonly Context context;
        private readonly List<PhotoInfo> photos = new List<PhotoInfo>();

        public PhotoPagerAdapter(Context context, List<PhotoInfo> photos)
        {
            this.context = context;
            this.photos = photos;
        }

        public override int Count
        {
            get { return photos.Count; }
        }

        public override void DestroyItem(ViewGroup container, int position, Java.Lang.Object objectValue)
        {
            container.RemoveView((View)objectValue);
        }

        public override Java.Lang.Object InstantiateItem(ViewGroup container, int position)
        {
            LayoutInflater inflater = LayoutInflater.From(context);
            View itemView = inflater.Inflate(Resource.Layout.PhotoPagerItem, container, false);

            ImageView imageView = (ImageView)itemView.FindViewById(Resource.Id.imageView);

            // Get the image URL for the current position.
            PhotoInfo photo = photos[position];

            Picasso picasso = Picasso.With(context);
            picasso.Load(photo.FilePath)
                .Placeholder(Resource.Drawable.placeholder)
                .Error(Resource.Drawable.error)
                .Resize(750, 1334)
                .CenterInside()
                .Tag(context)
                .Into(imageView);

            container.AddView(itemView);

            return itemView;
        }

        public override bool IsViewFromObject(View view, Java.Lang.Object objectValue)
        {
            return view == objectValue;
        }

        public override void RestoreState(IParcelable state, Java.Lang.ClassLoader loader)
        {
            
        }

        public override IParcelable SaveState()
        {
            return null;
        }
    }
}