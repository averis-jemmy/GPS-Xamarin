using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisEntity;
using Square.Picasso;
using System.IO;
using Android.Graphics;
using Square.OkHttp;

namespace MyAveris.Droid
{
    public class PhotoGridViewAdapter : BaseAdapter<PhotoInfo>
    {
        private readonly Context context;
        private readonly List<PhotoInfo> photos = new List<PhotoInfo>();

        public PhotoGridViewAdapter(Context context, List<PhotoInfo> photos)
        {
            this.context = context;

            // Ensure we get a different ordering of images on each run.
            //var copy = urls.ToList();
            //Shuffle(copy);

            // Triple up the list.
            this.photos = photos;
            //urls.AddRange(copy);
            //urls.AddRange(copy);
        }

        public override View GetView(int position, View convertView, ViewGroup parent)
        {
            SquaredImageView view = convertView as SquaredImageView;
            if (view == null)
            {
                view = new SquaredImageView(context);
                view.SetScaleType(ImageView.ScaleType.CenterCrop);
            }

            // Get the image URL for the current position.
            PhotoInfo photo = this[position];

            //Picasso picasso = new Picasso.Builder(context)
            //    .Downloader(new OkHttpDownloader(UnsafeOkHttpClient.GetUnsafeOkHttpClient()))
            //    .Build();

            Picasso picasso = Picasso.With(context);

            // Trigger the download of the URL asynchronously into the image view.
            picasso.Load(photo.FilePath)
                .Placeholder(Resource.Drawable.placeholder)
                .Error(Resource.Drawable.error)
                .Fit()
                .Tag(context)
                .Into(view);

            return view;
        }

        public override int Count
        {
            get { return photos.Count; }
        }

        public override PhotoInfo this[int position]
        {
            get { return photos[position]; }
        }

        public override long GetItemId(int position)
        {
            return position;
        }

        private static void Shuffle<T>(IList<T> list)
        {
            Random rng = new Random();
            int n = list.Count;
            while (n > 1)
            {
                n--;
                int k = rng.Next(n + 1);
                T value = list[k];
                list[k] = list[n];
                list[n] = value;
            }
        }
    }
}