using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using MyAverisEntity;
using Android.Util;

namespace MyAveris.Droid
{
    /// <summary>
    /// An image view which always remains square with respect to its width.
    /// </summary>
    public class SquaredImageView : ImageView
    {
        public SquaredImageView(Context context)
            : base(context)
        {
        }

        public SquaredImageView(Context context, IAttributeSet attrs)
            : base(context, attrs)
        {
        }

        protected override void OnMeasure(int widthMeasureSpec, int heightMeasureSpec)
        {
            base.OnMeasure(widthMeasureSpec, heightMeasureSpec);

            SetMeasuredDimension(MeasuredWidth, MeasuredWidth);
        }
    }
}