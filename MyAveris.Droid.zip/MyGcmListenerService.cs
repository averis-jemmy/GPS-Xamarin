﻿using System;
using Android;
using Android.App;
using Android.Content;
using Android.Gms.Gcm;
using Android.Media;
using Android.Support.V4.App;
using Android.Util;
using Android.OS;

namespace MyAveris.Droid
{
    [Service(Exported = false), IntentFilter(new[] { "com.google.android.c2dm.intent.RECEIVE" })]
    public class MyGcmListenerService : GcmListenerService
    {
        const string TAG = "MyGcmListenerService";

        public override void OnMessageReceived(string from, Bundle data)
        {
            var title = data.GetString("title");
            var message = data.GetString("message");
            Log.Debug(TAG, "From: " + from);
            Log.Debug(TAG, "Message: " + message);

            SendNotification(title, message);
        }

        void SendNotification(string title, string message)
        {
            if (string.IsNullOrEmpty(title))
                title = "MYAveris Message";

            var intent = new Intent(this, typeof(DummyActivity));
            intent.AddFlags(ActivityFlags.ClearTop);
            var pendingIntent = PendingIntent.GetActivity(this, 0, intent, PendingIntentFlags.OneShot);

            var defaultSoundUri = RingtoneManager.GetDefaultUri(RingtoneType.Notification);

            var notificationBuilder = new NotificationCompat.Builder(this)
                .SetSmallIcon(Resource.Drawable.ic_stat_ic_notification)
                .SetContentTitle(title)
                .SetContentText(message)
                .SetAutoCancel(true)
                .SetSound(defaultSoundUri)
                .SetStyle(new NotificationCompat.BigTextStyle().BigText(message))
                .SetContentIntent(pendingIntent);

            var notificationManager = (NotificationManager)GetSystemService(Context.NotificationService);
            notificationManager.Notify(0, notificationBuilder.Build());
        }
    }
}