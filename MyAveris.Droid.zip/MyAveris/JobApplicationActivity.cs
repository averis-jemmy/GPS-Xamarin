﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAveris
{
    [Table("JobApplicationActivity")]
    public class JobApplicationActivity
    {
        [PrimaryKey, Column("ID")]
        public Guid ID { get; set; }
        public string Organisation { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string Country { get; set; }
        public string NatureOfActivities { get; set; }
    }
}
