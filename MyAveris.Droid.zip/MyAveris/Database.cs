﻿using SQLite;
using System;
using System.Collections.Generic;
using System.IO;

namespace MyAveris
{
    public static class Database
    {
        private static SQLiteConnection db;

        public static SQLiteConnection newInstance(string dbPath)
        {
            try
            {
                db = new SQLiteConnection(dbPath);
                return db;
            }
            catch { }
            return null;
        }

        public static void CreateTables()
        {
            try
            {
                db.CreateTable<User>();
                db.CreateTable<DeclarationDetail>();
                db.CreateTable<JobApplication>();
                db.CreateTable<JobApplicationAddress>();
                db.CreateTable<JobApplicationFamily>();
                db.CreateTable<JobApplicationEducation>();
                db.CreateTable<JobApplicationLanguage>();
                db.CreateTable<JobApplicationWorkingHistory>();
                db.CreateTable<JobApplicationActivity>();
                db.CreateTable<JobApplicationReference>();
                db.CreateTable<JobApplicationPackageDetail>();
                db.CreateTable<JobApplicationDeclaration>();
            }
            catch { }
        }

        public static void DropTables()
        {
            try
            {
                db.DropTable<User>();
                db.DropTable<DeclarationDetail>();
                db.DropTable<JobApplication>();
                db.DropTable<JobApplicationAddress>();
                db.DropTable<JobApplicationFamily>();
                db.DropTable<JobApplicationEducation>();
                db.DropTable<JobApplicationLanguage>();
                db.DropTable<JobApplicationWorkingHistory>();
                db.DropTable<JobApplicationActivity>();
                db.DropTable<JobApplicationReference>();
                db.DropTable<JobApplicationPackageDetail>();
                db.DropTable<JobApplicationDeclaration>();
            }
            catch { }
        }

        public static void UpdateDeclarationDetails(List<DeclarationDetail> details)
        {
            try
            {
                if (db.Table<DeclarationDetail>().Count() != 0)
                {
                    db.DeleteAll<DeclarationDetail>();
                }

                db.InsertAll(details);
            }
            catch { }
        }

        public static List<DeclarationDetail> GetDeclarationDetails()
        {
            try
            {
                var model = (from s in db.Table<DeclarationDetail>()
                             orderby s.No
                             select s);

                List<DeclarationDetail> infos = new List<DeclarationDetail>();

                foreach (DeclarationDetail item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static User GetUser()
        {
            try
            {
                var model = (from s in db.Table<User>()
                             select s).FirstOrDefault();
                return model;
            }
            catch { }

            return null;
        }

        public static void DeleteJobApplicationForm()
        {
            try
            {
                db.DeleteAll<JobApplication>();
                db.DeleteAll<JobApplicationAddress>();
                db.DeleteAll<JobApplicationFamily>();
                db.DeleteAll<JobApplicationEducation>();
                db.DeleteAll<JobApplicationLanguage>();
                db.DeleteAll<JobApplicationWorkingHistory>();
                db.DeleteAll<JobApplicationActivity>();
                db.DeleteAll<JobApplicationReference>();
                db.DeleteAll<JobApplicationPackageDetail>();
                db.DeleteAll<JobApplicationDeclaration>();
            }
            catch { }
        }

        public static void ClearData()
        {
            try
            {
                db.DeleteAll<User>();
                db.DeleteAll<JobApplication>();
                db.DeleteAll<JobApplicationAddress>();
                db.DeleteAll<JobApplicationFamily>();
                db.DeleteAll<JobApplicationEducation>();
                db.DeleteAll<JobApplicationLanguage>();
                db.DeleteAll<JobApplicationWorkingHistory>();
                db.DeleteAll<JobApplicationActivity>();
                db.DeleteAll<JobApplicationReference>();
                db.DeleteAll<JobApplicationPackageDetail>();
                db.DeleteAll<JobApplicationDeclaration>();
            }
            catch { }
        }

        public static User UpdateUser(User model)
        {
            try
            {
                if (db.Table<User>().Count() != 0)
                {
                    db.DeleteAll<User>();
                }

                db.Insert(model);

                try
                {
                    var item = (from s in db.Table<User>()
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static void UpdateUserDeviceToken(string deviceToken)
        {
            try
            {
                var item = (from s in db.Table<User>()
                            select s).FirstOrDefault();
                if (item != null)
                {
                    item.DeviceToken = deviceToken;
                    db.Update(item);
                }
            }
            catch { }
        }

        public static void UpdateUserHasProfilePicture(bool hasProfilePicture)
        {
            try
            {
                var item = (from s in db.Table<User>()
                            select s).FirstOrDefault();
                if (item != null)
                {
                    item.HasProfilePicture = hasProfilePicture;
                    db.Update(item);
                }
            }
            catch { }
        }

        public static void UpdateUserPositionApplied(string positionAppleid)
        {
            try
            {
                var item = (from s in db.Table<User>()
                            select s).FirstOrDefault();
                if (item != null)
                {
                    item.PositionApplied = positionAppleid;
                    db.Update(item);
                }
            }
            catch { }
        }

        public static JobApplicationAddress GetAddress(string addressType)
        {
            try
            {
                var model = (from s in db.Table<JobApplicationAddress>()
                             where s.AddressType == addressType
                             select s).FirstOrDefault();
                return model;
            }
            catch { }

            return null;
        }

        public static bool DeleteAddress(string addressType)
        {
            try
            {
                var model = (from s in db.Table<JobApplicationAddress>()
                             where s.AddressType == addressType
                             select s).FirstOrDefault();

                db.Delete(model);
                return true;
            }
            catch { }

            return false;
        }

        public static JobApplicationAddress UpdateAddress(JobApplicationAddress model)
        {
            try
            {
                try
                {
                    var address = (from s in db.Table<JobApplicationAddress>()
                                   where s.AddressType == model.AddressType
                                   select s).FirstOrDefault();
                    if (address != null)
                    {
                        model.ID = address.ID;
                        db.Update(model);
                    }
                    else
                    {
                        db.Insert(model);
                    }
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationAddress>()
                                where s.AddressType == model.AddressType
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static List<JobApplicationFamily> GetFamilies()
        {
            try
            {
                var model = (from s in db.Table<JobApplicationFamily>()
                             select s);

                List<JobApplicationFamily> infos = new List<JobApplicationFamily>();

                foreach (JobApplicationFamily item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static bool DeleteFamily(JobApplicationFamily model)
        {
            try
            {
                var family = (from s in db.Table<JobApplicationFamily>()
                              where s.ID == model.ID
                              select s).FirstOrDefault();
                if (family != null)
                {
                    db.Delete(model);
                }

                return true;
            }
            catch { }

            return false;
        }

        public static JobApplicationFamily UpdateFamily(JobApplicationFamily model)
        {
            try
            {
                try
                {
                    var family = (from s in db.Table<JobApplicationFamily>()
                                  where s.ID == model.ID
                                  select s).FirstOrDefault();
                    if (family != null)
                    {
                        db.Update(model);
                    }
                    else
                    {
                        db.Insert(model);
                    }
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationFamily>()
                                where s.ID == model.ID
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static List<JobApplicationEducation> GetEducations()
        {
            try
            {
                var model = (from s in db.Table<JobApplicationEducation>()
                             select s);

                List<JobApplicationEducation> infos = new List<JobApplicationEducation>();

                foreach (JobApplicationEducation item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static bool DeleteEducation(JobApplicationEducation model)
        {
            try
            {
                var education = (from s in db.Table<JobApplicationEducation>()
                                 where s.ID == model.ID
                                 select s).FirstOrDefault();
                if (education != null)
                {
                    db.Delete(model);
                }

                return true;
            }
            catch { }

            return false;
        }

        public static JobApplicationEducation UpdateEducation(JobApplicationEducation model)
        {
            try
            {
                try
                {
                    var education = (from s in db.Table<JobApplicationEducation>()
                                     where s.ID == model.ID
                                     select s).FirstOrDefault();
                    if (education != null)
                    {
                        db.Update(model);
                    }
                    else
                    {
                        db.Insert(model);
                    }
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationEducation>()
                                where s.ID == model.ID
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static List<JobApplicationLanguage> GetLanguages()
        {
            try
            {
                var model = (from s in db.Table<JobApplicationLanguage>()
                             select s);

                List<JobApplicationLanguage> infos = new List<JobApplicationLanguage>();

                foreach (JobApplicationLanguage item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static bool DeleteLanguage(JobApplicationLanguage model)
        {
            try
            {
                var language = (from s in db.Table<JobApplicationLanguage>()
                                where s.ID == model.ID
                                select s).FirstOrDefault();
                if (language != null)
                {
                    db.Delete(model);
                }

                return true;
            }
            catch { }

            return false;
        }

        public static JobApplicationLanguage UpdateLanguage(JobApplicationLanguage model)
        {
            try
            {
                try
                {
                    var language = (from s in db.Table<JobApplicationLanguage>()
                                    where s.ID == model.ID
                                    select s).FirstOrDefault();
                    if (language != null)
                    {
                        db.Update(model);
                    }
                    else
                    {
                        db.Insert(model);
                    }
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationLanguage>()
                                where s.ID == model.ID
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static List<JobApplicationWorkingHistory> GetWorkingHistories()
        {
            try
            {
                var model = (from s in db.Table<JobApplicationWorkingHistory>()
                             select s);

                List<JobApplicationWorkingHistory> infos = new List<JobApplicationWorkingHistory>();

                foreach (JobApplicationWorkingHistory item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static bool DeleteWorkingHistory(JobApplicationWorkingHistory model)
        {
            try
            {
                var workingHistory = (from s in db.Table<JobApplicationWorkingHistory>()
                                      where s.ID == model.ID
                                      select s).FirstOrDefault();
                if (workingHistory != null)
                {
                    db.Delete(model);
                }

                return true;
            }
            catch { }

            return false;
        }

        public static JobApplicationWorkingHistory UpdateWorkingHistory(JobApplicationWorkingHistory model)
        {
            try
            {
                try
                {
                    var workingHistory = (from s in db.Table<JobApplicationWorkingHistory>()
                                          where s.ID == model.ID
                                          select s).FirstOrDefault();
                    if (workingHistory != null)
                    {
                        db.Update(model);
                    }
                    else
                    {
                        db.Insert(model);
                    }
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationWorkingHistory>()
                                where s.ID == model.ID
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static List<JobApplicationActivity> GetActivities()
        {
            try
            {
                var model = (from s in db.Table<JobApplicationActivity>()
                             select s);

                List<JobApplicationActivity> infos = new List<JobApplicationActivity>();

                foreach (JobApplicationActivity item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static bool DeleteActivity(JobApplicationActivity model)
        {
            try
            {
                var activity = (from s in db.Table<JobApplicationActivity>()
                                where s.ID == model.ID
                                select s).FirstOrDefault();
                if (activity != null)
                {
                    db.Delete(model);
                }

                return true;
            }
            catch { }

            return false;
        }

        public static JobApplicationActivity UpdateActivity(JobApplicationActivity model)
        {
            try
            {
                try
                {
                    var activity = (from s in db.Table<JobApplicationActivity>()
                                    where s.ID == model.ID
                                    select s).FirstOrDefault();
                    if (activity != null)
                    {
                        db.Update(model);
                    }
                    else
                    {
                        db.Insert(model);
                    }
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationActivity>()
                                where s.ID == model.ID
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static List<JobApplicationReference> GetReferences()
        {
            try
            {
                var model = (from s in db.Table<JobApplicationReference>()
                             select s);

                List<JobApplicationReference> infos = new List<JobApplicationReference>();

                foreach (JobApplicationReference item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static void DeleteReferences()
        {
            try
            {
                db.DeleteAll<JobApplicationReference>();
            }
            catch { }
        }

        public static void UpdateReference(JobApplicationReference model)
        {
            try
            {
                try
                {
                    db.Insert(model);
                }
                catch { }
            }
            catch { }
        }

        public static JobApplicationPackageDetail GetPackageDetail()
        {
            try
            {
                try
                {
                    var item = (from s in db.Table<JobApplicationPackageDetail>()
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static JobApplicationPackageDetail UpdatePackageDetail(JobApplicationPackageDetail model)
        {
            try
            {
                try
                {
                    db.DeleteAll<JobApplicationPackageDetail>();
                    db.Insert(model);
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationPackageDetail>()
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static List<JobApplicationDeclaration> GetDeclarations()
        {
            try
            {
                var model = (from s in db.Table<JobApplicationDeclaration>()
                             select s);

                List<JobApplicationDeclaration> infos = new List<JobApplicationDeclaration>();

                foreach (JobApplicationDeclaration item in model)
                {
                    infos.Add(item);
                }

                return infos;
            }
            catch { }

            return null;
        }

        public static JobApplicationDeclaration UpdateDeclaration(JobApplicationDeclaration model)
        {
            try
            {
                try
                {
                    var declaration = (from s in db.Table<JobApplicationDeclaration>()
                                       where s.DeclarationID == model.DeclarationID
                                       select s).FirstOrDefault();
                    if (declaration != null)
                    {
                        model.ID = declaration.ID;
                        db.Update(model);
                    }
                    else
                    {
                        db.Insert(model);
                    }
                }
                catch { }

                try
                {
                    var item = (from s in db.Table<JobApplicationDeclaration>()
                                where s.DeclarationID == model.DeclarationID
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static byte[] GetProfile()
        {
            try
            {
                var jobApp = (from s in db.Table<JobApplication>()
                              select s).FirstOrDefault();
                if (jobApp != null)
                {
                    return jobApp.Photo;
                }
            }
            catch { }

            return null;
        }

        public static JobApplication GetJobApplication()
        {
            try
            {
                var model = (from s in db.Table<JobApplication>()
                             select s).FirstOrDefault();
                return model;
            }
            catch { }

            return null;
        }

        public static JobApplication InsertJobApplication(JobApplication model)
        {
            try
            {
                if (db.Table<JobApplication>().Count() != 0)
                {
                    db.DeleteAll<JobApplication>();
                }

                db.Insert(model);

                try
                {
                    var item = (from s in db.Table<JobApplication>()
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }

        public static JobApplication UpdateJobApplication(JobApplication model)
        {
            try
            {
                var jobApp = (from s in db.Table<JobApplication>()
                              select s).FirstOrDefault();

                if (jobApp != null)
                    model.ID = jobApp.ID;

                db.Update(model);

                try
                {
                    var item = (from s in db.Table<JobApplication>()
                                select s).FirstOrDefault();
                    return item;
                }
                catch { }
            }
            catch { }

            return null;
        }
    }
}
