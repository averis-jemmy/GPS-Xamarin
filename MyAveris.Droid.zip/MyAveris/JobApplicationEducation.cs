﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAveris
{
    [Table("JobApplicationEducation")]
    public class JobApplicationEducation
    {
        [PrimaryKey, Column("ID")]
        public Guid ID { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Institution { get; set; }
        public string Country { get; set; }
        public string Qualification { get; set; }
        public string CourseOfStudy { get; set; }
    }
}
