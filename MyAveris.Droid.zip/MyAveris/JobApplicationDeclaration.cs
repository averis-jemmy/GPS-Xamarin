﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAveris
{
    [Table("JobApplicationDeclaration")]
    public class JobApplicationDeclaration
    {
        [PrimaryKey, AutoIncrement, Column("ID")]
        public int ID { get; set; }
        public Guid? DeclarationID { get; set; }
        public string DeclarationDetail { get; set; }
        public bool? Answer { get; set; }
        public string Remarks { get; set; }
    }
}
