﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAveris
{
    [Table("JobApplicationReference")]
    public class JobApplicationReference
    {
        [PrimaryKey, AutoIncrement, Column("ID")]
        public int ID { get; set; }
        public string Name { get; set; }
        public string Occupation { get; set; }
        public byte? YearsKnown { get; set; }
        public string Address { get; set; }
        public string Employer { get; set; }
        public string HomeNumber { get; set; }
        public string MobileNumber { get; set; }
        public string OfficeNumber { get; set; }
    }
}
