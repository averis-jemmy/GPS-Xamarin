﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyAveris
{
    [Table("JobApplicationWorkingHistory")]
    public class JobApplicationWorkingHistory
    {
        [PrimaryKey, Column("ID")]
        public Guid ID { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string Company { get; set; }
        public string Country { get; set; }
        public string LastPositionHeld { get; set; }
        public string NameOfSuperior { get; set; }
        public string DesignationOfSuperior { get; set; }
        public decimal? LastDrawnSalary { get; set; }
        public string ReasonForLeaving { get; set; }
    }
}
