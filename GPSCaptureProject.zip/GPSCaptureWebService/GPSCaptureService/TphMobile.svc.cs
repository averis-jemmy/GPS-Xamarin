﻿using GPSCaptureData;
using GPSCaptureEntity;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Threading.Tasks;

namespace GPSCaptureService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class TphMobile : ITphMobile
    {
        public List<string> DownloadEstates()
        {
            OutgoingWebResponseContext response = WebOperationContext.Current.OutgoingResponse;

            try
            {
                Database.ConnectionString = ConfigurationManager.ConnectionStrings["TphDb"].ConnectionString;
                return Database.GetAllEstates();
            }
            catch (Exception ex)
            {
                response.Headers.Add("ErrorMessage", "Error");
                response.Headers.Add("ErrorDescription", ex.Message);
            }
            return null;
        }

        public List<TphInfo> DownloadTphs(string estateCode)
        {
            OutgoingWebResponseContext response = WebOperationContext.Current.OutgoingResponse;

            try
            {
                Database.ConnectionString = ConfigurationManager.ConnectionStrings["TphDb"].ConnectionString;
                return Database.GetAllTphs(estateCode);
            }
            catch (Exception ex)
            {
                response.Headers.Add("ErrorMessage", "Error");
                response.Headers.Add("ErrorDescription", ex.Message);
            }
            return null;
        }

        public void UpdateTph(TphInfo info)
        {
            OutgoingWebResponseContext response = WebOperationContext.Current.OutgoingResponse;

            try
            {
                Database.ConnectionString = ConfigurationManager.ConnectionStrings["TphDb"].ConnectionString;
                if(!Database.UpdateTph(info))
                {
                    response.Headers.Add("ErrorMessage", "Error");
                    response.Headers.Add("ErrorDescription", "Failed to update");
                }
            }
            catch (Exception ex)
            {
                response.Headers.Add("ErrorMessage", "Error");
                response.Headers.Add("ErrorDescription", ex.Message);
            }
        }
    }
}
