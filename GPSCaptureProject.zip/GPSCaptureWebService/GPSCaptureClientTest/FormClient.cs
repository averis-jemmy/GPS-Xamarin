﻿using GPSCaptureData;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Formatters;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GPSCaptureClientTest
{
    public partial class FormClient : Form
    {
        string strResult = string.Empty;
        string requestType = string.Empty;
        string requestData = string.Empty;
        List<KeyValuePair<string, string>> headers = null;

        public FormClient()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            //Database.ConnectionString = "data source=172.21.11.130;initial catalog=AA_IOC_PMS_Dev;integrated security=false;user id=TPHAdmin;password=1Qaz2Wsx2016;";
            //List<string> estates = Database.GetAllEstates();

            //decimal test = 101.12451325m;
            //string te = test.ToString();

            txtResponse.Text = string.Empty;
            txtResponse.Enabled = false;
            txtRequest.Enabled = false;
            btnGo.Enabled = false;

            headers = new List<KeyValuePair<string, string>>();

            string[] request = txtRequest.Text.Split(';');
            if (request.Length > 1)
            {
                requestType = request[0];
                requestData = request[1];

                BackgroundWorker worker = new BackgroundWorker();
                worker.DoWork += worker_DoWork;
                worker.RunWorkerCompleted += worker_RunWorkerCompleted;
                worker.RunWorkerAsync();
            }
            else
            {
                txtResponse.Enabled = true;
                txtRequest.Enabled = true;
                btnGo.Enabled = true;
                txtResponse.Text = strResult;
            }
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            RestClient client = new RestClient("http://localhost:53960/TphMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            strResult = client.ProcessRequest(requestType, headers, false);
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            txtResponse.Enabled = true;
            txtRequest.Enabled = true;
            btnGo.Enabled = true;
            txtResponse.Text = strResult;
        }

        byte[] encryptedtext;

        private void button1_Click(object sender, EventArgs e)
        {
            UnicodeEncoding ByteConverter = new UnicodeEncoding();
            RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            txtResponse.Text = Cryptography.Encryption(txtRequest.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UnicodeEncoding ByteConverter = new UnicodeEncoding();
            RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            txtRequest.Text = Cryptography.Decryption(txtResponse.Text);
        }
    }
}
