﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPSCaptureEntity
{
    public class TphInfo
    {
        public string Estate { get; set; }
        public string Afdeling { get; set; }
        public string Block { get; set; }
        public string TPH { get; set; }
        public string Active { get; set; }
        public decimal? Latitude { get; set; }
        public decimal? Longitude { get; set; }
        public string Remarks { get; set; }
        public DateTime? UpdatedDate { get; set; }
    }
}
