﻿using GPSCaptureEntity;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPSCaptureData
{
    public static class Database
    {
        public static string ConnectionString = string.Empty;

        public static List<string> GetAllEstates()
        {
            List<string> estates = new List<string>();
            if (!string.IsNullOrEmpty(ConnectionString))
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandTimeout = 0;
                    com.CommandType = System.Data.CommandType.Text;
                    com.CommandText = "SELECT DISTINCT Estate FROM TPH";
                    DataTable table = new DataTable();
                    DataSet dtSet = new DataSet();
                    SqlDataAdapter adap = new SqlDataAdapter();
                    adap.SelectCommand = com;
                    adap.Fill(table);

                    if (table.Rows.Count > 0)
                    {
                        foreach (DataRow row in table.Rows)
                        {
                            if (row[0] != null)
                                estates.Add(row[0].ToString());
                        }
                    }
                    con.Close();
                }
                catch { }
                finally
                {
                    if (con.State != System.Data.ConnectionState.Closed)
                        con.Close();
                }
            }
            return estates;
        }

        public static List<TphInfo> GetAllTphs(string estate)
        {
            List<TphInfo> tphs = new List<TphInfo>();
            if (!string.IsNullOrEmpty(ConnectionString))
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandTimeout = 0;
                    com.CommandType = System.Data.CommandType.Text;
                    com.CommandText = "SELECT DISTINCT Estate, Afdeling, Block, TPH, Active, Latitude, Longitude, Remarks, UpdatedDate FROM TPH WHERE Estate = '" + estate + "'";
                    DataTable table = new DataTable();
                    SqlDataAdapter adap = new SqlDataAdapter();
                    adap.SelectCommand = com;
                    adap.Fill(table);

                    if (table.Rows.Count > 0)
                    {
                        foreach (DataRow row in table.Rows)
                        {
                            TphInfo info = new TphInfo();
                            if (row[0] != null)
                                info.Estate = row[0].ToString();
                            if (row[1] != null)
                                info.Afdeling = row[1].ToString();
                            if (row[2] != null)
                                info.Block = row[2].ToString();
                            if (row[3] != null)
                                info.TPH = row[3].ToString();
                            if (row[4] != null)
                                info.Active = row[4].ToString();
                            if (row[5] != null)
                            {
                                try
                                {
                                    info.Latitude = (decimal)row[5];
                                }
                                catch { }
                            }
                            if (row[6] != null)
                            {
                                try
                                {
                                    info.Longitude = (decimal)row[6];
                                }
                                catch { }
                            }
                            if (row[7] != null)
                                info.Remarks = row[7].ToString();
                            if (row[8] != null)
                            {
                                try
                                {
                                    info.UpdatedDate = (DateTime)row[8];
                                }
                                catch { }
                            }
                            tphs.Add(info);
                        }
                    }
                    con.Close();
                }
                catch { }
                finally
                {
                    if (con.State != System.Data.ConnectionState.Closed)
                        con.Close();
                }
            }
            return tphs;
        }

        public static bool UpdateTph(TphInfo info)
        {
            if (!string.IsNullOrEmpty(ConnectionString))
            {
                SqlConnection con = new SqlConnection(ConnectionString);
                try
                {
                    con.Open();
                    SqlCommand com = new SqlCommand();
                    com.Connection = con;
                    com.CommandTimeout = 0;
                    com.CommandType = System.Data.CommandType.Text;
                    string latitude = "NULL", longitude = "NULL";
                    if (info.Latitude.HasValue)
                        latitude = info.Latitude.GetValueOrDefault().ToString();
                    if (info.Longitude.HasValue)
                        latitude = info.Longitude.GetValueOrDefault().ToString();

                    com.CommandText = "UPDATE TPH SET " +
                        "Latitude = " + latitude +
                        ", Longitude = " + longitude +
                        ", Remarks = '" + info.Remarks +
                        "', UpdatedDate = '" + info.UpdatedDate.GetValueOrDefault().ToString("yyyy-MM-dd") +
                        "' WHERE Estate = '" + info.Estate + "' AND Afdeling = '" + info.Afdeling + "' AND Block = '" + info.Block +
                        "' AND TPH = '" + info.TPH + "'";
                    com.ExecuteNonQuery();
                    con.Close();
                    return true;
                }
                catch { }
                finally
                {
                    if (con.State != System.Data.ConnectionState.Closed)
                        con.Close();
                }
            }
            return false;
        }
    }
}
