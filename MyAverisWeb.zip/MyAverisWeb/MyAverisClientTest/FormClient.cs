﻿using MyAverisData;
using MyAverisEntity;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Runtime.Serialization.Formatters;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyAverisClientTest
{
    public partial class FormClient : Form
    {
        string strResult = string.Empty;
        string requestType = string.Empty;
        string requestData = string.Empty;
        List<KeyValuePair<string, string>> headers = null;

        public const string API_KEY = "AIzaSyAkjTP-MybajYOjIS9JUY8MPHaOtFafCnc";

        public FormClient()
        {
            InitializeComponent();
        }

        private void btnGo_Click(object sender, EventArgs e)
        {
            //PreBoardingInfo info = new PreBoardingInfo();
            //info.BuddyName = "Angel";
            //info.Department = "Others";
            //info.HRContactPerson = "Eve";
            //info.JobID = Guid.Parse("09fda2ff-03c2-4d82-acd0-8459af48b654");
            //info.JoinDate = DateTime.Now.AddDays(30);
            //info.Position = "God";
            //info.Supervisor = "Universe";
            //info.UserID = Guid.Parse("860C3937-5E75-4CB4-8188-311C5CB527AC");

            //JobApplicationRepository rep = new JobApplicationRepository(Database.Instant);
            //bool test = rep.AcceptJobApplication(info);

            //DateTime test = new DateTime(2016, 9, 29, 18, 14, 25);
            //DateTime test2 = new DateTime(2016, 9, 30, 18, 14, 25);
            //double test3 = (test2 - test).TotalMinutes;
            //string test = string.Empty;
            //try
            //{
            //    test = JsonConvert.DeserializeObject<string>("\"ghjagsd\"");
            //}
            //catch { }

            txtResponse.Text = string.Empty;
            txtResponse.Enabled = false;
            txtRequest.Enabled = false;
            btnGo.Enabled = false;

            headers = new List<KeyValuePair<string, string>>();

            //headers.Add(new KeyValuePair<string, string>("UserID", "5e3e0b14-1606-4025-8f18-c76138ba76be"));
            //headers.Add(new KeyValuePair<string, string>("TokenID", "f520b9c4-a861-4736-817f-ee75b751331a"));

            //headers.Add(new KeyValuePair<string, string>("UserID", "860C3937-5E75-4CB4-8188-311C5CB527AC"));
            //headers.Add(new KeyValuePair<string, string>("TokenID", "4929617D-2B89-44F6-81B0-3E1E4AA3E0C7"));

            //headers.Add(new KeyValuePair<string, string>("UserID", "5FD55244-F824-4531-AAB7-20860AE202ED"));
            //headers.Add(new KeyValuePair<string, string>("TokenID", "82FF6E5B-7D57-447E-90C0-9B4BF446C504"));

            //headers.Add(new KeyValuePair<string, string>("UserID", "63D485C8-2C3D-4CE9-A42D-801274A74655"));
            //headers.Add(new KeyValuePair<string, string>("TokenID", "9E1FCD7B-8411-4FBB-A479-1C212555B253"));

            //PhotoRepository rep = new PhotoRepository(Database.Instant);
            //List<PhotoInfo> infos = rep.GetPhotoList("FUN");

            //string requestData = JsonConvert.SerializeObject(photos);

            //RestClient client = new RestClient("https://172.25.67.87/MyAverisServiceHttps/AverisMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            //RestClient client = new RestClient("https://m-dev.averis.biz/MyAverisServiceHttps/AverisMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            //RestClient client = new RestClient("https://203.223.140.195/MyAverisServiceHttps/AverisMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            //RestClient client = new RestClient("http://localhost:52860/AverisMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            //strResult = client.ProcessRequest("UploadProfilePicture", headers, File.ReadAllBytes(Directory.GetParent(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\images\\bad.png"));

            //RestClient client = new RestClient("http://localhost:52860/AverisMobile.svc/", HttpVerb.GET, ContentTypeString.JSON, string.Empty);
            //strResult = client.ProcessRequest("DownloadProfilePicture", headers, true);
            //byte[] bitmapData = Convert.FromBase64String(strResult);
            //Bitmap bmp;
            //using (var ms = new MemoryStream(bitmapData))
            //{
            //    bmp = new Bitmap(ms);
            //}
            //pbTest.Image = bmp;
            //pbTest.SizeMode = PictureBoxSizeMode.StretchImage;

            //string[] request = txtRequest.Text.Split(';');
            //if (request.Length > 1)
            //{
            //    requestType = request[0];
            //    requestData = request[1];

            //    BackgroundWorker worker = new BackgroundWorker();
            //    worker.DoWork += worker_DoWork;
            //    worker.RunWorkerCompleted += worker_RunWorkerCompleted;
            //    worker.RunWorkerAsync();
            //}
            //else
            //{
            //    txtResponse.Enabled = true;
            //    txtRequest.Enabled = true;
            //    btnGo.Enabled = true;
            //    txtResponse.Text = strResult;
            //}

            try
            {
                //Console.WriteLine ("DEBUG***  {0}", args [0].Trim ());

                string message = "Hello World!!!";
                string token = "ewG6_g-IALI:APA91bGYbdoPOiAbjs8Eep9x_V5bjsqefopTSfQTrqU8Eojff-SZsuPMYDo9E2-sniksDAFpfXl4AinXSc3hLpP97z4tk4Lo4YOKmBIsgu4hzKFMkMlZ2NIt9bpIoBF7t72PDrvEufn4";

                var jGcmData = new JObject();
                var jData = new JObject();

                jData.Add("message", message.Trim());

                if (token != null)
                {
                    jGcmData.Add("to", token.Trim());
                }
                else
                {
                    jGcmData.Add("to", "/topics/averis");
                }

                jGcmData.Add("data", jData);

                // First create a proxy object

                string proxyUri =
                    string.Format("{0}:{1}", "172.25.90.168", "8080");

                NetworkCredential proxyCreds = new NetworkCredential(
                    "globalnet\\svc-myaveris",
                    "welcome1"
                );

                WebProxy proxy = new WebProxy(proxyUri, false)
                {
                    UseDefaultCredentials = false,
                    Credentials = proxyCreds,
                };

                // Now create a client handler which uses that proxy
                HttpClientHandler httpClientHandler = new HttpClientHandler()
                {
                    Proxy = proxy,
                    PreAuthenticate = true,
                    UseDefaultCredentials = false,
                };

                // You only need this part if the server wants a username and password:

                string
                    httpUserName = "globalnet\\jemmy",
                    httpPassword = "Jemmycarol888";

                httpClientHandler.Credentials = new NetworkCredential(httpUserName, httpPassword);

                var url = new Uri("https://gcm-http.googleapis.com/gcm/send");
                using (var client = new HttpClient(httpClientHandler))
                {

                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.TryAddWithoutValidation("Authorization", "key=" + API_KEY);
                    Task.WaitAll(client.PostAsync(url, new StringContent(jGcmData.ToString(), Encoding.Default, "application/json")).ContinueWith(response =>
                    {
                        StreamWriter writer = new StreamWriter("d:/error.log", true);
                        writer.WriteLine(response.Result.StatusCode);
                        writer.Close();
                        //writer.WriteLine(response.Exception.Message);
                        //writer.WriteLine(response.Exception.InnerExceptions.Count.ToString());
                        if (response.Result.StatusCode == HttpStatusCode.OK)
                        {
                        }
                        Console.WriteLine(response);
                        Console.WriteLine("Check your device/emulator for notification or logcat for " +
                        "confirmation of the receipt of the GCM message.");
                    }));
                }
                Console.ReadLine();
            }
            catch (IOException ex)
            {
                Console.WriteLine("Unable to send GCM message.");
                Console.WriteLine("Please ensure that API_KEY has been replaced by the server " +
                "API key, and that the device's registration token is correct (if specified).");
                Console.Error.WriteLine(ex.StackTrace);
            }
            catch (Exception ex)
            {
                StreamWriter writer = new StreamWriter("d:/error.log", true);
                writer.WriteLine(ex.Message);
                writer.WriteLine(ex.InnerException.Message);
                writer.Close();
            }
        }

        void worker_DoWork(object sender, DoWorkEventArgs e)
        {
            //JobApplicationRepository rep = new JobApplicationRepository(Database.Instant);
            //JobApplicationInfo info = new JobApplicationInfo();
            //info = rep.GetJobApplicationByID(Guid.Parse("350e2f1f-71d4-45b9-92af-1b320efcbae9"));
            //info.PackageDetail = new JobApplicationPackageDetailInfo();
            //UnicodeEncoding ByteConverter = new UnicodeEncoding();
            //RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            //byte[] plaintext = ByteConverter.GetBytes("10000.50");
            //info.PackageDetail.BaseSalary = Cryptography.Encryption(plaintext, RSA.ExportParameters(false), false);

            //info.Photo = File.ReadAllBytes(Directory.GetParent(System.Reflection.Assembly.GetExecutingAssembly().Location) + "\\images\\bad.png");
            //string requestData = JsonConvert.SerializeObject(info,
            //                                  new JsonSerializerSettings()
            //                                  {
            //                                      DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
            //                                  });

            //PreBoardingInfo model = new PreBoardingInfo()
            //{
            //    ID = Guid.NewGuid(),
            //    JobID = Guid.NewGuid(),
            //    UserID = Guid.NewGuid(),
            //    Position = "TEST",
            //    BuddyName = "NAME",
            //    HRContactPerson = "HR",
            //    Supervisor = "SUPER",
            //    Department = "IT",
            //    JoinDate = DateTime.Now
            //};
            //string requestData = JsonConvert.SerializeObject(model,
            //                                  new JsonSerializerSettings()
            //                                  {
            //                                      DateFormatHandling = DateFormatHandling.MicrosoftDateFormat
            //                                  });

            //JobApplicationInfo test = JsonConvert.DeserializeObject<JobApplicationInfo>(requestData);
            //RestClient client = new RestClient("https://m.averis.biz/MyAverisServiceHttps/AverisMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            RestClient client = new RestClient("https://202.223.140.197/MyAverisServiceHttps/AverisMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            //RestClient client = new RestClient("http://localhost:52860/AverisMobile.svc/", HttpVerb.POST, ContentTypeString.JSON, requestData);
            strResult = client.ProcessRequest(requestType, headers, false);

            //strResult = HttpGet.HttpGetUrl("+601137047578", "test");

            //RestClient client = new RestClient("https://172.25.67.87/MyAverisServiceHttps/images/99d81220-d58d-4506-8c5d-d00b7ad64ceb.png", HttpVerb.POST, ContentTypeString.JSON, string.Empty);
            //strResult = client.DownloadRemoteImageFile();
        }

        void worker_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            txtResponse.Enabled = true;
            txtRequest.Enabled = true;
            btnGo.Enabled = true;
            txtResponse.Text = strResult;

            //byte[] bitmapData = Convert.FromBase64String(strResult);
            //Bitmap bmp;
            //using (var ms = new MemoryStream(bitmapData))
            //{
            //    bmp = new Bitmap(ms);
            //}
            //pbTest.Image = bmp;
            //pbTest.SizeMode = PictureBoxSizeMode.StretchImage;

            //JobApplicationInfo info = JsonConvert.DeserializeObject<JobApplicationInfo>(strResult);
            //Bitmap bmp;
            //using (var ms = new MemoryStream(info.Photo))
            //{
            //    bmp = new Bitmap(ms);
            //}
            //pbTest.Image = bmp;
            //pbTest.SizeMode = PictureBoxSizeMode.StretchImage;
        }

        byte[] encryptedtext;

        private void button1_Click(object sender, EventArgs e)
        {
            UnicodeEncoding ByteConverter = new UnicodeEncoding();
            RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            txtResponse.Text = Cryptography.Encryption(txtRequest.Text);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            UnicodeEncoding ByteConverter = new UnicodeEncoding();
            RSACryptoServiceProvider RSA = new RSACryptoServiceProvider();
            txtRequest.Text = Cryptography.Decryption(txtResponse.Text);
        }
    }
}
