﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using MyAverisCommon;

namespace MyAveris
{
    public class Utility
    {
        public StringBuilder DateFormat(DateTime? ddmmyyyy)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append(string.Empty);
            try
            {
                if (ddmmyyyy != null)
                {
                    DateTime dateformat = Convert.ToDateTime(ddmmyyyy);

                    if (dateformat.Day.ToString().Length == 1)
                    { sb.Append("0" + dateformat.Day.ToString()); }
                    else
                    { sb.Append(dateformat.Day.ToString()); }

                    sb.Append("/");
                    if (dateformat.Month.ToString().Length == 1)
                    { sb.Append("0" + dateformat.Month.ToString()); }
                    else
                    { sb.Append(dateformat.Month.ToString()); }

                    sb.Append("/" + dateformat.Year.ToString());
                }

                return sb;
            }
            catch { return sb; }

        }

        public string FormatDate(string Val)
        {
            string val = string.Empty;
            if (Val != null)
            {
                if (Val != string.Empty)
                {
                    val = Convert.ToDateTime(Val).ToString("dd MMM yyyy");
                }
            }

            return val;
        }
        
        public DateTime ToDateFormat(string ddmmyyyy)
        {
            DateTime dt = new DateTime();

            StringBuilder sb = new StringBuilder();
            sb.Append(string.Empty);
            try
            {

                if (ddmmyyyy != null)
                {
                    DateTime dateformat = Convert.ToDateTime(ddmmyyyy);

                    if (dateformat.Day.ToString().Length == 1)
                    { sb.Append("0" + dateformat.Day.ToString()); }
                    else
                    { sb.Append(dateformat.Day.ToString()); }

                    sb.Append("/");
                    if (dateformat.Month.ToString().Length == 1)
                    { sb.Append("0" + dateformat.Month.ToString()); }
                    else
                    { sb.Append(dateformat.Month.ToString()); }

                    sb.Append("/" + dateformat.Year.ToString());
                }

                return dt;
            }
            catch { return dt; }

        }

        public string GetValue(string Val)
        {
            string val = string.Empty;
            if (Val != null)
            {
                if (Val != string.Empty)
                {
                    val = String.Format("{0:,000.00}", Cryptography.Decryption(Val));                    
                }
            }
            return val;
        }
    }
}
