﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace MyAveris
{
    public class ErrorLog
    {
        public void Writelog(String strMessage, string strApplication)
        {
            try
            {
                string strLogFile = String.Empty;
                string filepath = String.Empty;
                string strLogFolder = System.Configuration.ConfigurationManager.AppSettings["ErrorLogFolder"];

                strLogFile = System.Configuration.ConfigurationManager.AppSettings["ErrorLog"];
                filepath = strLogFolder + strLogFile + " " + DateTime.Now.ToString("dd-MM-yyyy") + ".txt";

                if (File.Exists(filepath))
                {
                    using (StreamWriter sw = new StreamWriter(filepath, true))
                    {
                        sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + "    " + strMessage);
                        sw.Close();
                        sw.Dispose();
                    }
                }
                else
                {
                    StreamWriter sw = File.CreateText(filepath);
                    sw.WriteAsync(Environment.NewLine + Convert.ToString(System.DateTime.Now) + "    " + strMessage);
                    sw.Close();
                    sw.Dispose();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}

