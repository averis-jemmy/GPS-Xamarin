﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.
[assembly: AssemblyTitle("MyAveris")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Averis Sdn Bhd")]
[assembly: AssemblyProduct("MyAveris")]
[assembly: AssemblyCopyright("Copyright © Averis Sdn Bhd 2016")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

// Setting ComVisible to false makes the types in this assembly not visible
// to COM components.  If you need to access a type in this assembly from
// COM, set the ComVisible attribute to true on that type.
[assembly: ComVisible(false)]

// The following GUID is for the ID of the typelib if this project is exposed to COM
[assembly: Guid("227DA796-B0D5-431C-B13C-895FE2E27D27")]

// Version information for an assembly consists of the following four values:
//
//      Major Version
//      Minor Version
//      Build Number
//      Revision
//
// You can specify all the values or you can default the Revision and Build Numbers
// by using the '*' as shown below:
[assembly: AssemblyVersion("1.0.8.0")]
[assembly: AssemblyFileVersion("1.0.8.0")]
//20161004 AVT - Change wording Application List to Job Application List (IssueLog Item No.12)
//             - Locked and Active column use icon to represent instead of 'Yes'/'No' (IssueLog Item No.17)
//20161006 AVT - Changed status to  (i) Processing (Default) (ii) Unsuccessful (iii) Successful (iv) KIV"(IssueLog Item No.16)
//20161010 AVT - Include icon to indicate sorting function at the header of each column (IssueLog Item No.14)
//               Remarks - Added Link to header (underline) on mouse over
//             - Added function to authorized recruiter to delete candidate user account. (IssueLog Item No.19)
//             - Added validation on phone number, user can only enter value (6xxxxxxxxxx) (IssueLog Item No.21)
//20161011 AVT - As per Serena Added function to restore applicant account. (IssueLog Item No.19)
//20161017 AVT - Fixed Create Applicant, missing name and emailaddress. 
//               Feedback from user As per Serena Added Position Applied field when adding new applicant and automatically add to job application list (IssueLog Item )
//20161018 AVT - Added function to open form in new windows. (IssueLog Item No.28)
//20161019 AVT - Fixed issue on creating Applicant account - Email and User name are not created.  Phone number is created. (IssueLog Item No.31)
//             - Added new field Position Applied in Create Applicant. 
//               Add column PositionApplied in User table (by Jemmy) (IssueLog Item No. 32 & 42)
//             - Added description for icons delete, edit, current package and application form  (IssueLog Item No.39)
//             - Added function to delete Job Application for Recruiter role  (IssueLog Item No.40)
//             - Added function to Create New Recruiter for SuperUser role (IssueLog Item No.43)
//20161024 AVT - Added country code selection (IssueLog Item No.37)
//             - Show column header description for the tables (IssueLog Item No.39)
//             - Fixed issue on Lock Status (IssueLog Item No.56)
//             - Removed link from "Hello XXX" (IssueLog Item No.57)
//             - Locked job application when application status is not Submitted (IssueLog Item No.59)
//             - Changed sequence of Social Activities, Education, working experience based on latest year/month (IssueLog Item No.55)
//             - Added Last Name to Family details (IssueLog Item No.52)
//20161025 AVT - Added batch delete, resubmit, locked and change application status (IssueLog Item No.13)
//20161026 AVT - Deployed in production server 172.25.67.86 
//20161028 AVT - Added Contact Person on application form
//             - Fixed issue when edit Recruiter, IsDeletes = null
//             - Application Go Live!!!       
//20161128 AVT - Added additional request for Preboarding information when application status is Successful (v1.0.1.0)
//20161130 AVT - Fixed issue on Start Date display on Educational Background when export to excel (v1.0.2.0)
//20161202 AVT - Fixed issue when Application Status change, IsDeleted column remains false, previously IsDeleted is Null (v1.0.3.0)
//             - Removed Preboarding Info when Application Status is not Successful (v1.0.3.0)
//20161207 AVT - Added columns to display in Job Application Management - Created By and Recruiter Name (v1.0.4.0)
//20161208 AVT - Change columns display in Job Application Management - Full Name to Candidate Name and Recruiter to Recruiter Name (v1.0.5.0)
//             - Change columns display in Job Application Management - Remove Time in Created Date and change Recruiter Name from account name to Full Name (v1.0.5.0)
//20161213 AVT - Fix display for Recruiter's Name, based on the CreatedBy, previously showing CreatedBy from JobApplication table. Change to CreatedBy from User table (v1.0.6.0)
//20161213 AVT - As per Joey Lum request, phone number in applicant info can be edited, confirmed by Serena (v1.0.6.0)
//20170104 AVT - Fixed Preboarding info, missing Application Status after adding preboarding, search issue - can only search either by first name/last name or fullname on the order of first name lastname basis (v1.0.7.0)
//20170106 AVT - Fixed error on display Employee Application form, when last withdrawn salary is not specified, decryption is causing the error.  (v1.0.8.0)





