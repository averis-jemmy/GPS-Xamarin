﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Collections;
using MyAverisData;
using MyAverisEntity;


namespace MyAveris.Controllers
{
    [Authorize]
    public class PositionsController : Controller
    {
        PositionRepository posRep = new PositionRepository(Database.Instant);
        // GET: Applicants
        public ActionResult Index(string q)
        {
            try
            {
                List<PositionViewModel> list = new List<PositionViewModel>();

                list = posRep.SearchPosition(q);

                if (Request.IsAjaxRequest())
                {
                    return PartialView("Index", list);
                }
                return View(list);
            }
            catch
            {
                ModelState.AddModelError("", "Error");
                return View();
            }
        }
    }
}
