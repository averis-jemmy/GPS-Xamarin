﻿using System;
using System.Globalization;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using System.Configuration;
using System.DirectoryServices;
using System.Collections.Generic;
using MyAverisData;
using MyAverisEntity;

namespace MyAveris.Controllers
{
    [Authorize]
    public class AccountController : Controller
    {
        public AccountController()
        {
        }

        //
        // GET: /Account/Login
        [AllowAnonymous]
        public ActionResult Login(string returnUrl)
        {
            ViewBag.ReturnUrl = returnUrl;
            return View();
        }

        //
        // POST: /Account/Login
        [HttpPost]
        [AllowAnonymous]
        [ValidateAntiForgeryToken]
        public ActionResult Login(LoginViewModel model, string returnUrl)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }

            string userName = model.Email.Substring(0, model.Email.IndexOf("@"));
            bool result = UserLogin(userName, model.Password);

            if (result)
            {
                UserRepository userRep = new UserRepository(Database.Instant);
                UserViewModel ud = new UserViewModel();

                ud.Email = model.Email;

                if (userRep.UserExists(ud))
                {
                    if (userRep.IsUserActive(ud))
                    {
                        var claims = new List<Claim>();
                        claims.Add(new Claim(ClaimTypes.NameIdentifier, userName));
                        claims.Add(new Claim("http://schemas.microsoft.com/accesscontrolservice/2010/07/claims/identityprovider", "ASP.NET Identity", "http://www.w3.org/2001/XMLSchema#string"));
                        claims.Add(new Claim(ClaimTypes.Name, userName));
                        claims.Add(new Claim(ClaimTypes.Email, model.Email));
                        if (userName == ConfigurationManager.AppSettings["SuperUser"].ToString())
                        { claims.Add(new Claim(ClaimTypes.Role, ConfigurationManager.AppSettings["Admin"].ToString())); }
                        else
                        { claims.Add(new Claim(ClaimTypes.Role, ConfigurationManager.AppSettings["HR"].ToString())); }

                        var manager = new ClaimsIdentity(claims, DefaultAuthenticationTypes.ApplicationCookie);
                        var ctx = Request.GetOwinContext();
                        var signinManager = ctx.Authentication;

                        signinManager.SignIn(new AuthenticationProperties { IsPersistent = (model.RememberMe) }, manager);
                        // auth is succeed, 
                        //added
                        Session["UserName"] = manager.Name;// User.Identity.Name;
                        return RedirectToLocal("~/JobApplications/Index");
                    }
                    else
                    {
                        ModelState.AddModelError("", "User account is not Active. Please contact administrator");
                        return View(model);
                    }
                }
                else
                {
                    ModelState.AddModelError("", "User account does not exist. Please contact administrator");
                    return View(model);
                }
            }
            else
            {
                ModelState.AddModelError("", "AD account does not exist / Password is incorrect. Please contact administrator");
                return View(model);
            }          
        }

        private bool UserLogin(string userName, string password)
        {
            string path = ConfigurationManager.AppSettings["LDAP"].ToString();

            DirectoryEntry de = new DirectoryEntry(path, userName, password, AuthenticationTypes.Secure);

            try
            {
                DirectorySearcher ds = new DirectorySearcher(de);
                SearchResult sr = ds.FindOne();

                return true;
            }
            catch
            {
                return false;
            }
        }

        //
        // POST: /Account/LogOff
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LogOff()
        {
            //AuthenticationManager.SignOut(DefaultAuthenticationTypes.ApplicationCookie);
            //return RedirectToAction("Index", "Home");

            var ctx = Request.GetOwinContext();
            var authenticationManager = ctx.Authentication;
            authenticationManager.SignOut();

            return RedirectToAction("Login", "Account");

        }

        //
        // GET: /Account/ExternalLoginFailure
        [AllowAnonymous]
        public ActionResult ExternalLoginFailure()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                
            }

            base.Dispose(disposing);
        }

        #region Helpers
        // Used for XSRF protection when adding external logins
        private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private ActionResult RedirectToLocal(string returnUrl)
        {
            if (Url.IsLocalUrl(returnUrl))
            {
                return Redirect(returnUrl);
            }
            return RedirectToAction("Index", "Home");
        }

        internal class ChallengeResult : HttpUnauthorizedResult
        {
            public ChallengeResult(string provider, string redirectUri)
                : this(provider, redirectUri, null)
            {
            }

            public ChallengeResult(string provider, string redirectUri, string userId)
            {
                LoginProvider = provider;
                RedirectUri = redirectUri;
                UserId = userId;
            }

            public string LoginProvider { get; set; }
            public string RedirectUri { get; set; }
            public string UserId { get; set; }

            public override void ExecuteResult(ControllerContext context)
            {
                var properties = new AuthenticationProperties { RedirectUri = RedirectUri };
                if (UserId != null)
                {
                    properties.Dictionary[XsrfKey] = UserId;
                }
                context.HttpContext.GetOwinContext().Authentication.Challenge(properties, LoginProvider);
            }
        }
        #endregion
    }
}