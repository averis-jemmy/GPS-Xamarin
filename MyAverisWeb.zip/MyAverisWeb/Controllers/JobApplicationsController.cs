﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Text;
using System.Globalization;
using System.IO;
using MyAverisCommon;
using MyAverisData;
using MyAverisEntity;


namespace MyAveris.Controllers
{
    [Authorize]
    public class JobApplicationsController : Controller
    {
        private Utility util = new Utility();
        private JobApplicationRepository rep = new JobApplicationRepository(Database.Instant);

        public ActionResult Index(string q, string[] ids, string ApplicationStatus)
        {
            try
            {
                List<SelectListItem> li = new List<SelectListItem>();
                li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Submitted, Value = InitialData.ApplicationStatus.Submitted, Selected = false });
                li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Accepted, Value = InitialData.ApplicationStatus.Accepted, Selected = false });
                li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Rejected, Value = InitialData.ApplicationStatus.Rejected, Selected = false });
                li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.KIV, Value = InitialData.ApplicationStatus.KIV, Selected = false });

                ViewBag.ApplicationStatus = new SelectList(li, "Text", "Value");

                string useraction = string.Empty;

                if (ids != null)
                {
                    if (ids.Contains("Delete Selected"))
                    { rep.DeleteSelected(ids, User.Identity.Name); }

                    else if (ids.Contains("Resubmit Selected"))
                    { rep.ResubmitSelected(ids, User.Identity.Name); }

                    else if (ids.Contains("Locked Selected"))
                    { rep.LockedSelected(ids, User.Identity.Name); }

                    else if (ids.Contains("Change Status Selected"))
                    {
                        if (ApplicationStatus != null)
                        { rep.ChangeStatusSelected(ids, User.Identity.Name, ApplicationStatus); }
                    }
                }

                List<JobApplicationViewModel> list = new List<JobApplicationViewModel>();

                list = rep.SearchModel(q);


                return View(list);
            }
            catch
            {
                ModelState.AddModelError("", "Error");
                return View();
            }
        }

        // GET: JobApplications/Details/5
        public ActionResult Details(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            JobApplicationViewModel model = new JobApplicationViewModel();

            model = rep.GetModel(id);


            ViewBag.Photo = ConfigurationManager.AppSettings["ProfilePhoto"].ToString() + model.UserID.ToString() + ".jpg";

            if (model == null)
            {
                return HttpNotFound();
            }

            return View(model);
        }

        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            JobApplicationViewModel model = new JobApplicationViewModel();

            model = rep.GetModel(id);

            if (model == null)
            {
                return HttpNotFound();
            }

            List<SelectListItem> li = new List<SelectListItem>();
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Submitted, Value = InitialData.ApplicationStatus.Submitted, Selected = false });
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Accepted, Value = InitialData.ApplicationStatus.Accepted, Selected = false });
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Rejected, Value = InitialData.ApplicationStatus.Rejected, Selected = false });
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.KIV, Value = InitialData.ApplicationStatus.KIV, Selected = false });

            ViewBag.ApplicationStatus = new SelectList(li, "Text", "Value", model.ApplicationStatus);

            model.PreBoarding.JoinDateText = model.PreBoarding.JoinDate.GetValueOrDefault().ToString("dd MMM yyyy");

            return View(model);
        }

        [HttpPost]
        public ActionResult Edit(FormCollection collection)
        {
            List<SelectListItem> li = new List<SelectListItem>();
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Submitted, Value = InitialData.ApplicationStatus.Submitted, Selected = false });
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Accepted, Value = InitialData.ApplicationStatus.Accepted, Selected = false });
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.Rejected, Value = InitialData.ApplicationStatus.Rejected, Selected = false });
            li.Add(new SelectListItem { Text = InitialData.ApplicationStatus.KIV, Value = InitialData.ApplicationStatus.KIV, Selected = false });

            try
            {
                JobApplicationViewModel jobApplication = new JobApplicationViewModel();

                jobApplication.ApplicationStatus = collection["ApplicationStatus"].Split(',')[0];

                if ((jobApplication.ApplicationStatus == String.Empty) || (jobApplication.ApplicationStatus == null))
                {
                    jobApplication.ApplicationStatus = rep.GetApplicationStatus(new Guid(collection["ID"].Split(',')[0]));
                }


                ViewBag.ApplicationStatus = new SelectList(li, "Text", "Value", jobApplication.ApplicationStatus);

                jobApplication.ID = new Guid(collection["ID"].Split(',')[0]);
                jobApplication.UserID = new Guid(collection["UserID"].Split(',')[0]);

                jobApplication.FullName = collection["FullName"].Split(',')[0];
                jobApplication.FirstName = collection["FirstName"].Split(',')[0];
                jobApplication.LastName = collection["LastName"].Split(',')[0];
                jobApplication.PositionApplied = collection["PositionApplied"].Split(',')[0];
                jobApplication.EmailAddress = collection["EmailAddress"].Split(',')[0];
                jobApplication.EmergencyContact = collection["EmergencyContact"].Split(',')[0];
                jobApplication.IsLocked = (collection["IsLocked"].Split(',')[0] != null ? Convert.ToBoolean(collection["IsLocked"].Split(',')[0]) : false);

                if (ModelState.IsValid)
                {
                    if (jobApplication.ApplicationStatus == InitialData.ApplicationStatus.Accepted)
                    {
                        PreBoardingViewModel pb = new PreBoardingViewModel();
                        pb.UserID = jobApplication.UserID;
                        pb.Position = jobApplication.PositionApplied;
                        pb.BuddyName = collection["BuddyName"].Split(',')[0];
                        pb.HRContactPerson = collection["HRContactPerson"].Split(',')[0];
                        pb.Supervisor = collection["Supervisor"].Split(',')[0];
                        pb.Department = collection["Department"].Split(',')[0];
                        pb.JoinDateText = collection["JoinDate"].Split(',')[0];

                        pb.RecruiterName = collection["RecruiterName"].Split(',')[0];

                        if (rep.GetPreBoardingModel(jobApplication.UserID) != null)
                        {
                            pb.UpdatedBy = User.Identity.Name;
                            rep.UpdatePreBoardingModel(pb);
                        }
                        else
                        {
                            pb.CreatedBy = User.Identity.Name;
                            rep.CreatePreBoardingModel(pb);
                        }
                    }
                    else
                    {
                        PreBoardingViewModel pb = new PreBoardingViewModel();
                        pb = rep.GetPreBoardingModel(new Guid(collection["UserID"].Split(',')[0]));
                        if (pb != null)
                        {
                            jobApplication.UpdatedBy = User.Identity.Name;
                            rep.DeletePreBoardingInfo(jobApplication);
                        }
                    }
                    jobApplication.IsDeleted = false;
                    jobApplication.UpdatedBy = User.Identity.Name;
                    jobApplication.IsLocked = jobApplication.ApplicationStatus != InitialData.ApplicationStatus.Submitted ? true : false;
                    rep.UpdateModel(jobApplication);
                    return RedirectToAction("Index");
                }

                return View();
            }
            catch
            {
                ModelState.AddModelError("", "Invalid Join Date.");
                return View();
            }
        }

        public ActionResult Resubmit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            JobApplicationViewModel model = new JobApplicationViewModel();

            model = rep.GetModel(id);

            if (model == null)
            {
                return HttpNotFound();
            }
            return View(model);
        }

        // POST: Applicants/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        //[Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        // public ActionResult Resubmit(Guid id)
        public ActionResult Resubmit([Bind(Include = "ID,UserID,FullName,FirstName, LastName,PositionApplied,EmailAddress,EmergencyContact,ApplicationStatus,IsLocked,IsDeleted")] JobApplicationViewModel jobApplication)
        {
            jobApplication.UpdatedBy = User.Identity.Name;
            jobApplication.IsDeleted = false;
            rep.DeleteModel(jobApplication);

            return RedirectToAction("Index");
        }

        // GET: JobApplications/Delete/5
        public ActionResult Delete(Guid id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            JobApplicationViewModel model = new JobApplicationViewModel();
            model = rep.GetModel(id);

            if (model == null)
            {
                return HttpNotFound();
            }

            return View(model);
        }

        // POST: JobApplications/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed([Bind(Include = "ID,UserID,FullName,FirstName, LastName,PositionApplied,EmailAddress,EmergencyContact,ApplicationStatus,IsLocked,IsDeleted")] JobApplicationViewModel jobApplication)
        {
            jobApplication.UpdatedBy = User.Identity.Name;
            jobApplication.IsDeleted = true;
            rep.DeleteModel(jobApplication);

            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Database.Instant.Dispose();
            }
            base.Dispose(disposing);
        }

        public ActionResult ExportApplicationForm(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            JobApplicationViewModel model = new JobApplicationViewModel();
            model = rep.GetModel(id);

            var Photo = ConfigurationManager.AppSettings["ProfilePhoto"].ToString() + model.UserID.ToString() + ".jpg";

            StringBuilder sb = new StringBuilder();
            sb.Append("<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8' /></head><body><table border='1' class='myaveris-table'>");

            sb.Append("<tr><td align='center'><img src='" + ConfigurationManager.AppSettings["AverisLogo"].ToString() + "' width='146' height='98' /></td><td colspan='8' align='center'><div style='font-size:large; font-weight:bold;'>EMPLOYMENT APPLICATION FORM</div></td><td align='center'><div style='font-size:12px; font-weight:bold;'>");

            sb.Append("<img src='" + Photo + "' width='120' height='120'  />");

            sb.Append(" </div></td></tr>");
            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Personal Information</td></tr>");
            sb.Append("<tr style='font-weight:bold;'><td>Title (Dr, Prof)</td><td colspan='6'>Name (As in passport. Pls underline surname/family name)</td><td>Known As</td><td>Chinese Character (if applicable)</td><td>Gender</td></tr>");
            sb.Append("<tr><td class='myaveris-td'>" + model.Title + "</td><td colspan='6' class='myaveris-td'>" + model.FirstName + " " + "<span class='lastname'>" + model.LastName + "</span>" + "</td><td class='myaveris-td'>" + model.KnownAs + "</td><td class='myaveris-td'>" + model.ChineseCharacter + "</td><td>" + model.Gender + "</td></tr>");
            sb.Append("<tr style='font-weight:bold;'><td>Date of Birth<br />(dd/mm/yyyy)</td><td colspan='3'>Country of Birth</td><td colspan='3'>Nationality</td><td>Race</td><td>Marital Status</td><td>Religion</td></tr>");
            sb.Append("<tr><td>" + util.DateFormat(model.DateOfBirth) + "</td><td colspan='3'>" + model.CountryOfBirth + "</td><td colspan='3'>" + model.Nationality + "</td><td>" + model.Race + "</td><td>" + model.MaritalStatus + "</td><td>" + model.Religion + "</td></tr>");
            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Personal ID</td></tr>");
            sb.Append("<tr style='font-weight:bold;'><td colspan='2'>Type</td><td align='center' colspan='2'>Number</td><td align='center' colspan='2'>Date of Issue (for passport)<br />(dd/mm/yyyy)</td><td align='center' colspan='2'>Date of Expiry (for passport)<br />(dd/mm/yyyy)</td><td align='center' colspan='2'>Country of Issue</td></tr>");
            sb.Append("<tr><td colspan='2' style='font-weight:bold;'>Identity Card/Passport No</td><td align='center' colspan='2'>" + model.IdentityNo + "</td><td align='center' colspan='2'>" + util.DateFormat(model.DateOfIssue) + "</td><td align='center' colspan='2'>" + util.DateFormat(model.DateOfExpiry) + "</td><td colspan='2'>" + model.CountryOfIssue + "</td></tr>");
            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Contact Details</td></tr>");
            sb.Append("<tr style='font-weight:bold; text-align:center;'><td>Address Type</td><td colspan='4'>Address</td><td>Postal Code</td><td colspan='2'>Country</td><td colspan='2'>Telephone Numbers</td></tr>");

            foreach (var a in model.Addresses)
            {
                if (a.AddressType == InitialData.AddressType.CurrentAddress)
                {
                    sb.Append("<tr><td rowspan='2' style='font-weight:bold;'>Current</td><td colspan='4' rowspan='2'>" + a.Address + "</td><td rowspan='2'>" + a.PostalCode + "</td><td colspan='2' rowspan='2'>" + a.Country + "</td><td style='font-weight:bold;'>Home:</td><td>" + a.HomeNumber + "</td></tr>");
                    sb.Append(" <tr><td style='font-weight:bold;'>Mobile:</td><td> " + a.MobileNumber + "</td></tr>");
                }

                if (a.AddressType == InitialData.AddressType.HomeAddress)
                {
                    sb.Append("<tr><td rowspan='2' style='font-weight:bold;'>Home<br />(if different from current address)</td><td colspan='4' rowspan='2'>" + a.Address + "</td><td rowspan='2'>" + a.PostalCode + "</td><td colspan='2' rowspan='2'>" + a.Country + "</td><td style='font-weight:bold;'>Home:</td><td>" + a.HomeNumber + "</td></tr>");
                    sb.Append("<tr><td style='font-weight:bold;'>Mobile:</td><td>" + a.MobileNumber + "</td></tr>");
                }

                if (a.AddressType == InitialData.AddressType.EmergencyAddress)
                {
                    sb.Append("<tr><td rowspan='2' style='font-weight:bold;'>Emergency<br />(if different from current address)</td><td colspan='4' rowspan='2'>" + a.Address + "</td><td rowspan='2'>" + a.PostalCode + "</td><td colspan='2' rowspan='2'>" + a.Country + "</td><td style='font-weight:bold;'>Home:</td><td>" + a.HomeNumber + "</td></tr>");
                    sb.Append("<tr><td style='font-weight:bold;'>Mobile:</td><td>" + a.MobileNumber + "</td></tr>");
                }
            }

            sb.Append("<tr><td style='font-weight:bold;'>Email Address</td><td colspan='9'>" + model.EmailAddress + "</td></tr>");
            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Family Details (Due to medical benefits purpose, full information of spouse & children must be provided)</td></tr>");
            sb.Append("<tr style='font-weight:bold; text-align:center;'><td>Family Members (Relationship)</td><td>Name (As in passport. Pls underline surname / family name)</td><td>I/C or Passport No.</td><td>Gender</td><td>Date of Birth<br />(dd/mm/yyyy)</td><td>Country of Birth</td><td>Nationality</td><td>Job Title</td><td>Employer</td><td>Is this person currently in the same country as you?</td></tr>");

            foreach (var f in model.Families)
            {
                sb.Append("<tr><td>" + f.Relationship + "</td>");

                if (f.FirstName == null)
                {
                    sb.Append("<td>N/A</td");
                }
                else
                {
                    sb.Append("<td>" + f.FirstName + " " + f.LastName + "</td>");
                }
                sb.Append("<td>" + f.IdentityNo + "</td><td>" + f.Gender + "</td>");

                if (f.DateOfBirth == null)
                {
                    sb.Append("<td>N/A</td>");
                }
                else
                {
                    sb.Append("<td>" + util.DateFormat(f.DateOfBirth) + "</td>");
                }

                sb.Append("<td>" + f.CountryOfBirth + "</td><td>" + f.Nationality + "</td>");
                sb.Append(" <td>" + f.JobTitle + "</td><td>" + f.Employer + "</td>");
                if (Convert.ToBoolean(f.IsSameCountry))
                {
                    sb.Append("<td class='myaveris-td'>Yes</td>");
                }
                else
                {
                    sb.Append("<td class='myaveris-td'>No</td>");
                }
                sb.Append("</tr>");
            }

            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Education - Formal and Professional</td></tr>");
            sb.Append("<tr style='font-weight:bold; text-align:center;'><td>Start Date<br />(dd/mm/yyyy)</td><td>End Date<br />(dd/mm/yyyy)</td><td colspan='3'>Education Institution</td><td>Country</td><td colspan='2'>Qualification<br />(Bachelor, Masters, CPA, etc)</td><td colspan='2'>Course of Study<br />(Business Administration, Accountancy, Mechanical Engineering, etc)</td></tr>");


            foreach (var e in model.Educations)
            {
                sb.Append("<tr>");
                if (e.StartDate == null)
                {
                    sb.Append("<td class='myaveris-td'>N/A</td>");
                    sb.Append("<td class='myaveris-td'>N/A</td>");
                }
                else
                {

                    sb.Append("<td class='myaveris-td'>" + util.DateFormat(e.StartDate) + "</td>");

                    if (e.EndDate == null)
                    { sb.Append("<td class='myaveris-td'>present</td>"); }
                    else
                    { sb.Append("<td class='myaveris-td'>" + util.DateFormat(e.EndDate) + "</td>"); }
                }
                sb.Append("<td colspan='3' class='myaveris-td'>" + e.Institution + "</td><td class ='myaveris-td'>" + e.Country + "</td><td colspan='2' class='myaveris-td'>" + e.Qualification + "</td><td colspan='2' class='myaveris-td'>" + e.CourseOfStudy + "</td></tr>");
            }

            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Language Skills</td></tr>");
            sb.Append("<tr><td style='font-weight:bold; text-align:center;' rowspan='2'>Language</td><td colspan='3' style='font-weight:bold; text-align:center;'>Read</td><td colspan='3' style='font-weight:bold; text-align:center;'>Write</td><td colspan='3' style='font-weight:bold; text-align:center;'>Speak</td></tr>");
            sb.Append("<tr><td style='font-weight:bold; text-align:center;'>Average</td><td style='font-weight:bold; text-align:center;'>Good</td><td style='font-weight:bold; text-align:center;'>Excellent</td><td style='font-weight:bold; text-align:center;'>Average</td><td style='font-weight:bold; text-align:center;'>Good</td><td style='font-weight:bold; text-align:center;'>Excellent</td><td style='font-weight:bold; text-align:center;'>Average</td><td style='font-weight:bold; text-align:center;'>Good</td><td style='font-weight:bold; text-align:center;'>Excellent</td></tr>");
            foreach (var l in model.Languages)
            {

                sb.Append("<tr ><td>" + l.Language + "</td>");

                if (l.ReadAbility == null)
                {
                    sb.Append("<td style='text-align:center;'></td>");
                    sb.Append("<td style='text-align:center;'></td>");
                    sb.Append("<td style='text-align:center;'></td>");
                }
                else
                {
                    if (l.ReadAbility == 1)
                    {
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                    }

                    if (l.ReadAbility == 2)
                    {
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                    }

                    if (l.ReadAbility == 3)
                    {
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                    }
                }


                if (l.WriteAbility == null)
                {
                    sb.Append("<td style='text-align:center;'></td>");
                    sb.Append("<td style='text-align:center;'></td>");
                    sb.Append("<td style='text-align:center;'></td>");
                }
                else
                {
                    if (l.WriteAbility == 1)
                    {
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                    }

                    if (l.WriteAbility == 2)
                    {
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                    }

                    if (l.WriteAbility == 3)
                    {
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                    }
                }

                if (l.SpeakAbility == null)
                {
                    sb.Append("<td style='text-align:center;'></td>");
                    sb.Append("<td style='text-align:center;'></td>");
                    sb.Append("<td style='text-align:center;'></td>");
                }
                else
                {
                    if (l.SpeakAbility == 1)
                    {
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                    }

                    if (l.SpeakAbility == 2)
                    {
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                    }

                    if (l.SpeakAbility == 3)
                    {
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>No</td>");
                        sb.Append("<td style='text-align:center;'>Yes</td>");
                    }
                }

                sb.Append("</tr>");
            }

            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Working History</td></tr>");
            sb.Append("<tr style='font-weight:bold; text-align=center;'><td>Start Date<br />(dd/mm/yyyy)</td><td>End Date<br />(dd/mm/yyyy)</td><td>Company</td><td>City/Country</td><td>Last Position Held</td><td>Name of Superior</td><td>Designation of Superior</td><td>Last Drawn Salary</td><td colspan='2'>Reason for leaving</td></tr>");
            foreach (var w in model.WorkingHistories)
            {
                if (w.LastDrawnSalaryText != "N/A") { w.LastDrawnSalaryText = Cryptography.Decryption(w.LastDrawnSalaryText); }
                sb.Append("<tr>");
                if (w.StartDate == null)
                {
                    sb.Append("<td>N/A</td><td>N/A</td>");
                }
                else
                {
                    sb.Append("<td>" + util.DateFormat(w.StartDate) + "</td>");
                    if (w.EndDate == null)
                    { sb.Append("<td>present</td>"); }
                    else
                    {
                        sb.Append("<td>" + util.DateFormat(w.EndDate) + "</td>");
                    }
                }
                sb.Append("<td>" + w.Company + "</td><td>" + w.Country + "</td><td>" + w.LastPositionHeld + "</td><td>" + w.NameOfSuperior + "</td><td>" + w.DesignationOfSuperior + "</td><td>" + String.Format("{0:0.00}", w.LastDrawnSalaryText) + "</td><td colspan='2'>" + w.ReasonForLeaving + "</td></tr>");
            }

            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Involvement In Social/ Political Activities</td></tr>");
            sb.Append("<tr style='font-weight:bold; text-align:center;' ><td colspan='3'>Organisation/ Club</td><td>From</td><td>To</td><td colspan='2'>Country</td><td colspan='3'>Nature of Activities</td></tr>");
            foreach (var a in model.Activities)
            {
                sb.Append("<tr><td colspan='3'>" + a.Organisation + "</td>");
                if (a.FromDate == null)
                { sb.Append("<td>N/A</td><td>N/A</td>"); }
                else
                {
                    sb.Append("<td>" + util.DateFormat(a.FromDate) + "</td>");
                    if (a.ToDate == null)
                    { sb.Append("<td>present</td>"); }
                    else { sb.Append("<td>" + util.DateFormat(a.ToDate) + "</td>"); }
                }
                sb.Append("<td colspan='2'>" + a.Country + "</td><td colspan='3'>" + a.NatureOfActivities + "</td></tr>");
            }

            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>National Service Liability (if applicable)</td></tr>");
            sb.Append("<tr><td style='font-weight:bold;'>Date Completed (dd/mm/yyyy)</td>");


            sb.Append("<td colspan='4'>" + util.DateFormat(model.ServiceCompleted) + "</td>");
            sb.Append("<td style='font-weight:bold;' colspan='2'>Highest Rank Attained</td><td colspan='3' class='myaveris-td'>" + model.HighestRankAttained + "</td></tr>");
            sb.Append("<tr><td style='font-weight:bold;'>If exempted, please give reasons:</td><td colspan='4'>" + model.ExemptionReason + "</td>");
            sb.Append("<td style='font-weight:bold;' colspan='2'>Liability For Reservist Duties</td>");
            if (model.LiabilityForDuties == true)
            { sb.Append("<td colspan='3'>Yes</td>"); }
            else
            { sb.Append("<td colspan='3'>No</td>"); }
            sb.Append("</tr>");
            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Reference Checks (It is the policy of this company to carry out reference checks with previous companies and referees provided)</td></tr>");
            foreach (var r in model.References)
            {
                sb.Append("<tr><td style='font-weight:bold;'>Name</td><td colspan='3'>" + r.Name + "</td><td style='font-weight:bold;'>Occupation</td><td colspan='3'>" + r.Occupation + "</td><td style='font-weight:bold;'>Years Known</td>");
                if (r.YearsKnown == null)
                { sb.Append("<td>N/A</td></tr>"); }
                else { sb.Append("<td>" + r.YearsKnown + "</td></tr>"); }


                sb.Append("<tr><td rowspan='2' style='font-weight:bold;'>Address</td><td colspan='7' rowspan='2'>" + r.Address + "</td><td style='font-weight:bold;'>Telephone</td><td>" + r.MobileNumber + "</td></tr>");
                sb.Append("<tr><td style='font-weight:bold;'>Home</td><td>" + r.HomeNumber + "</td></tr>");
                sb.Append("<tr><td style='font-weight:bold;'>Employer</td><td colspan='7'>" + r.Employer + "</td><td style='font-weight:bold;'>Office</td><td>" + r.OfficeNumber + "</td></tr>");
            }
            sb.Append("<tr><td colspan='10' style='background-color:#C0C0C0; font-weight:bold;'>Declaration</td></tr>");
            foreach (var d in model.Declarations)
            {
                sb.Append("<tr><td colspan='9'>" + rep.GetDeclarationDetail((Guid)d.DeclarationID) + "</td>");  //            

                if (d.Answer == true)
                {
                    sb.Append("<td>Yes</td>");
                }
                else { sb.Append("<td>No</td>"); }

                sb.Append("</tr>");
                if (d.Remarks != string.Empty)
                {
                    sb.Append("<tr><td colspan='10'>" + d.Remarks + "</td></tr>");
                }
            }

            sb.Append("<tr><td colspan='10'><br/><br/>I hereby declare that all the information given by me in this form and the copies attached are true and correct and that I am liable to be dismissed if it is found to be otherwise, notwithstanding any provisions in my contract of service with the Company. I acknowledge that employment is subject to my passing a medical examination.<br/>");
            sb.Append("I confirm that I have been notified of and consent to the Company’s collection, use and/or disclosure, to any Group Company, of my personal data, provided to the Company by me or by third parties, such as referees and former employers for the following:<br/>");
            sb.Append("(i) to assess my suitability for employment by the Company;<br />");
            sb.Append("(ii) If I am hired, all purposes relating to my gainful employment with the Company , including but not limited to administering and maintaining personnel records, paying and reviewing salary and other remuneration and benefits, undertaking performance appraisals and reviews, maintaining sickness and other absence records and taking decisions as to my fitness for work; and<br/>");
            sb.Append("(iii) ensuring the Company’s compliance with statutory and other legal requirements as may be applicable.<br />");
            sb.Append("I agree to take such steps as may be necessary to provide the Company with updates to my personal data as and when they occur. I also understand and agree that the provision of my personal data to the Company is necessary for the processing of this job application.<br/>");
            sb.Append("<br/><br/>");
            sb.Append("<u> Note to Applicant :</u><br/>");
            sb.Append("(i) For all enquiries in relation to personal data, including seeking access to, requesting correction of and providing updates on your personal data, you may contact the data protection officer at dpo@averis.biz or +60-3-27858888.<br/>");
            sb.Append("(ii) You may request the data protection officer to reasonably limit the processing of your personal data, including personal data relating to other persons who may be identified from your personal data, subject to the Company’s discretion which shall be exercised reasonably.<br/><br/>");
            sb.Append("<tr><td align='center' colspan='5'><br /><br />__________________________<br />Signature of Applicant</td><td align='center'  colspan='5'><br /><br />__________________________<br />Date</td></tr>");
            sb.Append("</table></body></html>");

            Response.Clear();
            Response.ClearHeaders();
            Response.ClearContent();
            Response.AddHeader("Content-Disposition", "attachment;filename=Application_Form_" + model.FullName + ".xls");
            Response.ContentType = "application/vnd.xls";
            Response.Cache.SetCacheability(HttpCacheability.NoCache); // not necessarily required
            Response.Charset = "";
            Response.Output.Write(sb);
            Response.End();
            return View();
        }

        public ActionResult Test(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            JobApplicationViewModel model = new JobApplicationViewModel();

            model = rep.GetModel(id);

            ViewBag.Photo = ConfigurationManager.AppSettings["ProfilePhoto"].ToString() + model.UserID.ToString() + ".jpg";

            if (model == null)
            {
                return HttpNotFound();
            }

            return PartialView(model);
        }

        public ActionResult CurrentPackage(Guid? id)
        {
            try
            {
                JobApplicationViewModel model = new JobApplicationViewModel();
                model = rep.GetModel(id);

                ViewBag.FullName = model.FullName;

                ViewBag.ID = model.ID;

                JobApplicationPackageDetailInfo package = new JobApplicationPackageDetailInfo();
                package = model.PackageDetail;

                package.JobApplicationID = model.ID;

                if(package != null)
                    return View(package);
                else
                    return View();
            }
            catch
            {
                ModelState.AddModelError("", "Error");
                return View();
            }
        }

        public ActionResult ExportCurrentPackage(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            JobApplicationViewModel model = new JobApplicationViewModel();
            model = rep.GetModel(id);

            JobApplicationPackageDetailInfo package = new JobApplicationPackageDetailInfo();
            package = model.PackageDetail;

            package.JobApplicationID = model.ID;

            StringBuilder sb = new StringBuilder();
            sb.Append("<html><head><meta http-equiv='Content-Type' content='text/html; charset=UTF-8' /></head><body><table border='1'>");
            sb.Append("<table border='1' style='background-color:#FFFFFF'>");
            sb.Append("<tr><td colspan='3' align='center' style='font-weight:bold; font-size:larger;background-color:orange'>Verification of Salary Details and Benefits<br />(Strictly Private & Confidential)</td></tr>");
            sb.Append("<tr><td style='font-weight:bold;'>Applicant's Name:</td><td colspan='2'>" + model.FullName + "</td></tr>");
            sb.Append("<tr style='font-weight:bold; background-color:orange'><td>Items</td><td>Remarks</td><td>RM</td></tr>");
            sb.Append("<tr><td>Base Salary</td><td></td><td>" + (util.GetValue(package.BaseSalary)) + "</td></tr>");
            sb.Append(" <tr><td>Expected salary</td><td></td><td>" + (util.GetValue(package.ExpectedSalary)) + "</td></tr>");
            sb.Append("<tr><td>Contractual Bonus</td><td></td><td>" + (util.GetValue(package.ContractualBonus)) + "</td></tr>");
            sb.Append("<tr><td>Performance Bonus</td><td></td><td>" + (util.GetValue(package.PerformanceBonus)) + "</td></tr>");
            sb.Append("<tr style='font-weight:bold; background-color:orange'><td>Fixed Allowances (as shown in payslip)</td><td></td><td>RM</td></tr>");
            sb.Append("<tr><td>Housing Allowance</td><td></td><td>" + (util.GetValue(package.HousingAllowance)) + "</td></tr>");
            sb.Append("<tr><td>Transport allowance</td><td>(Transport allowance, not milleage)</td><td>" + (util.GetValue(package.TransportAllowance)) + "</td></tr>");
            sb.Append("<tr><td>Connectivity allowance</td><td>(Broadband / handphone)</td><td>" + (util.GetValue(package.ConnectivityAllowance)) + "</td></tr>");
            sb.Append("<tr><td>Project allowance</td><td>(EPF deductable)</td><td>" + (util.GetValue(package.ProjectAlowance)) + "</td></tr>");
            sb.Append("<tr><td>Special Skills Allowance</td><td></td><td>" + (util.GetValue(package.SpecialSkillsAllowance)) + "</td></tr>");
            sb.Append("<tr><td>Car Park</td><td>(Paid by company)</td><td>" + (util.GetValue(package.CarParkAllowance)) + "</td></tr>");
            sb.Append("<tr style='font-weight:bold; background-color:orange'><td>Claims</td><td></td><td>RM</td></tr>");
            sb.Append("<tr><td>Car Park</td><td></td><td>" + (util.GetValue(package.CarParkClaim)) + "</td></tr>");
            sb.Append("<tr><td>Handphone</td><td></td><td>" + (util.GetValue(package.PhoneClaim)) + "</td></tr>");
            sb.Append("<tr><td>Mileage</td><td></td><td>" + (util.GetValue(package.MileageClaim)) + "</td></tr>");
            sb.Append("<tr><td>Meal</td><td></td><td>" + (util.GetValue(package.MealClaim)) + "</td></tr>");
            sb.Append("<tr><td>OT</td><td></td><td>" + (util.GetValue(package.OvertimeClaim)) + "</td></tr>");
            sb.Append("<tr><td>Standby/Shift</td><td></td><td>" + (util.GetValue(package.StandbyClaim)) + "</td></tr>");
            sb.Append("<tr style='font-weight:bold; background-color:orange'><td>Benefits</td><td></td><td>RM</td></tr>");
            sb.Append("<tr><td>Medical & Hospitalization</td><td></td><td></td></tr>");
            sb.Append("<tr><td>- Self</td><td></td><td>" + (util.GetValue(package.SelfMedicalBenefit)) + "</td></tr>");
            sb.Append("<tr><td>- Family</td><td></td><td>" + (util.GetValue(package.FamilyMedicalBenefit)) + "</td></tr>");
            sb.Append("<tr><td>Group Term Life & PA</td><td></td><td></td></tr>");
            sb.Append("<tr><td>- Self</td><td></td><td>" + (util.GetValue(package.SelfInsuranceBenefit)) + "</td></tr>");
            sb.Append("<tr><td>- Family</td><td></td><td>" + (util.GetValue(package.FamilyInsuranceBenefit)) + "</td></tr>");
            sb.Append("<tr><td>Dental</td><td></td><td>" + (util.GetValue(package.DentalBenefit)) + "</td></tr>");
            sb.Append(" <tr><td>Optical</td><td></td><td>" + (util.GetValue(package.OpticalBenefit)) + "</td></tr>");
            sb.Append("<tr><td>Annual Leave</td><td></td><td>" + (util.GetValue(package.AnnualLeave)) + "</td></tr>");
            sb.Append("<tr><td>Medical Leave</td><td></td><td>" + (util.GetValue(package.MedicalLeave)) + "</td></tr>");
            sb.Append("<tr><td>Retirement benefit</td><td></td><td>" + (util.GetValue(package.RetirementBenefit)) + "</td></tr>");
            sb.Append("<tr style='font-weight:bold; background-color:orange'><td>Statutory Details</td><td></td><td></td></tr>");
            sb.Append("<tr><td>EPF NO:</td><td></td><td>" + (util.GetValue(package.EPFNumber)) + "</td></tr>");
            sb.Append("<tr><td>SOCSO NO</td><td></td><td>" + (util.GetValue(package.SOCSONumber)) + "</td></tr>");
            sb.Append("<tr><td>INCOME TAX NO & ADDRESS</td><td></td><td>" + (util.GetValue(package.IncomeTaxNumber)) + "</td></tr>");
            sb.Append("<tr><td>MBB / OCBC Bank Details</td><td></td><td>" + (util.GetValue(package.BankAccountNumber)) + "</td></tr>");
            sb.Append("<tr><td colspan='3'><p>Note:</p><p>1) Pls provide us your monthly payslip for the last 3 months including the payslip that states the bonus (either contractual or performance / variable bonus)</p><p>2) For contractual bonus, please enclosed your letter of employment from your current employer stipulating the bonus.</p></td></tr>");
            sb.Append("</table></body></html>");

            Response.Clear();
            Response.AddHeader("Content-Disposition", "attachment;filename=CurrentPackage_" + model.FullName + ".xls");
            Response.ContentType = "application/vnd.xls";
            Response.Cache.SetCacheability(HttpCacheability.NoCache); // not necessarily required
            Response.Charset = "";
            Response.Output.Write(sb);
            Response.End();
            return View();
        }
    }
}
