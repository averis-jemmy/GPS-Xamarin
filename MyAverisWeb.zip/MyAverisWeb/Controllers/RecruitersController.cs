﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using System.Collections;
using MyAverisData;
using MyAverisEntity;


namespace MyAveris.Controllers
{
    [Authorize]
    public class RecruitersController : Controller
    {
        private UserRepository userRep = new UserRepository(Database.Instant);

        // GET: Applicants
        public ActionResult Index(string q)
        {
            try
            {
                List<UserViewModel> list = new List<UserViewModel>();

                if (User.IsInRole(ConfigurationManager.AppSettings["Admin"].ToString()))
                { list = userRep.SearchUser(q, true, true); }
                else
                { list = userRep.SearchUser(q, false, true); }


                if (Request.IsAjaxRequest())
                {
                    return PartialView("Index", list);
                }
                return View(list);
            }
            catch
            {
                ModelState.AddModelError("", "Error");
                return View();
            }
        }

        // GET: Applicants/Create
        public ActionResult Create()
        {
            UserViewModel user = new UserViewModel();
            user.PositionApplied = "HR";
            return View(user);
        }


        // POST: Applicants/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "ID,EmailAddress,Name,PhoneNumber,PositionApplied")] UserViewModel user)
        {
            if (ModelState.IsValid)
            {
                user.IsRecruiter = true;
                user.CreatedBy = User.Identity.Name;
                userRep.CreateUser(user);
                return RedirectToAction("Index");
            }

            return View(user);
        }


        //// GET: Applicants/Edit/5
        public ActionResult Edit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            UserViewModel model = new UserViewModel();
            model = userRep.GetUserViewModelByID(id.GetValueOrDefault());
            model.PositionApplied = "HR";
            if (model == null)
            {
                return HttpNotFound();
            }

            return View(model);
        }

        // POST: Recruiters/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "ID,EmailAddress,Name,PhoneNumber,PositionApplied")] UserViewModel user)
        {
            if (ModelState.IsValid)
            {
                user.UpdatedBy = User.Identity.Name;
                userRep.UpdateUser(user);
                return RedirectToAction("Index");
            }
            return View(user);
        }

        //// GET: Recruiters/Activate/5

        [Authorize(Roles = "Admin")]
        public ActionResult Activate(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            UserViewModel model = new UserViewModel();
            model = userRep.GetUserViewModelByID(id.GetValueOrDefault());

            if (model == null)
            {
                return HttpNotFound();
            }
            return View(model);
        }
        
        [HttpPost]
        [ValidateAntiForgeryToken]
        // POST: Recruiters/Activate/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        public ActionResult Activate(Guid id)
        {
            UserViewModel applicant = new UserViewModel();

            if (ModelState.IsValid)
            {
                applicant = userRep.GetUserViewModelByID(id);
                if (applicant == null)
                {
                    return HttpNotFound();
                }
                applicant.UpdatedBy = User.Identity.Name;
                applicant.IsDeleted = false;
                userRep.UpdateUser(applicant);
                return RedirectToAction("Index");
            }

            return View(applicant);
        }



        // GET: Recruiters/Delete/5
        public ActionResult Delete(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            UserViewModel applicant = new UserViewModel();
            applicant = userRep.GetUserViewModelByID(id.GetValueOrDefault());

            if (applicant == null)
            {
                return HttpNotFound();
            }
            return View(applicant);
        }

        // POST: Recruiters/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(Guid id)
        {
            UserViewModel applicant = new UserViewModel();
            applicant = userRep.GetUserViewModelByID(id);
            applicant.IsDeleted = true;
            applicant.UpdatedBy = User.Identity.Name;
            userRep.DeleteUser(applicant);
            return RedirectToAction("Index");
        }

        [Authorize(Roles = "Admin")]
        public ActionResult Resubmit(Guid? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            UserViewModel applicant = new UserViewModel();
            applicant = userRep.GetUserViewModelByID(id.GetValueOrDefault());
            if (applicant == null)
            {
                return HttpNotFound();
            }
            return View(applicant);
        }

        // POST: Recruiters/Resubmit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [Authorize(Roles = "Admin")]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Resubmit(Guid id)
        {
            UserViewModel applicant = new UserViewModel();
            applicant = userRep.GetUserViewModelByID(id);
            applicant.IsDeleted = false;
            applicant.UpdatedBy = User.Identity.Name;
            userRep.DeleteUser(applicant);
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                Database.Instant.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
